import { createFileRoute } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Use — KLXchange" },
      { name: "description", content: "The terms and conditions for using KLXchange, Malaysia's live money changer rate comparison site." },
      { property: "og:title", content: "Terms of Use — KLXchange" },
      { property: "og:description", content: "Terms governing use of klxchange.com." },
      { property: "og:url", content: "https://klxchange.com/terms" },
    ],
    links: [{ rel: "canonical", href: "https://klxchange.com/terms" }],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Terms of Use</h1>
        <p className="mt-3 text-sm text-muted-foreground">Last updated: 18 June 2026</p>

        <h2 className="mt-10 text-2xl font-bold">1. Acceptance</h2>
        <p className="mt-3 text-muted-foreground">
          By accessing klxchange.com you agree to these terms. If you do not agree, please don't use the site.
        </p>

        <h2 className="mt-10 text-2xl font-bold">2. What KLXchange is — and isn't</h2>
        <p className="mt-3 text-muted-foreground">
          KLXchange is an independent rate-comparison service for Malaysian money changers. We are
          <strong> not </strong> a licensed money changer, remittance service, financial advisor or
          payment institution, and we do not handle any currency or funds. All transactions happen
          directly between you and the money changer you choose to visit.
        </p>

        <h2 className="mt-10 text-2xl font-bold">3. Rates are indicative</h2>
        <p className="mt-3 text-muted-foreground">
          Rates displayed are pulled live from each merchant's published source. Despite our best
          efforts they may be delayed, cached, mis-parsed, or out of date. The rate you receive at
          the counter is the only rate that is binding. Always confirm before transacting.
        </p>

        <h2 className="mt-10 text-2xl font-bold">4. No financial advice</h2>
        <p className="mt-3 text-muted-foreground">
          Nothing on KLXchange is financial, investment, tax or legal advice. Currency markets move;
          you are responsible for your own decisions.
        </p>

        <h2 className="mt-10 text-2xl font-bold">5. Acceptable use</h2>
        <p className="mt-3 text-muted-foreground">
          You agree not to scrape, mirror, resell, or abuse the service, attempt to overload our
          infrastructure, or use the data to impersonate a money changer.
        </p>

        <h2 className="mt-10 text-2xl font-bold">6. Intellectual property</h2>
        <p className="mt-3 text-muted-foreground">
          The KLXchange name, logo, layout and original written content are ours. Money changer
          names, logos and rate data remain the property of their respective owners and are used
          here for comparison purposes under fair dealing.
        </p>

        <h2 className="mt-10 text-2xl font-bold">7. Disclaimer of warranties</h2>
        <p className="mt-3 text-muted-foreground">
          The site is provided "as is" without warranties of any kind. We do not warrant that rates
          are accurate, complete, current, or that the site will be uninterrupted.
        </p>

        <h2 className="mt-10 text-2xl font-bold">8. Limitation of liability</h2>
        <p className="mt-3 text-muted-foreground">
          To the maximum extent permitted by Malaysian law, KLXchange and its operators are not
          liable for any losses arising from your use of the site, including any difference between
          a rate shown here and the rate received at a counter.
        </p>

        <h2 className="mt-10 text-2xl font-bold">9. Changes</h2>
        <p className="mt-3 text-muted-foreground">
          We may revise these terms. Continued use after a change means you accept the new terms.
        </p>

        <h2 className="mt-10 text-2xl font-bold">10. Governing law</h2>
        <p className="mt-3 text-muted-foreground">
          These terms are governed by the laws of Malaysia.
        </p>
      </main>
      <SiteFooter />
    </div>
  );
}