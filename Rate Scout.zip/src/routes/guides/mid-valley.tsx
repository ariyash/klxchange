import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";
import { CHANGERS, type MoneyChanger, displayUnit, displayUnitLabel } from "@/lib/changers";
import { getLiveRates } from "@/lib/rates.functions";
import { getDbChangers, type DbChangerRow, type DbRateRow } from "@/lib/db-changers.functions";

const TITLE = "Money Changer Mid Valley — Best Live Rates Comparison | KL Xchange";
const DESC =
  "Compare live exchange rates from money changers in Mid Valley Megamall. Find the best USD, SGD, EUR, GBP, AUD and THB rates updated in real time.";
const URL = "https://klxchange.com/guides/mid-valley";
const POPULAR = ["USD", "SGD", "EUR", "GBP", "AUD", "THB", "JPY", "CNY"] as const;

export const Route = createFileRoute("/guides/mid-valley")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: "Money Changer Mid Valley — Best Live Rates Comparison",
          description: DESC,
          mainEntityOfPage: URL,
          about: "Money changers in Mid Valley Megamall, Kuala Lumpur",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home", item: "https://klxchange.com/" },
            { "@type": "ListItem", position: 2, name: "Guides", item: "https://klxchange.com/guides/mid-valley" },
            { "@type": "ListItem", position: 3, name: "Mid Valley", item: URL },
          ],
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: [
            {
              "@type": "Question",
              name: "Which money changer in Mid Valley gives the best rate?",
              acceptedAnswer: {
                "@type": "Answer",
                text: "Rates change throughout the day. Use the live comparison table above to see the best buy and sell rates among Mid Valley Megamall money changers right now.",
              },
            },
            {
              "@type": "Question",
              name: "What are the opening hours of money changers in Mid Valley Megamall?",
              acceptedAnswer: {
                "@type": "Answer",
                text: "Most Mid Valley Megamall money changers operate daily from 10:00 AM to 10:00 PM, in line with the mall's hours.",
              },
            },
            {
              "@type": "Question",
              name: "Do Mid Valley money changers accept all currencies?",
              acceptedAnswer: {
                "@type": "Answer",
                text: "Major currencies (USD, SGD, EUR, GBP, AUD, THB, JPY, CNY) are usually available. Less common currencies may be limited — call ahead to confirm stock.",
              },
            },
          ],
        }),
      },
    ],
  }),
  component: MidValleyGuide,
});

type RowChanger = {
  slug: string;
  name: string;
  address: string;
  hours: string;
  phone: string;
  rating: number;
  reviews: number;
};

function MidValleyGuide() {
  const [currency, setCurrency] = useState<string>("USD");

  const seedMidValley: RowChanger[] = useMemo(
    () =>
      (CHANGERS as MoneyChanger[])
        .filter((c) => c.area === "Mid Valley")
        .map((c) => ({
          slug: c.slug,
          name: c.name,
          address: c.address,
          hours: c.hours,
          phone: c.phone,
          rating: c.rating,
          reviews: c.reviews,
        })),
    [],
  );

  const dbFn = useServerFn(getDbChangers);
  const ratesFn = useServerFn(getLiveRates);

  const { data: dbData } = useQuery({
    queryKey: ["db-changers"],
    queryFn: () => dbFn(),
    staleTime: 60_000,
  });

  const { data: live } = useQuery({
    queryKey: ["live-rates"],
    queryFn: () => ratesFn(),
    refetchInterval: 3_000,
    staleTime: 0,
  });

  const dbMidValley: RowChanger[] = useMemo(() => {
    const rows = (dbData?.changers ?? []) as DbChangerRow[];
    return rows
      .filter((c) => (c.area ?? "").toLowerCase().includes("mid valley"))
      .map((c) => ({
        slug: c.slug,
        name: c.name,
        address: c.address,
        hours: c.hours,
        phone: c.phone,
        rating: c.rating,
        reviews: c.reviews,
      }));
  }, [dbData]);

  const all: RowChanger[] = useMemo(() => {
    const map = new Map<string, RowChanger>();
    for (const r of [...seedMidValley, ...dbMidValley]) map.set(r.slug, r);
    return [...map.values()];
  }, [seedMidValley, dbMidValley]);

  const dbRatesBySlug = useMemo(() => {
    const out: Record<string, Record<string, { buy: number; sell: number; unit: number }>> = {};
    const changersBySlug = new Map(
      ((dbData?.changers ?? []) as DbChangerRow[]).map((c) => [c.slug, c.id]),
    );
    for (const r of (dbData?.rates ?? []) as DbRateRow[]) {
      const slug = [...changersBySlug.entries()].find(([, id]) => id === r.changer_id)?.[0];
      if (!slug) continue;
      out[slug] = out[slug] ?? {};
      out[slug][r.code] = { buy: Number(r.buy), sell: Number(r.sell), unit: Number(r.unit) || 1 };
    }
    return out;
  }, [dbData]);

  const rows = useMemo(() => {
    return all
      .map((c) => {
        const liveEntry = live?.[c.slug];
        const liveRate = liveEntry?.rates?.[currency];
        const dbRate = dbRatesBySlug[c.slug]?.[currency];
        const rate = liveRate
          ? { buy: liveRate.buy, sell: liveRate.sell, unit: liveRate.unit || 1 }
          : dbRate;
        return { ...c, rate };
      })
      .sort((a, b) => {
        if (!a.rate && !b.rate) return 0;
        if (!a.rate) return 1;
        if (!b.rate) return -1;
        // Best to BUY foreign currency = lowest "sell" rate (you pay less MYR)
        return a.rate.sell / a.rate.unit - b.rate.sell / b.rate.unit;
      });
  }, [all, live, dbRatesBySlug, currency]);

  const scale = displayUnit(currency);
  const displayLabel = displayUnitLabel(currency);

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <SiteHeader />
      <main className="flex-1">
        <article className="container mx-auto px-4 py-10 max-w-4xl">
          <nav aria-label="Breadcrumb" className="text-sm text-muted-foreground mb-4">
            <Link to="/" className="hover:underline">Home</Link>
            <span className="mx-2">/</span>
            <span>Guides</span>
            <span className="mx-2">/</span>
            <span className="text-foreground">Mid Valley</span>
          </nav>

          <header className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
              Money Changer Mid Valley: Best Live Rates in Mid Valley Megamall
            </h1>
            <p className="mt-3 text-muted-foreground">
              Comparing live buy and sell rates from licensed money changers inside Mid Valley
              Megamall. Rates refresh every few seconds — pick the best rate before you walk over.
            </p>
          </header>

          <section aria-labelledby="live-rates" className="mb-10">
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
              <h2 id="live-rates" className="text-2xl font-semibold">Live rate comparison</h2>
              <label className="text-sm flex items-center gap-2">
                <span className="text-muted-foreground">Currency</span>
                <select
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  className="border rounded-md px-2 py-1 bg-background"
                >
                  {POPULAR.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </label>
            </div>

            <div className="overflow-x-auto border rounded-lg">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="text-left p-3">Money changer</th>
                    <th className="text-right p-3">We buy ({displayLabel})</th>
                    <th className="text-right p-3">We sell ({displayLabel})</th>
                    <th className="text-left p-3">Details</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.length === 0 && (
                    <tr>
                      <td colSpan={4} className="p-4 text-center text-muted-foreground">
                        Loading rates…
                      </td>
                    </tr>
                  )}
                  {rows.map((r, idx) => (
                    <tr key={r.slug} className="border-t">
                      <td className="p-3">
                        <div className="font-medium flex items-center gap-2">
                          {r.name}
                          {idx === 0 && r.rate && (
                            <span className="text-xs bg-primary text-primary-foreground px-1.5 py-0.5 rounded">
                              Best
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">{r.hours}</div>
                      </td>
                      <td className="p-3 text-right tabular-nums">
                        {r.rate ? ((r.rate.buy / r.rate.unit) * scale).toFixed(4) : "—"}
                      </td>
                      <td className="p-3 text-right tabular-nums">
                        {r.rate ? ((r.rate.sell / r.rate.unit) * scale).toFixed(4) : "—"}
                      </td>
                      <td className="p-3">
                        <Link
                          to="/changer/$slug"
                          params={{ slug: r.slug }}
                          className="text-primary hover:underline"
                        >
                          View profile →
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Sorted by best "we sell" rate (the rate you pay in MYR to buy foreign currency).
              Rates are indicative and may differ at the counter for large transactions.
            </p>
          </section>

          <section className="prose prose-neutral dark:prose-invert max-w-none mb-10">
            <h2>Where to find money changers in Mid Valley Megamall</h2>
            <p>
              Mid Valley Megamall hosts several licensed money changers spread across the Lower
              Ground (LG) and South Court (S-P1) floors. They sit close to one another, which
              makes it easy to walk a few metres and compare counter rates — or save the trip and
              compare them live above.
            </p>
            <h2>How we pick the best rate</h2>
            <p>
              For travellers <strong>buying</strong> a foreign currency, the best changer is the
              one with the lowest <em>sell</em> rate (you pay fewer MYR per unit). For travellers
              <strong> selling</strong> leftover foreign notes, the best changer is the one with
              the highest <em>buy</em> rate. The table above defaults to "best to buy", which is
              the most common scenario for travellers heading out from KL.
            </p>
            <h2>Tips before you walk over</h2>
            <ul>
              <li>Call ahead for large amounts (RM10,000+) — small counters may not hold stock.</li>
              <li>Bring your passport or MyKad; AMLA rules require ID above small thresholds.</li>
              <li>Avoid airport changers if you can — Mid Valley rates are typically much better.</li>
              <li>Mid-morning and early afternoon usually have the best rates and shortest queues.</li>
            </ul>
          </section>

          <section aria-labelledby="changers" className="mb-10">
            <h2 id="changers" className="text-2xl font-semibold mb-4">
              Money changers in Mid Valley
            </h2>
            <ul className="grid gap-3 sm:grid-cols-2">
              {all.map((c) => (
                <li key={c.slug} className="border rounded-lg p-4">
                  <Link
                    to="/changer/$slug"
                    params={{ slug: c.slug }}
                    className="font-medium hover:underline"
                  >
                    {c.name}
                  </Link>
                  <div className="text-xs text-muted-foreground mt-1">{c.address}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    ★ {c.rating} ({c.reviews} reviews) · {c.hours}
                  </div>
                </li>
              ))}
            </ul>
          </section>

          <section aria-labelledby="faq" className="mb-4">
            <h2 id="faq" className="text-2xl font-semibold mb-4">FAQ</h2>
            <dl className="space-y-4">
              <div>
                <dt className="font-medium">Which money changer in Mid Valley gives the best rate?</dt>
                <dd className="text-muted-foreground">
                  Rates change throughout the day. Use the live comparison table above to see who
                  is leading right now.
                </dd>
              </div>
              <div>
                <dt className="font-medium">What are the opening hours?</dt>
                <dd className="text-muted-foreground">
                  Most counters follow mall hours, roughly 10:00 AM – 10:00 PM daily.
                </dd>
              </div>
              <div>
                <dt className="font-medium">Do they accept all currencies?</dt>
                <dd className="text-muted-foreground">
                  Major currencies are always stocked. For exotic currencies, call ahead.
                </dd>
              </div>
            </dl>
          </section>
        </article>
      </main>
      <SiteFooter />
    </div>
  );
}