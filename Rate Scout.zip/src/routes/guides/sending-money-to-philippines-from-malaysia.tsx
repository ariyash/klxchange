import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

const TITLE = "Sending Money to the Philippines from Malaysia — 2026 Remittance Guide | KLXchange";
const DESC =
  "How to send ringgit to PHP from Malaysia: compare Placid Express, Western Union, MoneyGram and bank transfers. Real fees, real rates, and how to spot the cheapest channel for OFW remittance.";
const URL = "https://klxchange.com/guides/sending-money-to-philippines-from-malaysia";

export const Route = createFileRoute("/guides/sending-money-to-philippines-from-malaysia")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "article" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: "Sending Money to the Philippines from Malaysia",
          description: DESC,
          mainEntityOfPage: URL,
          author: { "@type": "Organization", name: "KLXchange" },
          publisher: { "@type": "Organization", name: "KLXchange" },
          datePublished: "2026-06-18",
          dateModified: "2026-06-18",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: [
            { "@type": "Question", name: "What's the cheapest way to send money from Malaysia to the Philippines?", acceptedAnswer: { "@type": "Answer", text: "Licensed remittance operators like Placid Express, MoneyGram and Western Union typically beat bank wires on both fee and FX margin. Fees are usually RM 5–15 per transfer and PHP arrives in minutes for cash pickup, or same-day for GCash and bank deposit." } },
            { "@type": "Question", name: "Is Placid Express good for PHP remittance?", acceptedAnswer: { "@type": "Answer", text: "Placid Express is one of the most-used corridors for Malaysia-to-Philippines transfers. Cash pickup is available at most major Philippine banks and pawnshops. Always check the MYR to PHP rate against the day's mid-market rate before sending." } },
            { "@type": "Question", name: "Can I send via GCash from Malaysia?", acceptedAnswer: { "@type": "Answer", text: "Yes — most KL remittance counters now offer direct top-up to a GCash wallet. Same-day delivery, often free or RM 5 fee. Bring the recipient's GCash-registered mobile number." } },
            { "@type": "Question", name: "What documents do I need?", acceptedAnswer: { "@type": "Answer", text: "Your passport or work permit, recipient's full name as it appears on their ID, and either bank/branch details, GCash number, or a cash-pickup reference for them to collect." } },
            { "@type": "Question", name: "Is there a limit on how much I can send?", acceptedAnswer: { "@type": "Answer", text: "Under Bank Negara Malaysia rules, individual cross-border transfers are generally capped at RM 50,000 per day without additional documentation. Most OFW remittances are well under this." } },
          ],
        }),
      },
    ],
  }),
  component: Guide,
});

function Guide() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />
      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <nav className="text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link> › <span>Guides</span> ›{" "}
          <span className="text-foreground">Sending money to the Philippines</span>
        </nav>
        <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">
          Sending money to the Philippines from Malaysia
        </h1>
        <p className="mt-3 text-sm text-muted-foreground">Updated June 2026 · 7 min read</p>

        <p className="mt-8 text-lg leading-relaxed">
          Roughly 200,000 Filipinos work in Malaysia, and remittance to the Philippines is one of the busiest
          money corridors in KL. The good news: it's also one of the cheapest in Southeast Asia, with fees as low
          as RM 5 and same-day delivery to GCash, bank accounts, and pawnshop pickup. This guide compares the main
          channels and shows you how to spot a fair MYR-to-PHP rate.
        </p>

        <h2 className="mt-12 text-2xl font-semibold">1. Your four options</h2>
        <table className="mt-4 w-full text-sm">
          <thead className="border-b text-left text-muted-foreground"><tr><th className="py-2">Channel</th><th>Speed</th><th>Typical fee</th></tr></thead>
          <tbody>
            <tr className="border-b"><td className="py-2 font-medium">Placid Express</td><td>Minutes (cash) / same-day (bank/GCash)</td><td>RM 5–10</td></tr>
            <tr className="border-b"><td className="py-2 font-medium">Western Union</td><td>Minutes (cash pickup)</td><td>RM 8–18</td></tr>
            <tr className="border-b"><td className="py-2 font-medium">MoneyGram</td><td>Minutes (cash pickup)</td><td>RM 6–15</td></tr>
            <tr><td className="py-2 font-medium">Bank wire (Maybank, CIMB)</td><td>1–3 business days</td><td>RM 25–50</td></tr>
          </tbody>
        </table>

        <h2 className="mt-10 text-2xl font-semibold">2. Compare the rate, not just the fee</h2>
        <p className="mt-3">
          A "no fee" promotion often hides a worse MYR-PHP rate. Check the day's mid-market rate (e.g. RM 1 ≈
          PHP 12.5 in mid-2026) and compare it to what the operator quotes. A 2% margin on RM 1,000 is PHP 250 —
          much more than the RM 10 fee difference between counters.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">3. Cash pickup vs bank vs GCash</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6">
          <li><strong>Cash pickup</strong> — fastest, available at BDO, Metrobank, M Lhuillier, Cebuana Lhuillier, Palawan Pawnshop. Best if the recipient has no bank account.</li>
          <li><strong>Bank deposit</strong> — cheapest for amounts above RM 500. Same-day to most Philippine banks.</li>
          <li><strong>GCash / Maya wallet</strong> — fastest digital option. Funds land in minutes, recipient withdraws via ATM or pays bills directly.</li>
        </ul>

        <h2 className="mt-10 text-2xl font-semibold">4. Where to send from in KL</h2>
        <p className="mt-3">
          Most Bukit Bintang, Sungei Wang, KLCC, Mid Valley and Masjid India money changers also handle PHP
          remittance — often at better rates than standalone WU/MG counters because the FX desk is in-house.
          KLXchange lists every licensed changer with remittance services so you can find the nearest one.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">5. What to bring</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6">
          <li>Your passport or Malaysian work permit (i-Kad).</li>
          <li>Recipient's full name <em>exactly</em> as it appears on their valid Philippine ID.</li>
          <li>For bank deposit: bank name, branch, and account number.</li>
          <li>For GCash: the recipient's GCash-registered Philippine mobile number.</li>
          <li>For cash pickup: just the recipient's name — you'll get a reference number to share with them.</li>
        </ul>

        <div className="mt-10 rounded-lg border bg-muted/30 p-6">
          <p className="text-sm font-medium">Compare PHP rates in KL right now</p>
          <p className="mt-1 text-sm text-muted-foreground">Live MYR-PHP rates from major KL changers.</p>
          <Link to="/" className="mt-3 inline-block rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
            View live PHP rates →
          </Link>
        </div>
      </article>
      <SiteFooter />
    </div>
  );
}
