import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

const TITLE = "KLIA & KLIA2 Airport Money Changer Guide 2026 — Should You Change at the Airport? | KLXchange";
const DESC =
  "Honest guide to changing money at KLIA and KLIA2: which counters are open 24 hours, how bad airport rates really are, ATM vs counter, and the smartest way to land in Malaysia with ringgit.";
const URL = "https://klxchange.com/guides/klia-airport-money-changer-guide";

export const Route = createFileRoute("/guides/klia-airport-money-changer-guide")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "article" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: "KLIA & KLIA2 Airport Money Changer Guide 2026",
          description: DESC,
          mainEntityOfPage: URL,
          author: { "@type": "Organization", name: "KLXchange" },
          publisher: { "@type": "Organization", name: "KLXchange" },
          datePublished: "2026-06-18",
          dateModified: "2026-06-18",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: [
            { "@type": "Question", name: "Should I change money at KLIA?", acceptedAnswer: { "@type": "Answer", text: "Only the bare minimum — RM 100–150 is enough for the KLIA Ekspres or a taxi to KL. Airport rates are typically 2–4% worse than Bukit Bintang or Mid Valley." } },
            { "@type": "Question", name: "Are KLIA money changers open 24 hours?", acceptedAnswer: { "@type": "Answer", text: "Yes — both KLIA Terminal 1 and KLIA2 have 24-hour money changer counters in the arrival hall and after immigration. ATM withdrawal is also available 24/7 from Maybank, CIMB, and Public Bank machines." } },
            { "@type": "Question", name: "ATM withdrawal or counter exchange at KLIA?", acceptedAnswer: { "@type": "Answer", text: "ATM is usually slightly cheaper than the counter once you account for the spread — most foreign cards are charged RM 12 per withdrawal plus your home bank's FX fee. For small amounts, the convenience is similar; for anything over RM 500, wait until you reach KL city." } },
            { "@type": "Question", name: "Which currencies do KLIA changers accept?", acceptedAnswer: { "@type": "Answer", text: "All major currencies: USD, EUR, GBP, SGD, AUD, JPY, CNY, HKD, KRW, THB, IDR, PHP, INR. Exotic currencies (e.g. BND, NPR) may only be available at the city changers." } },
            { "@type": "Question", name: "Can I use Grab from KLIA without ringgit?", acceptedAnswer: { "@type": "Answer", text: "Yes — Grab accepts foreign credit cards. You don't strictly need cash to leave the airport. KLIA Ekspres also accepts card and contactless." } },
          ],
        }),
      },
    ],
  }),
  component: Guide,
});

function Guide() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />
      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <nav className="text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link> › <span>Guides</span> ›{" "}
          <span className="text-foreground">KLIA airport money changer guide</span>
        </nav>
        <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">
          KLIA & KLIA2 airport money changer guide
        </h1>
        <p className="mt-3 text-sm text-muted-foreground">Updated June 2026 · 5 min read</p>

        <p className="mt-8 text-lg leading-relaxed">
          You've landed at KLIA at 1am with nothing but a foreign credit card and USD 200 in your pocket. Do you
          change it now or wait? Short answer: change the bare minimum at the airport, get to KL, and change
          the rest at a licensed money changer in Bukit Bintang or Mid Valley. Here's the detail.
        </p>

        <h2 className="mt-12 text-2xl font-semibold">How bad are KLIA rates really?</h2>
        <p className="mt-3">
          On a typical day, KLIA airport counters quote USD-MYR about <strong>2–4% below the rate at Bukit Bintang</strong>.
          On USD 100 that's roughly RM 10–20. On USD 1,000, it's RM 100–200 — enough to pay for a night at a
          decent hotel. The further from immigration you walk, the worse the rate usually gets.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">Counters at KLIA and KLIA2</h2>
        <p className="mt-3">
          Both terminals have multiple 24-hour money changers: <strong>Maybank, CIMB, Public Bank, Travelex,
          Western Union</strong> and a handful of independent licensed changers. In the arrival hall, the
          counters past immigration tend to be slightly better than the ones inside the secured area.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">Change just enough</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6">
          <li><strong>KLIA Ekspres train to KL Sentral:</strong> RM 55 one-way (card accepted, cash optional).</li>
          <li><strong>Airport taxi / Grab to KL city:</strong> RM 80–120 (Grab takes foreign credit cards).</li>
          <li><strong>Snack / SIM card:</strong> RM 30–50.</li>
        </ul>
        <p className="mt-3">
          So <strong>RM 150 is plenty</strong> for a typical traveller landing in KL. Change USD 50 at the airport
          and save the rest for a city changer.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">ATM withdrawal — when it makes sense</h2>
        <p className="mt-3">
          Maybank, CIMB and Public Bank ATMs at KLIA accept Visa, Mastercard, UnionPay and most major networks.
          The Malaysian-side fee is typically RM 12 per withdrawal, plus whatever your home bank charges
          (anywhere from 0% to 3%). For small amounts the convenience often wins; for amounts above RM 500, a
          city money changer is usually cheaper than withdrawing the equivalent in two ATM trips.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">The smartest workflow</h2>
        <ol className="mt-3 list-decimal space-y-2 pl-6">
          <li>Land. Change USD 50 (or equivalent) at the nearest licensed counter — enough for transport and the night.</li>
          <li>Take KLIA Ekspres or Grab into the city.</li>
          <li>The next morning, open KLXchange, compare USD-MYR rates in Bukit Bintang or Mid Valley, and change the rest there.</li>
        </ol>

        <div className="mt-10 rounded-lg border bg-muted/30 p-6">
          <p className="text-sm font-medium">Already in KL?</p>
          <p className="mt-1 text-sm text-muted-foreground">
            See live USD, SGD, EUR, GBP, AUD and more rates from every major KL changer.
          </p>
          <Link to="/" className="mt-3 inline-block rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
            View live rates →
          </Link>
        </div>
      </article>
      <SiteFooter />
    </div>
  );
}
