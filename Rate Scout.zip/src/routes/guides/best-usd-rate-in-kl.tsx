import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

const TITLE = "Best USD to MYR Rate in KL Today — Where to Change Dollars in 2026 | KLXchange";
const DESC =
  "Where to get the best US dollar to ringgit exchange rate in Kuala Lumpur. Compare licensed money changers in Bukit Bintang, Mid Valley, KLCC and KLIA, and learn how to time your USD-MYR conversion.";
const URL = "https://klxchange.com/guides/best-usd-rate-in-kl";

export const Route = createFileRoute("/guides/best-usd-rate-in-kl")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "article" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: "Best USD to MYR Rate in KL Today",
          description: DESC,
          mainEntityOfPage: URL,
          author: { "@type": "Organization", name: "KLXchange" },
          publisher: { "@type": "Organization", name: "KLXchange" },
          datePublished: "2026-06-18",
          dateModified: "2026-06-18",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: [
            { "@type": "Question", name: "Where do I get the best USD rate in KL?", acceptedAnswer: { "@type": "Answer", text: "Licensed money changers in Bukit Bintang (Jalan Bukit Bintang, Sungei Wang, Berjaya Times Square) and Mid Valley typically offer the tightest USD-MYR spreads in KL — usually 1–3 sen better than banks and 5–10 sen better than the airport." } },
            { "@type": "Question", name: "Should I bring USD 100 bills or smaller notes?", acceptedAnswer: { "@type": "Answer", text: "USD 100 bills (series 2013 or newer, no marks or tears) get the best rate. USD 50 and below are usually quoted 1–2 sen lower per dollar. Avoid bringing old-series notes — many KL changers refuse pre-2006 issues." } },
            { "@type": "Question", name: "What time of day is the USD-MYR rate best?", acceptedAnswer: { "@type": "Answer", text: "Mid-morning (10am–12pm) tends to be best. Changers update boards after the overnight US session settles, and competition is highest before the lunch rush." } },
            { "@type": "Question", name: "Is it worth shopping between changers?", acceptedAnswer: { "@type": "Answer", text: "Yes — on a USD 1,000 exchange, a 3 sen difference per dollar is RM 30. KLXchange shows live USD rates from major KL changers side-by-side so you can pick the best one before walking over." } },
          ],
        }),
      },
    ],
  }),
  component: Guide,
});

function Guide() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />
      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <nav className="text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link> › <span>Guides</span> ›{" "}
          <span className="text-foreground">Best USD rate in KL</span>
        </nav>
        <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">Best USD to MYR rate in KL today</h1>
        <p className="mt-3 text-sm text-muted-foreground">Updated June 2026 · 6 min read</p>

        <p className="mt-8 text-lg leading-relaxed">
          If you're holding US dollars in Kuala Lumpur, where you change them matters more than most travellers
          realise. On a USD 1,000 exchange, the gap between the best and worst rate in KL is routinely RM 50–100.
          This guide explains where to go, what notes to bring, and how to use KLXchange's live board to find the
          best USD-MYR rate right now.
        </p>

        <h2 className="mt-12 text-2xl font-semibold">1. The three KL zones with the best USD rates</h2>
        <p className="mt-3">
          Three areas in KL are consistently competitive for USD: <strong>Bukit Bintang</strong> (Jalan Bukit
          Bintang, Sungei Wang Plaza, Berjaya Times Square), <strong>Mid Valley</strong> (Mid Valley Megamall and
          The Gardens), and <strong>Masjid India / Jalan Tuanku Abdul Rahman</strong>. Density of changers = price
          competition; you can walk past five counters in 100 metres and undercut any single one.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">2. Where NOT to change USD in KL</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6">
          <li><strong>KLIA / KLIA2 arrival counters</strong> — typically 1.5–3% worse than Bukit Bintang. Change only enough for the train or taxi.</li>
          <li><strong>Hotel front desks</strong> — convenience markup of 2–4%. Almost never worth it.</li>
          <li><strong>Banks</strong> — fine for large amounts with paper trail, but rates are 1–2% behind licensed changers.</li>
        </ul>

        <h2 className="mt-10 text-2xl font-semibold">3. Bring the right USD notes</h2>
        <p className="mt-3">
          KL changers price USD by denomination. <strong>USD 100 bills, series 2013 or later, crisp and unmarked,</strong>
          get the headline rate. USD 50, 20, 10, 5 and 1 are usually quoted 1–3 sen lower per dollar. Pre-2006
          notes, marked notes, or notes with tears are often refused outright — most changers post strict acceptance
          rules above the counter.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">4. Time it right</h2>
        <p className="mt-3">
          Rates move with the overnight US session. Most KL changers update their boards between 9:30am and 10:30am,
          and again around 2pm if the USD has moved sharply. Mid-morning is usually the best window — fresh rate,
          full inventory, before the lunch crowd. Friday afternoon rates can be slightly worse as changers protect
          themselves over the weekend.
        </p>

        <h2 className="mt-10 text-2xl font-semibold">5. Use the live board, then walk over</h2>
        <p className="mt-3">
          Don't guess. KLXchange pulls live USD-MYR buy and sell rates from every major KL changer multiple times
          per hour. Open the table, sort by USD, and you'll see the best three rates in KL at the top — gold, silver,
          and bronze. Walk to that counter directly.
        </p>

        <div className="mt-10 rounded-lg border bg-muted/30 p-6">
          <p className="text-sm font-medium">Ready to compare?</p>
          <p className="mt-1 text-sm text-muted-foreground">
            See the top USD-MYR rates in KL right now, updated live.
          </p>
          <Link to="/" className="mt-3 inline-block rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
            View live USD rates →
          </Link>
        </div>

        <h2 className="mt-12 text-2xl font-semibold">Frequently asked questions</h2>
        <div className="mt-4 space-y-5">
          <div><p className="font-medium">Where do I get the best USD rate in KL?</p><p className="mt-1 text-sm text-muted-foreground">Licensed money changers in Bukit Bintang and Mid Valley. Use KLXchange to see the current leader before you go.</p></div>
          <div><p className="font-medium">USD 100 or smaller notes?</p><p className="mt-1 text-sm text-muted-foreground">Always USD 100 (series 2013+, clean). Smaller notes are quoted 1–2 sen lower per dollar.</p></div>
          <div><p className="font-medium">What time of day is best?</p><p className="mt-1 text-sm text-muted-foreground">Mid-morning, 10am–12pm — boards are fresh and competition is highest.</p></div>
          <div><p className="font-medium">Is shopping around worth it?</p><p className="mt-1 text-sm text-muted-foreground">On USD 1,000, a 3 sen gap is RM 30. Yes.</p></div>
        </div>
      </article>
      <SiteFooter />
    </div>
  );
}
