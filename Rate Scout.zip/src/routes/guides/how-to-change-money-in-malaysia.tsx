import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

const TITLE = "How to Change Money in Malaysia — A 2026 Traveller's Guide | KLXchange";
const DESC =
  "Step-by-step guide to exchanging foreign currency in Malaysia: where to go, what ID to bring, how to spot a licensed changer, and how to get the best RM rate in KL.";
const URL = "https://klxchange.com/guides/how-to-change-money-in-malaysia";

export const Route = createFileRoute("/guides/how-to-change-money-in-malaysia")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:url", content: URL },
      { property: "og:type", content: "article" },
    ],
    links: [{ rel: "canonical", href: URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: "How to Change Money in Malaysia — A 2026 Traveller's Guide",
          description: DESC,
          mainEntityOfPage: URL,
          author: { "@type": "Organization", name: "KLXchange" },
          publisher: { "@type": "Organization", name: "KLXchange" },
          datePublished: "2026-06-18",
          dateModified: "2026-06-18",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            { "@type": "ListItem", position: 1, name: "Home", item: "https://klxchange.com/" },
            { "@type": "ListItem", position: 2, name: "Guides", item: "https://klxchange.com/guides/how-to-change-money-in-malaysia" },
            { "@type": "ListItem", position: 3, name: "How to change money in Malaysia", item: URL },
          ],
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: [
            { "@type": "Question", name: "Where can I change money in Malaysia?", acceptedAnswer: { "@type": "Answer", text: "Licensed money changers (best rates), bank branches (convenient but worse rates), and airport counters at KLIA / KLIA2 (worst rates — only change enough for the taxi). Avoid hotel front desks and unlicensed kiosks." } },
            { "@type": "Question", name: "Is it better to change money in Malaysia or back home?", acceptedAnswer: { "@type": "Answer", text: "Almost always better in Malaysia. KL has one of the most competitive money-changer markets in Asia and spreads on USD, SGD, EUR and GBP are typically 0.5–1.5% — significantly tighter than at most banks abroad." } },
            { "@type": "Question", name: "Do I need to show ID to change money?", acceptedAnswer: { "@type": "Answer", text: "For transactions under RM 3,000 usually not, but bring your IC or passport anyway — under Bank Negara's AMLA rules, changers may request ID at their discretion and must for larger amounts." } },
            { "@type": "Question", name: "How do I know a money changer is licensed?", acceptedAnswer: { "@type": "Answer", text: "Look for the Bank Negara Malaysia licence sticker at the counter, a posted rate board, and printed receipts. Licensed changers are listed on Bank Negara's MSB register." } },
            { "@type": "Question", name: "Can I use credit card or QR pay instead?", acceptedAnswer: { "@type": "Answer", text: "Yes — DuitNow QR and Visa/Mastercard are accepted almost everywhere in KL, but card networks add a 2–3% FX markup. For amounts above a few hundred ringgit, cash from a money changer is usually cheaper." } },
          ],
        }),
      },
    ],
  }),
  component: Guide,
});

function Guide() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />

      <article className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <nav className="text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link> ›{" "}
          <span>Guides</span> ›{" "}
          <span className="text-foreground">How to change money in Malaysia</span>
        </nav>

        <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">
          How to change money in Malaysia
        </h1>
        <p className="mt-3 text-sm text-muted-foreground">
          Updated 18 June 2026 · 7 min read · by the KLXchange team
        </p>

        <p className="mt-6 text-lg text-muted-foreground">
          Malaysia is one of the cheapest places in Asia to exchange foreign currency — but only if
          you know where to go. This guide walks you through every option, what each typically
          costs, what ID to bring, and the small habits that save serious ringgit on a holiday or
          business trip.
        </p>

        <h2 className="mt-10 text-2xl font-bold">1. Your four options, ranked</h2>
        <p className="mt-3 text-muted-foreground">
          From best rate to worst, here's how Malaysians actually exchange currency:
        </p>
        <ol className="mt-3 list-decimal space-y-3 pl-6 text-muted-foreground">
          <li><strong>Licensed money changers</strong> — best rates, spreads of 0.5–1.5% on major currencies. Found in every mall: Mid Valley, Suria KLCC, Pavilion, Berjaya Times Square, Sungei Wang, 1 Utama, Sunway Pyramid.</li>
          <li><strong>Bank branches</strong> — convenient if you already have an account, but spreads are 1.5–2.5%. Maybank, CIMB, RHB and Public Bank all exchange cash at the counter.</li>
          <li><strong>KLIA / KLIA2 airport counters</strong> — worst rates of any legitimate option, often 3–4% off mid-market. Only change enough for the train into KL (RM 200–300 is plenty) and find a mall changer the next day.</li>
          <li><strong>Hotel front desks</strong> — avoid. Convenience pricing, 4–6% off mid-market is normal.</li>
        </ol>

        <h2 className="mt-10 text-2xl font-bold">2. How to spot a licensed money changer</h2>
        <p className="mt-3 text-muted-foreground">
          All money changers in Malaysia must be licensed by Bank Negara Malaysia (BNM) under the
          Money Services Business Act 2011. A legitimate counter will have:
        </p>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li>A BNM licence sticker visible at the counter</li>
          <li>A posted, public rate board for every currency they trade</li>
          <li>Printed receipts for every transaction (keep yours)</li>
          <li>Glass-fronted counter inside a mall or commercial building</li>
        </ul>
        <p className="mt-3 text-muted-foreground">
          If a "changer" operates from a hotel lobby, street stall, or doesn't issue receipts, walk away.
        </p>

        <h2 className="mt-10 text-2xl font-bold">3. What to bring</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li><strong>Your IC or passport.</strong> Most transactions under RM 3,000 don't require ID, but changers can ask at any amount, and must for larger exchanges under AMLA rules.</li>
          <li><strong>Clean, undamaged notes.</strong> Torn, written-on, or heavily folded foreign notes are often refused or accepted at a worse rate. USD pre-2006 series notes are sometimes refused outright.</li>
          <li><strong>Larger denominations.</strong> USD 100 and EUR 200/500 notes usually get a better rate than small bills.</li>
        </ul>

        <h2 className="mt-10 text-2xl font-bold">4. Timing matters</h2>
        <p className="mt-3 text-muted-foreground">
          Rates move during the day as the underlying FX market moves. A few practical rules:
        </p>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li>Most KL mall changers update their boards 2–4 times a day, usually at open, mid-morning and after lunch.</li>
          <li>Avoid Friday afternoons in conservative areas — many changers close for Jumaat prayers from 12:30–2:30pm.</li>
          <li>Public holidays = thinner markets and wider spreads. Change before or after the holiday if you can.</li>
          <li>For amounts above RM 10,000, call ahead — large transactions sometimes get a negotiated rate, but only if the changer has the cash on hand.</li>
        </ul>

        <h2 className="mt-10 text-2xl font-bold">5. Always compare before you walk in</h2>
        <p className="mt-3 text-muted-foreground">
          Two changers in the same mall can quote rates 1–3% apart for the same currency at the
          same minute. On a RM 5,000 exchange that's RM 50–150 left on the table. That's exactly
          what we built{" "}
          <Link to="/" className="font-semibold text-[oklch(0.48_0.22_258)] underline">KLXchange</Link>{" "}
          for — every changer's live board, sortable by best rate first. Five seconds of comparing
          can save you a nice meal.
        </p>

        <h2 className="mt-10 text-2xl font-bold">6. Card, cash, or DuitNow QR?</h2>
        <p className="mt-3 text-muted-foreground">
          Malaysia is increasingly cashless. DuitNow QR is everywhere, and Visa/Mastercard are
          accepted at almost every restaurant, hotel and shopping mall. But for tourists:
        </p>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li><strong>Cards</strong> usually add a 2–3% foreign-transaction fee plus the network's FX markup. Good for hotels and big-ticket items; expensive for small purchases.</li>
          <li><strong>Cash</strong> from a money changer beats card pricing by 1–2% in most cases — and you'll need it for hawker stalls, taxis, Grab-cash and night markets.</li>
          <li><strong>DuitNow QR</strong> needs a Malaysian bank account or a partnered foreign wallet (Alipay+, Touch 'n Go eWallet via TNG Global, some Korean and Thai wallets). Useful if you have it; not worth opening an account for a short trip.</li>
        </ul>
        <p className="mt-3 text-muted-foreground">
          A common split for a one-week KL trip: RM 1,500–2,000 in cash for street food, taxis and
          tips; card for hotels, malls and big restaurants.
        </p>

        <h2 className="mt-10 text-2xl font-bold">7. A few small habits that save real money</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li><strong>Never change at the airport beyond taxi money.</strong> KLIA Ekspres into KL Sentral is RM 55 — that's all you need to land with.</li>
          <li><strong>Walk past the first changer.</strong> In any mall there are 3–6 within 200 metres. Compare.</li>
          <li><strong>Count notes before leaving the counter.</strong> Mistakes happen; once you walk away it's your problem.</li>
          <li><strong>Keep your receipt.</strong> You'll need it to change unused RM back to your home currency on the way out.</li>
          <li><strong>Don't change MYR to USD inside Malaysia if you're flying somewhere else.</strong> RM is not a strong international currency — you'll lose 3–5% on the round trip.</li>
        </ul>

        <h2 className="mt-10 text-2xl font-bold">Frequently asked questions</h2>

        <div className="mt-6 space-y-5">
          <div>
            <h3 className="font-bold">Where can I change money in Malaysia?</h3>
            <p className="mt-1 text-muted-foreground">Licensed money changers (best rates), bank branches (convenient but worse rates), and airport counters at KLIA / KLIA2 (worst rates — only change enough for the taxi). Avoid hotel front desks and unlicensed kiosks.</p>
          </div>
          <div>
            <h3 className="font-bold">Is it better to change money in Malaysia or back home?</h3>
            <p className="mt-1 text-muted-foreground">Almost always better in Malaysia. KL has one of the most competitive money-changer markets in Asia, with typical spreads of 0.5–1.5% on USD, SGD, EUR and GBP — significantly tighter than at most banks abroad.</p>
          </div>
          <div>
            <h3 className="font-bold">Do I need to show ID to change money?</h3>
            <p className="mt-1 text-muted-foreground">For transactions under RM 3,000 usually not, but bring your IC or passport anyway — under Bank Negara's AMLA rules, changers may request ID at their discretion and must for larger amounts.</p>
          </div>
          <div>
            <h3 className="font-bold">How do I know a money changer is licensed?</h3>
            <p className="mt-1 text-muted-foreground">Look for the Bank Negara Malaysia licence sticker at the counter, a posted rate board, and printed receipts. Licensed changers are listed on Bank Negara's MSB register.</p>
          </div>
          <div>
            <h3 className="font-bold">Can I use credit card or QR pay instead?</h3>
            <p className="mt-1 text-muted-foreground">Yes — DuitNow QR and Visa/Mastercard are accepted almost everywhere in KL, but card networks add a 2–3% FX markup. For amounts above a few hundred ringgit, cash from a money changer is usually cheaper.</p>
          </div>
        </div>

        <div className="mt-12 rounded-2xl border border-border bg-secondary/40 p-6">
          <h3 className="text-lg font-bold">Ready to compare?</h3>
          <p className="mt-2 text-muted-foreground">
            See live buy and sell rates from 50+ licensed money changers across KL, Mid Valley,
            KLCC and PJ — updated every few minutes.
          </p>
          <Link
            to="/"
            className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[oklch(0.48_0.22_258)] px-5 py-3 text-sm font-bold text-white hover:bg-[oklch(0.42_0.22_258)]"
          >
            View live rates →
          </Link>
        </div>

        <p className="mt-10 text-xs text-muted-foreground">
          Disclaimer: This article is general information for travellers, not financial advice.
          Rates and regulations can change — always confirm at the counter and check Bank Negara
          Malaysia for current rules.
        </p>
      </article>

      <SiteFooter />
    </div>
  );
}