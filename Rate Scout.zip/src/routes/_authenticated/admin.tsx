import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { SiteHeader } from "@/components/SiteHeader";
import { AREAS } from "@/lib/changers";
import {
  deleteChanger,
  getMyRole,
  ingestRates,
  listAdminChangers,
  upsertChanger,
} from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin — KL EXCHANGE" }] }),
  component: AdminPage,
});

type ChangerRow = {
  id: string;
  slug: string;
  name: string;
  area: string;
  address: string;
  phone: string;
  hours: string;
  website: string | null;
  rate_source_kind: "csv" | "klmc" | "auto" | "json" | "antaraduit" | "eglobex" | "infinity" | "saujana" | "gsheet" | "moneywave";
  rate_source_url: string | null;
  rate_json_mapping: { list: string; code: string; unit?: string; buy: string; sell: string } | null;
};

function AdminPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fetchRole = useServerFn(getMyRole);
  const fetchList = useServerFn(listAdminChangers);
  const callUpsert = useServerFn(upsertChanger);
  const callDelete = useServerFn(deleteChanger);
  const callIngest = useServerFn(ingestRates);

  const { data: roleData, isLoading: roleLoading } = useQuery({
    queryKey: ["my-role"],
    queryFn: () => fetchRole(),
  });
  const { data: list, refetch } = useQuery({
    queryKey: ["admin-changers"],
    queryFn: () => fetchList(),
    enabled: !!roleData?.isAdmin,
  });

  const [editing, setEditing] = useState<Partial<ChangerRow> | null>(null);
  const [csvText, setCsvText] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  if (roleLoading) return <Shell><p className="p-8">Loading…</p></Shell>;
  if (!roleData?.isAdmin) {
    return (
      <Shell>
        <div className="p-8">
          <h1 className="text-2xl font-bold">Access denied</h1>
          <p className="mt-2 text-muted-foreground">
            Your account does not have admin role. The first user to sign up becomes admin automatically.
          </p>
          <button onClick={signOut} className="mt-4 underline">Sign out</button>
        </div>
      </Shell>
    );
  }

  async function saveChanger(e: React.FormEvent) {
    e.preventDefault();
    if (!editing) return;
    console.log("[admin] saveChanger fired", editing);
    setBusy(true);
    setMsg(null);
    try {
      const payload = {
        id: editing.id,
        slug: editing.slug!,
        name: editing.name!,
        area: editing.area!,
        address: editing.address ?? "",
        phone: editing.phone ?? "",
        hours: editing.hours ?? "",
        website: editing.website || null,
        rating: 0,
        reviews: 0,
        rate_source_kind: editing.rate_source_kind ?? "csv",
        rate_source_url: editing.rate_source_url || null,
        rate_json_mapping: editing.rate_json_mapping ?? null,
      };
      const { id } = await callUpsert({ data: payload });
      console.log("[admin] upserted", id);
      if (csvText.trim() && payload.rate_source_kind === "csv") {
        const out = await callIngest({ data: { changerId: id, csv: csvText } });
        setMsg(`Saved. ${out.count} rates loaded.`);
      } else if (payload.rate_source_kind !== "csv") {
        try {
          const out = await callIngest({ data: { changerId: id } });
          setMsg(`Saved. ${out.count} rates pulled from URL.`);
        } catch (ingestErr) {
          // Save succeeded; only the rate pull failed. Keep the changer and surface the reason.
          setMsg(
            `Saved, but rate pull failed: ${
              ingestErr instanceof Error ? ingestErr.message : "unknown"
            }. Try "Refresh" on the row or change the rate source.`,
          );
        }
      } else {
        setMsg("Saved.");
      }
      setEditing(null);
      setCsvText("");
      refetch();
    } catch (e) {
      console.error("[admin] save failed", e);
      setMsg(e instanceof Error ? e.message : "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function refreshRates(id: string) {
    setBusy(true);
    setMsg(null);
    try {
      const out = await callIngest({ data: { changerId: id } });
      setMsg(`Refreshed: ${out.count} rates.`);
      refetch();
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Refresh failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("Delete this changer?")) return;
    await callDelete({ data: { id } });
    refetch();
  }

  const changers = (list?.changers ?? []) as unknown as ChangerRow[];
  const ratesByChanger = new Map<string, number>();
  for (const r of (list?.rates ?? []) as Array<{ changer_id: string }>) {
    ratesByChanger.set(r.changer_id, (ratesByChanger.get(r.changer_id) ?? 0) + 1);
  }

  return (
    <Shell>
      <div className="mx-auto max-w-5xl px-4 py-10">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Admin · Money Changers</h1>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() =>
              {
                setEditing({ slug: "", name: "", area: AREAS[0], rate_source_kind: "csv" });
                setCsvText("");
                setMsg(null);
                setTimeout(() => {
                  document
                    .getElementById("changer-form")
                    ?.scrollIntoView({ behavior: "smooth", block: "start" });
                }, 50);
              }
              }
              className="rounded-lg bg-foreground px-4 py-2 text-sm font-semibold text-background"
            >
              + Add changer
            </button>
            <button type="button" onClick={signOut} className="text-sm text-muted-foreground underline">
              Sign out
            </button>
          </div>
        </div>
        {msg && <p className="mt-3 text-sm">{msg}</p>}
        {msg && /AI_CREDITS_EXHAUSTED/.test(msg) && (
          <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900">
            <div className="font-semibold">AI credits exhausted</div>
            <p className="mt-1">
              The AI-powered rate extractor is temporarily unavailable because the workspace has run out of Lovable AI credits.
            </p>
            <ul className="mt-2 list-disc pl-5">
              <li>Top up in <span className="font-medium">Settings → Workspace → Plans &amp; Credits</span>, then click Refresh.</li>
              <li>Or switch this changer's rate source to CSV / a direct scraper (klmc, antaraduit, eglobex, infinity, saujana, gsheet, json) to avoid AI.</li>
              <li>Other changers using non-AI sources will keep refreshing normally.</li>
            </ul>
          </div>
        )}
        {msg && /AI_RATE_LIMITED/.test(msg) && (
          <div className="mt-3 rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900">
            <div className="font-semibold">AI service is busy</div>
            <p className="mt-1">Too many requests right now. Wait a moment and try Refresh again.</p>
          </div>
        )}

        <div className="mt-6 divide-y divide-border rounded-xl border border-border bg-card">
          {changers.length === 0 && (
            <p className="p-6 text-sm text-muted-foreground">No DB changers yet. Click "Add changer".</p>
          )}
          {changers.map((c) => (
            <div key={c.id} className="flex items-center justify-between gap-4 p-4">
              <div className="min-w-0">
                <div className="font-semibold">{c.name}</div>
                <div className="text-xs text-muted-foreground">
                  {c.area} · {c.slug} · {ratesByChanger.get(c.id) ?? 0} rates · {c.rate_source_kind}
                </div>
              </div>
              <div className="flex flex-shrink-0 gap-2 text-sm">
                <button type="button" onClick={() => refreshRates(c.id)} disabled={busy} className="underline">Refresh</button>
                <button type="button" onClick={() => { setEditing(c); setCsvText(""); setTimeout(() => document.getElementById("changer-form")?.scrollIntoView({ behavior: "smooth", block: "start" }), 50); }} className="underline">Edit</button>
                <button type="button" onClick={() => remove(c.id)} className="text-destructive underline">Delete</button>
              </div>
            </div>
          ))}
        </div>

        {editing && (
          <form id="changer-form" onSubmit={saveChanger} className="mt-8 space-y-4 rounded-xl border border-border bg-card p-6">
            <h2 className="text-xl font-bold">{editing.id ? "Edit" : "New"} changer</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Slug (unique, lowercase-dashes)">
                <input required value={editing.slug ?? ""}
                  onChange={(e) => setEditing({
                    ...editing,
                    slug: e.target.value
                      .toLowerCase()
                      .replace(/[^a-z0-9-]+/g, "-")
                      .replace(/-+/g, "-")
                      .replace(/^-|-$/g, ""),
                  })}
                  className={inputCls} />
              </Field>
              <Field label="Name">
                <input required value={editing.name ?? ""}
                  onChange={(e) => setEditing({ ...editing, name: e.target.value })}
                  className={inputCls} />
              </Field>
              <Field label="Area">
                <input
                  list="area-suggestions"
                  value={editing.area ?? ""}
                  onChange={(e) => setEditing({ ...editing, area: e.target.value })}
                  placeholder="Pick or type a new area"
                  className={inputCls}
                />
                <datalist id="area-suggestions">
                  {AREAS.map((a) => <option key={a} value={a} />)}
                </datalist>
              </Field>
              <Field label="Phone">
                <input value={editing.phone ?? ""}
                  onChange={(e) => setEditing({ ...editing, phone: e.target.value })}
                  className={inputCls} />
              </Field>
              <Field label="Address">
                <input value={editing.address ?? ""}
                  onChange={(e) => setEditing({ ...editing, address: e.target.value })}
                  className={inputCls} />
              </Field>
              <Field label="Hours">
                <input value={editing.hours ?? ""}
                  onChange={(e) => setEditing({ ...editing, hours: e.target.value })}
                  className={inputCls} />
              </Field>
              <Field label="Website (optional)">
                <input type="url" value={editing.website ?? ""}
                  onChange={(e) => setEditing({ ...editing, website: e.target.value })}
                  className={inputCls} />
              </Field>
              <Field label="Rate source">
                <select value={editing.rate_source_kind ?? "csv"}
                  onChange={(e) => setEditing({ ...editing, rate_source_kind: e.target.value as ChangerRow["rate_source_kind"] })}
                  className={inputCls}>
                  <option value="csv">CSV (manual paste)</option>
                  <option value="auto">Auto-extract from any website (AI)</option>
                  <option value="klmc">Pull from klmoneychanger URL</option>
                  <option value="antaraduit">Pull from Antaraduit (use ?val=1|3|4)</option>
                  <option value="eglobex">Pull from E-Globex (/rates or /timessquare)</option>
                  <option value="infinity">Pull from Infinity Exchange</option>
                  <option value="saujana">Pull from Saujana Hirisan (use ?branch_id=11|12|13)</option>
                  <option value="moneywave">Pull from Moneywave (?branch=pandan|midvalley|…)</option>
                  <option value="gsheet">Google Sheet (paste shareable URL)</option>
                  <option value="json">Custom JSON endpoint</option>
                </select>
              </Field>
            </div>

            {editing.rate_source_kind === "csv" && (
              <Field label="CSV rates (code,unit,buy,sell — one per line)">
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="file"
                      accept=".csv,text/csv"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const text = await file.text();
                        setCsvText(text);
                        setMsg(`Loaded ${file.name} (${text.split(/\r?\n/).filter(Boolean).length} rows).`);
                        e.target.value = "";
                      }}
                      className="text-xs"
                    />
                    {csvText && (
                      <button
                        type="button"
                        onClick={() => setCsvText("")}
                        className="text-xs text-muted-foreground underline"
                      >
                        Clear
                      </button>
                    )}
                  </div>
                  <textarea rows={6} value={csvText} onChange={(e) => setCsvText(e.target.value)}
                    placeholder={"USD,1,4.71,4.75\nSGD,1,3.49,3.52\nJPY,100,3.05,3.10"}
                    className={inputCls + " font-mono text-xs"} />
                  <p className="text-[11px] text-muted-foreground">
                    Upload a .csv file or paste rows directly. Header row is optional.
                  </p>
                </div>
              </Field>
            )}

            {(editing.rate_source_kind === "klmc" ||
              editing.rate_source_kind === "auto" ||
              editing.rate_source_kind === "antaraduit" ||
              editing.rate_source_kind === "eglobex" ||
              editing.rate_source_kind === "infinity" ||
              editing.rate_source_kind === "saujana" ||
              editing.rate_source_kind === "moneywave" ||
              editing.rate_source_kind === "gsheet" ||
              editing.rate_source_kind === "json") && (
              <Field
                label={
                  editing.rate_source_kind === "gsheet"
                    ? "Google Sheet URL (must be shared 'Anyone with the link can view'). Columns: code, [unit,] buy, sell"
                    : "Source URL"
                }
              >
                <input type="url" required value={editing.rate_source_url ?? ""}
                  onChange={(e) => setEditing({ ...editing, rate_source_url: e.target.value })}
                  placeholder={
                    editing.rate_source_kind === "gsheet"
                      ? "https://docs.google.com/spreadsheets/d/.../edit#gid=0"
                      : undefined
                  }
                  className={inputCls} />
              </Field>
            )}

            {editing.rate_source_kind === "json" && (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-5">
                {(["list", "code", "unit", "buy", "sell"] as const).map((k) => (
                  <Field key={k} label={`JSON path: ${k}`}>
                    <input value={editing.rate_json_mapping?.[k] ?? ""}
                      placeholder={k === "list" ? "data.rates" : k}
                      onChange={(e) =>
                        setEditing({
                          ...editing,
                          rate_json_mapping: {
                            list: editing.rate_json_mapping?.list ?? "",
                            code: editing.rate_json_mapping?.code ?? "",
                            unit: editing.rate_json_mapping?.unit ?? "",
                            buy: editing.rate_json_mapping?.buy ?? "",
                            sell: editing.rate_json_mapping?.sell ?? "",
                            [k]: e.target.value,
                          },
                        })
                      }
                      className={inputCls} />
                  </Field>
                ))}
              </div>
            )}

            <div className="flex gap-2">
              <button type="submit" disabled={busy}
                className="rounded-lg bg-foreground px-4 py-2 font-semibold text-background disabled:opacity-50">
                {busy ? "Saving…" : "Save"}
              </button>
              <button type="button" onClick={() => setEditing(null)} className="text-sm underline">
                Cancel
              </button>
            </div>
          </form>
        )}
      </div>
    </Shell>
  );
}

const inputCls = "w-full rounded-lg border border-border bg-background px-3 py-2 text-sm";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>{children}</main>
    </div>
  );
}