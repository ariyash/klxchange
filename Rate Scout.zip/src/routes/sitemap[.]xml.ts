import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";
import { CHANGERS } from "@/lib/changers";

const BASE_URL = "https://klxchange.com";

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const entries = [
          { path: "/", changefreq: "hourly", priority: "1.0" },
          { path: "/changers", changefreq: "daily", priority: "0.8" },
          { path: "/about", changefreq: "monthly", priority: "0.6" },
          { path: "/methodology", changefreq: "monthly", priority: "0.6" },
          { path: "/contact", changefreq: "monthly", priority: "0.5" },
          { path: "/privacy", changefreq: "yearly", priority: "0.3" },
          { path: "/terms", changefreq: "yearly", priority: "0.3" },
          { path: "/guides/mid-valley", changefreq: "weekly", priority: "0.7" },
          { path: "/guides/how-to-change-money-in-malaysia", changefreq: "monthly", priority: "0.7" },
          { path: "/guides/best-usd-rate-in-kl", changefreq: "weekly", priority: "0.8" },
          { path: "/guides/sending-money-to-philippines-from-malaysia", changefreq: "monthly", priority: "0.7" },
          { path: "/guides/klia-airport-money-changer-guide", changefreq: "monthly", priority: "0.7" },
          ...CHANGERS.map((c) => ({ path: `/changer/${c.slug}`, changefreq: "daily", priority: "0.6" })),
        ];
        const urls = entries.map(
          (e) =>
            `  <url>\n    <loc>${BASE_URL}${e.path}</loc>\n    <changefreq>${e.changefreq}</changefreq>\n    <priority>${e.priority}</priority>\n  </url>`,
        );
        const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>`;
        return new Response(xml, {
          headers: { "Content-Type": "application/xml", "Cache-Control": "public, max-age=3600" },
        });
      },
    },
  },
});