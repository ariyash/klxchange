import { createFileRoute } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact KLXchange — Get In Touch" },
      { name: "description", content: "Contact KLXchange to report a wrong rate, request a listing, or get in touch about partnerships and advertising." },
      { property: "og:title", content: "Contact KLXchange" },
      { property: "og:description", content: "Reach the KLXchange team about rates, listings or partnerships." },
      { property: "og:url", content: "https://klxchange.com/contact" },
    ],
    links: [{ rel: "canonical", href: "https://klxchange.com/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Contact us</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Questions, corrections, listings or partnerships — we read every email.
        </p>

        <div className="mt-10 space-y-6">
          <div className="rounded-2xl border border-border bg-card p-6">
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">General enquiries</h2>
            <p className="mt-2 text-lg font-semibold">
              <a href="mailto:hello@klxchange.com" className="text-[oklch(0.48_0.22_258)] underline">hello@klxchange.com</a>
            </p>
            <p className="mt-1 text-sm text-muted-foreground">We typically reply within 1–2 business days.</p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6">
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Report a wrong rate</h2>
            <p className="mt-2 text-base">
              Email <a href="mailto:rates@klxchange.com" className="font-semibold text-[oklch(0.48_0.22_258)] underline">rates@klxchange.com</a>{" "}
              with the changer name, currency, and what the counter rate actually was. A screenshot of the counter board helps.
            </p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6">
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">List your money changer</h2>
            <p className="mt-2 text-base">
              Run a licensed money changer in the Klang Valley? Visit our{" "}
              <a href="/publish-rate" className="font-semibold text-[oklch(0.48_0.22_258)] underline">Publish Your Rate</a>{" "}
              page or email <a href="mailto:listings@klxchange.com" className="font-semibold text-[oklch(0.48_0.22_258)] underline">listings@klxchange.com</a>.
            </p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-6">
            <h2 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Advertising</h2>
            <p className="mt-2 text-base">
              For sponsorships and display advertising:{" "}
              <a href="mailto:ads@klxchange.com" className="font-semibold text-[oklch(0.48_0.22_258)] underline">ads@klxchange.com</a>.
            </p>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  );
}