import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/public/hooks/refresh-rates")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env.CRON_SECRET;
        if (secret) {
          const authHeader = request.headers.get("authorization") ?? "";
          if (authHeader !== `Bearer ${secret}`) {
            return new Response(
              JSON.stringify({ ok: false, error: "Unauthorized" }),
              { status: 401, headers: { "Content-Type": "application/json" } },
            );
          }
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const {
          scrapeAntaraduit,
          scrapeAuto,
          scrapeEglobex,
          scrapeInfinity,
          scrapeKlmc,
          scrapeKlremit,
          scrapeSaujana,
          scrapeMsFirestore,
          scrapeGsheet,
          scrapeMoneywave,
          normalizeRateScale,
        } = await import("@/lib/scraper.server");

        const { data: changers, error } = await supabaseAdmin
          .from("changers" as never)
          .select("id, slug, rate_source_kind, rate_source_url");
        if (error) {
          return new Response(JSON.stringify({ ok: false, error: error.message }), {
            status: 500,
            headers: { "Content-Type": "application/json" },
          });
        }

        const rows = (changers ?? []) as unknown as Array<{
          id: string;
          slug: string;
          rate_source_kind: string;
          rate_source_url: string | null;
        }>;

        const results = await Promise.all(
          rows.map(async (c) => {
            if (!c.rate_source_url || c.rate_source_kind === "csv") {
              return { slug: c.slug, skipped: true } as const;
            }
            try {
              const list: Awaited<ReturnType<typeof scrapeKlmc>> =
                c.rate_source_kind === "klmc"
                  ? await scrapeKlmc(c.rate_source_url)
                  : c.rate_source_kind === "klremit"
                    ? await scrapeKlremit(c.rate_source_url)
                    : c.rate_source_kind === "antaraduit"
                      ? await scrapeAntaraduit(c.rate_source_url)
                      : c.rate_source_kind === "eglobex"
                        ? await scrapeEglobex(c.rate_source_url)
                        : c.rate_source_kind === "infinity"
                          ? await scrapeInfinity(c.rate_source_url)
                          : c.rate_source_kind === "auto"
                            ? await scrapeAuto(c.rate_source_url)
                            : c.rate_source_kind === "saujana"
                              ? await scrapeSaujana(c.rate_source_url)
                                : c.rate_source_kind === "ms_firestore"
                                  ? await scrapeMsFirestore(c.rate_source_url)
                                  : c.rate_source_kind === "gsheet"
                                    ? await scrapeGsheet(c.rate_source_url)
                                    : c.rate_source_kind === "moneywave"
                                      ? await scrapeMoneywave(c.rate_source_url)
                                      : [];
              const normalized = list.map((r) => normalizeRateScale(r));
              if (normalized.length === 0)
                return { slug: c.slug, count: 0, kind: c.rate_source_kind } as const;
              const now = new Date().toISOString();
              const currentCodes = [...new Set(normalized.map((r) => r.code))];
              const upserts = normalized.map((r) => ({
                changer_id: c.id,
                code: r.code,
                unit: r.unit,
                buy: r.buy,
                sell: r.sell,
                updated_at: now,
              }));
              const { error: upErr } = await supabaseAdmin
                .from("changer_rates" as never)
                .upsert(upserts as never, { onConflict: "changer_id,code" });
              if (upErr) throw new Error(upErr.message);
              const { error: deleteErr } = await supabaseAdmin
                .from("changer_rates" as never)
                .delete()
                .eq("changer_id", c.id as never)
                .not("code", "in", `("${currentCodes.join('","')}")`);
              if (deleteErr) throw new Error(deleteErr.message);
              return { slug: c.slug, count: normalized.length, prunedMissing: true } as const;
            } catch (e) {
              return {
                slug: c.slug,
                error: e instanceof Error ? e.message : String(e),
              } as const;
            }
          }),
        );

        return new Response(
          JSON.stringify({ ok: true, at: new Date().toISOString(), results }),
          { headers: { "Content-Type": "application/json" } },
        );
      },
    },
  },
});