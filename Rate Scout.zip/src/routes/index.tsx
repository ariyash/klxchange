import { createFileRoute } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";
import { Converter } from "@/components/Converter";
import { RateTable } from "@/components/RateTable";
import { CurrencyGrid } from "@/components/CurrencyGrid";
import { CHANGERS } from "@/lib/changers";
import klMap from "@/assets/kl-map.jpg";
import { AdSlot } from "@/components/AdSlot";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "KL EXCHANGE — Compare KL Money Changer Rates Live" },
      { name: "description", content: "Compare live KL money changer rates. Best USD, SGD, EUR, GBP, JPY buy/sell from changers across KL, Mid Valley, KLCC and PJ." },
      { property: "og:title", content: "KL EXCHANGE — Compare KL Money Changer Rates Live" },
      { property: "og:description", content: "Live buy/sell rates from authorized money changers across KL, Mid Valley, KLCC and PJ." },
      { property: "og:url", content: "https://klxchange.com/" },
    ],
    links: [
      { rel: "canonical", href: "https://klxchange.com/" },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "KL EXCHANGE",
          url: "https://klxchange.com/",
          potentialAction: {
            "@type": "SearchAction",
            target: "https://klxchange.com/changers?q={search_term_string}",
            "query-input": "required name=search_term_string",
          },
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "KL EXCHANGE",
          url: "https://klxchange.com/",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "FAQPage",
          mainEntity: [
            { "@type": "Question", name: "How often are the rates updated?", acceptedAnswer: { "@type": "Answer", text: "Every 1–3 minutes for active changers. Each row carries its own last-updated timestamp." } },
            { "@type": "Question", name: "Are the rates on KLXchange the actual counter rates?", acceptedAnswer: { "@type": "Answer", text: "They are pulled directly from each changer's published source. The final counter rate may vary by denomination and liquidity — always confirm before transacting." } },
            { "@type": "Question", name: "Which money changer in KL gives the best rate?", acceptedAnswer: { "@type": "Answer", text: "It depends on the currency. KLXchange sorts every changer by best RM-per-unit, so the winner for your specific currency is always at the top." } },
            { "@type": "Question", name: "Is KLXchange a money changer?", acceptedAnswer: { "@type": "Answer", text: "No. KLXchange is an independent comparison site. We do not handle any currency or funds." } },
            { "@type": "Question", name: "Do I need to bring my IC or passport?", acceptedAnswer: { "@type": "Answer", text: "Under Bank Negara's AMLA rules, changers may request ID for larger exchanges. Bringing your IC or passport is recommended." } },
          ],
        }),
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />

      {/* Top banner — all breakpoints */}
      <AdSlot className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-3" />

      <header className="border-b border-border bg-secondary/40 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2 lg:items-center">
            <div>
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
                KL's Best Rates,
                <br />
                <span className="text-[oklch(0.55_0.20_255)]">Found in Seconds.</span>
              </h1>
              <p className="mt-4 max-w-lg text-lg text-muted-foreground">
                Real-time buy and sell rates from 50+ authorized money changers across Kuala Lumpur, Mid Valley, and KLCC.
              </p>
              <a
                href="#rate-table"
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById("rate-table")?.scrollIntoView({ behavior: "smooth", block: "start" });
                }}
                className="mt-6 inline-flex items-center gap-2 rounded-lg bg-[oklch(0.48_0.22_258)] px-5 py-3 text-sm font-bold text-white shadow-sm transition-colors hover:bg-[oklch(0.42_0.22_258)]"
              >
                Compare Live Rates →
              </a>
            </div>
            <Converter />
          </div>
        </div>
      </header>

      <CurrencyGrid />

      {/* Mobile-only in-feed ad after currency grid */}
      <AdSlot
        variant="fluid"
        className="mx-auto block max-w-7xl px-4 py-4 sm:hidden"
      />
      {/* Desktop/tablet banner after currency grid */}
      <AdSlot className="mx-auto hidden max-w-7xl px-4 py-6 sm:block sm:px-6 lg:px-8" />

      <main>
      <section className="mx-auto max-w-3xl px-4 pt-8 sm:px-6 lg:px-8">
        <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">
          Compare live money changer rates in Kuala Lumpur
        </h2>
        <p className="mt-3 text-muted-foreground">
          KLXchange tracks live buy and sell rates from 50+ authorized money changers across Kuala
          Lumpur, Mid Valley, KLCC, Bukit Bintang and Petaling Jaya — refreshed every few minutes
          directly from each merchant's own published source. Whether you're heading on holiday,
          sending money home, or just landed at KLIA, you can see who's offering the best rate today
          for USD, SGD, EUR, GBP, JPY, AUD, THB, IDR, PHP and 40+ other currencies before you walk
          into the shop.
        </p>
        <p className="mt-3 text-muted-foreground">
          Rates between two changers in the same mall can vary by 1–3% — on a RM 5,000 exchange
          that's RM 50–150 left on the table. We rank purely by best rate first, with no paid
          placements. See our{" "}
          <a href="/methodology" className="font-semibold text-[oklch(0.48_0.22_258)] underline">methodology</a>{" "}
          for exactly how we collect and verify the data.
        </p>
      </section>

      <RateTable />

      <AdSlot
        variant="fluid"
        className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-6"
      />

      <section id="locations" className="bg-background py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8">
            <div>
              <h3 className="mb-6 text-xl font-bold">Map View</h3>
              <div className="relative h-[400px] overflow-hidden rounded-2xl border border-border bg-secondary">
                <img src={klMap} alt="Kuala Lumpur money changer map" loading="lazy" width={800} height={1024} className="h-full w-full object-cover" />
                <div className="absolute bottom-4 left-4 right-4 rounded-lg border border-border bg-card p-3 shadow-lg">
                  <p className="text-xs font-bold">{CHANGERS.length} changers tracked across KL</p>
                  <p className="text-[10px] text-muted-foreground">Prices updated 1 minute ago</p>
                </div>
              </div>
              {/* Sidebar ad — desktop */}
              <AdSlot className="mt-6 hidden lg:block" />
            </div>
          </div>
        </div>
      </section>

      <section className="bg-secondary/30 py-12">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Frequently asked questions</h2>
          <div className="mt-6 space-y-5">
            <div>
              <h3 className="font-bold">How often are the rates updated?</h3>
              <p className="mt-1 text-muted-foreground">Every 1–3 minutes for active changers. Each row shows its own "Last updated" timestamp so you can see exactly how fresh the number is.</p>
            </div>
            <div>
              <h3 className="font-bold">Are the rates on KLXchange the actual counter rates?</h3>
              <p className="mt-1 text-muted-foreground">They come directly from each changer's own published source, so they're as close as you'll get without walking in. The counter rate can still vary by note denomination, customer profile and current liquidity — always confirm before transacting.</p>
            </div>
            <div>
              <h3 className="font-bold">Which money changer in KL gives the best rate?</h3>
              <p className="mt-1 text-muted-foreground">It depends on the currency and the time of day. That's why we built KLXchange — instead of one "best" answer, the rate table sorts every changer by RM-per-unit so the winner for your specific currency is always at the top.</p>
            </div>
            <div>
              <h3 className="font-bold">Is KLXchange a money changer?</h3>
              <p className="mt-1 text-muted-foreground">No. KLXchange is an independent comparison site. We don't handle any currency or funds — all transactions happen directly between you and the licensed money changer you choose to visit.</p>
            </div>
            <div>
              <h3 className="font-bold">Do I need to bring my IC or passport?</h3>
              <p className="mt-1 text-muted-foreground">For most transactions under RM 3,000 you don't, but bring it anyway — under Bank Negara's AMLA rules changers may request ID for larger exchanges or at their discretion.</p>
            </div>
            <div>
              <h3 className="font-bold">Why do rates between changers in the same mall differ?</h3>
              <p className="mt-1 text-muted-foreground">Each changer sets its own spread based on its currency inventory, location costs and target customer. Differences of 1–3% on major currencies are common.</p>
            </div>
          </div>
        </div>
      </section>
      </main>

      <SiteFooter />
    </div>
  );
}
