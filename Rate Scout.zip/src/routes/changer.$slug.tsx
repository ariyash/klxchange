import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";
import { CurrencyFlag } from "@/components/CurrencyFlag";
import { getChanger, type MoneyChanger, type Area } from "@/lib/changers";
import { getLiveRates } from "@/lib/rates.functions";
import { getDbChangers } from "@/lib/db-changers.functions";

export const Route = createFileRoute("/changer/$slug")({
  head: ({ params }) => {
    const c = getChanger(params.slug);
    const title = c ? `${c.name} — Live Rates & Location | KL EXCHANGE` : "Money Changer";
    const desc = c
      ? `Live currency exchange rates, address, hours and contact for ${c.name} in ${c.area}.`
      : "Money changer profile.";
    const url = `https://klxchange.com/changer/${params.slug}`;
    return {
      meta: [
        { title },
        { name: "description", content: desc },
        { property: "og:title", content: title },
        { property: "og:description", content: desc },
        { property: "og:url", content: url },
        { property: "og:type", content: "business.business" },
      ],
      links: [{ rel: "canonical", href: url }],
      scripts: c
        ? [
            {
              type: "application/ld+json",
              children: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "LocalBusiness",
                name: c.name,
                address: {
                  "@type": "PostalAddress",
                  streetAddress: c.address,
                  addressLocality: c.area,
                  addressCountry: "MY",
                },
                telephone: c.phone,
                openingHours: c.hours,
                aggregateRating: {
                  "@type": "AggregateRating",
                  ratingValue: c.rating,
                  reviewCount: c.reviews,
                },
                url,
              }),
            },
            {
              type: "application/ld+json",
              children: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "FAQPage",
                mainEntity: [
                  { "@type": "Question", name: `What currencies does ${c.name} exchange?`, acceptedAnswer: { "@type": "Answer", text: `${c.name} typically handles major currencies including USD, SGD, EUR, GBP, JPY, AUD and most ASEAN currencies. Live availability and today's buy/sell rates are listed on this page.` } },
                  { "@type": "Question", name: `What are ${c.name}'s opening hours?`, acceptedAnswer: { "@type": "Answer", text: c.hours } },
                  { "@type": "Question", name: `Where is ${c.name} located?`, acceptedAnswer: { "@type": "Answer", text: `${c.name} is at ${c.address}, in ${c.area}.` } },
                  { "@type": "Question", name: `Is ${c.name} licensed?`, acceptedAnswer: { "@type": "Answer", text: `${c.name} is a money services business operating in Malaysia. All licensed money changers in Malaysia are regulated by Bank Negara Malaysia under the Money Services Business Act 2011.` } },
                  { "@type": "Question", name: `Are the rates shown on KLXchange the same as at the counter?`, acceptedAnswer: { "@type": "Answer", text: `Rates are pulled live from the merchant's published source and refreshed every few minutes. The final counter rate may differ slightly based on note denomination and current liquidity — always confirm before transacting.` } },
                ],
              }),
            },
          ]
        : [],
    };
  },
  loader: async ({ params }) => {
    const seed = getChanger(params.slug);
    if (seed) return seed;
    const { changers } = await getDbChangers();
    const db = changers.find((c) => c.slug === params.slug);
    if (!db) throw notFound();
    const c: MoneyChanger = {
      slug: db.slug,
      name: db.name,
      area: db.area as Area,
      address: db.address,
      hours: db.hours,
      phone: db.phone,
      rating: Number(db.rating) || 0,
      reviews: db.reviews,
      source:
        db.rate_source_kind === "klmc" && db.rate_source_url
          ? { kind: "klmc", url: db.rate_source_url }
          : { kind: "placid", branch: db.slug },
    };
    return c;
  },
  notFoundComponent: () => (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="text-3xl font-bold">Money changer not found</h1>
        <Link to="/" className="mt-6 inline-block font-semibold text-[oklch(0.55_0.20_255)]">
          ← Back to all rates
        </Link>
      </div>
    </div>
  ),
  errorComponent: ({ error }) => (
    <div className="p-12 text-center text-destructive">{error.message}</div>
  ),
  component: ChangerPage,
});

function ChangerPage() {
  const changer = Route.useLoaderData();
  const fetchRates = useServerFn(getLiveRates);
  const { data: live, isFetching } = useQuery({
    queryKey: ["live-rates"],
    queryFn: () => fetchRates(),
    refetchInterval: 3_000,
    staleTime: 0,
  });

  const my = live?.[changer.slug];
  const rateRows = my ? Object.values(my.rates).sort((a, b) => a.code.localeCompare(b.code)) : [];
  const [search, setSearch] = useState("");
  const filteredRows = rateRows.filter((r) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return r.code.toLowerCase().includes(q) || r.name.toLowerCase().includes(q);
  });

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />

      <div className="border-b border-border bg-secondary/40">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
          <Link to="/" className="text-sm font-semibold text-muted-foreground hover:text-foreground">
            ← All rates
          </Link>
          <div className="mt-4 grid grid-cols-1 gap-8 lg:grid-cols-3 lg:items-start">
            <div className="lg:col-span-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[oklch(0.48_0.22_258)]">
                {changer.area}
              </span>
              <h1 className="mt-2 text-4xl font-bold tracking-tight sm:text-5xl">{changer.name}</h1>
              <p className="mt-3 max-w-2xl text-muted-foreground">{changer.address}</p>
              <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 text-sm">
                <span className="font-semibold">⭐ {changer.rating}/5 ({changer.reviews.toLocaleString()} reviews)</span>
                <span className="text-muted-foreground">{changer.hours}</span>
                <a href={`tel:${changer.phone.replace(/\s/g, "")}`} className="font-semibold text-[oklch(0.55_0.20_255)]">
                  {changer.phone}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <section className="mb-10 max-w-3xl">
          <h2 className="text-2xl font-bold tracking-tight">About {changer.name}</h2>
          <p className="mt-3 text-muted-foreground">
            {changer.name} is a licensed money changer based in {changer.area}, Kuala Lumpur. The
            counter at {changer.address} handles walk-in foreign currency exchange for travellers,
            expats and businesses across the Klang Valley, with live buy and sell rates listed
            below for every currency the branch trades today.
          </p>
          <p className="mt-3 text-muted-foreground">
            Rates on this page are pulled directly from {changer.name}'s own published source and
            refreshed continuously. They're indicative — the final rate at the counter may vary
            slightly by note denomination and current cash liquidity, so always confirm before
            transacting. Bring your IC or passport for larger amounts, as required under Bank
            Negara Malaysia's AMLA rules.
          </p>
        </section>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <div className="mb-4 flex items-center gap-3">
              <h2 className="text-xl font-bold">Today's Rates</h2>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-[oklch(0.95_0.05_255)] px-2 py-0.5 text-[10px] font-bold uppercase text-[oklch(0.40_0.20_258)]">
                <span className={`h-1.5 w-1.5 rounded-full bg-[oklch(0.48_0.22_258)] ${isFetching ? "animate-pulse" : ""}`} />
                Live
              </span>
            </div>
            <div className="mb-4">
              <label htmlFor="currency-search" className="sr-only">Search currency</label>
              <input
                id="currency-search"
                type="search"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search currency (e.g. USD, Euro, Yen)"
                className="w-full rounded-lg border border-border bg-card px-3 py-2 text-sm text-[oklch(0.48_0.22_258)] placeholder:text-[oklch(0.48_0.22_258)]/60 focus:border-[oklch(0.55_0.20_255)] focus:outline-none focus:ring-1 focus:ring-[oklch(0.55_0.20_255)]"
              />
            </div>
            {my?.error && (
              <div className="mb-3 rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-xs text-destructive">
                Couldn't fetch rates: {my.error}
              </div>
            )}
            {/* Desktop / tablet table */}
            <div className="hidden overflow-hidden rounded-xl border border-border bg-card md:block" style={{ fontFamily: "Arial, sans-serif" }}>
              <table className="w-full text-left">
                <thead className="bg-secondary text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-6 py-4">Currency</th>
                    <th className="px-6 py-4 text-right">Unit</th>
                    <th className="px-6 py-4 text-right">Buy (RM)</th>
                    <th className="px-6 py-4 text-right">Sell (RM)</th>
                    <th className="px-6 py-4 text-right">Last Updated</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {rateRows.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-sm text-muted-foreground">
                        Loading live rates…
                      </td>
                    </tr>
                  )}
                  {rateRows.length > 0 && filteredRows.length === 0 && (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-sm text-muted-foreground">
                        No currencies match "{search}".
                      </td>
                    </tr>
                  )}
                  {filteredRows.map((r) => (
                    <tr key={r.code} className="transition-colors hover:bg-gradient-to-r hover:from-[oklch(0.96_0.04_255)] hover:via-[oklch(0.92_0.07_255)] hover:to-[oklch(0.96_0.04_255)]">
                      <td className="px-6 py-4">
                        <div className="flex flex-col items-start gap-1.5">
                          <CurrencyFlag code={r.code} />
                          <div>
                            <div className="font-bold leading-tight">{r.code}</div>
                            <div className="text-xs text-muted-foreground leading-tight">{r.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right font-mono text-sm text-muted-foreground">
                        {r.unit.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-right font-mono font-bold text-[oklch(0.48_0.22_258)]">
                        {r.buy.toFixed(4)}
                      </td>
                      <td className="px-6 py-4 text-right font-mono">{r.sell.toFixed(4)}</td>
                      <td className="px-6 py-4 text-right text-xs text-muted-foreground">
                        {r.updatedAt
                          ? new Date(r.updatedAt).toLocaleString("en-MY", {
                              dateStyle: "medium",
                              timeStyle: "short",
                            })
                          : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Mobile card list */}
            <ul className="space-y-3 md:hidden" style={{ fontFamily: "Arial, sans-serif" }}>
              {rateRows.length === 0 && (
                <li className="rounded-xl border border-border bg-card p-6 text-center text-sm text-muted-foreground">
                  Loading live rates…
                </li>
              )}
              {rateRows.length > 0 && filteredRows.length === 0 && (
                <li className="rounded-xl border border-border bg-card p-6 text-center text-sm text-muted-foreground">
                  No currencies match "{search}".
                </li>
              )}
              {filteredRows.map((r) => (
                <li key={r.code} className="rounded-xl border border-border bg-card p-4 transition-colors hover:bg-gradient-to-r hover:from-[oklch(0.96_0.04_255)] hover:via-[oklch(0.92_0.07_255)] hover:to-[oklch(0.96_0.04_255)]">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex min-w-0 flex-col gap-1.5">
                      <CurrencyFlag code={r.code} />
                      <div className="min-w-0">
                        <div className="text-base font-bold leading-tight">{r.code}</div>
                        <div className="truncate text-xs text-muted-foreground leading-tight">{r.name}</div>
                      </div>
                    </div>
                    <div className="shrink-0 text-right font-mono text-xs text-muted-foreground">
                      Unit {r.unit.toLocaleString()}
                    </div>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <div className="rounded-lg bg-secondary/60 px-3 py-2">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Buy (RM)</div>
                      <div className="mt-0.5 font-mono text-sm font-bold tabular-nums text-[oklch(0.48_0.22_258)]">{r.buy.toFixed(4)}</div>
                    </div>
                    <div className="rounded-lg bg-secondary/60 px-3 py-2">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Sell (RM)</div>
                      <div className="mt-0.5 font-mono text-sm font-bold tabular-nums">{r.sell.toFixed(4)}</div>
                    </div>
                  </div>
                  {r.updatedAt && (
                    <div className="mt-2 text-[11px] text-muted-foreground">
                      Updated {new Date(r.updatedAt).toLocaleString("en-MY", { dateStyle: "medium", timeStyle: "short" })}
                    </div>
                  )}
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-muted-foreground">
              Pulled live from the merchant's own website. Always confirm at the counter before transacting.
            </p>
          </div>

          <aside className="space-y-6">
            <div className="rounded-2xl border border-border bg-card p-6">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Contact</h3>
              <p className="mt-3 text-base font-semibold">{changer.phone}</p>
              <p className="mt-1 text-sm text-muted-foreground">{changer.hours}</p>
              <div className="mt-4 flex gap-2">
                <a
                  href={`tel:${changer.phone.replace(/\s/g, "")}`}
                  className="flex-1 rounded-lg bg-foreground py-2.5 text-center text-sm font-bold text-background"
                >
                  Call
                </a>
                <a
                  href={`https://maps.google.com/?q=${encodeURIComponent(changer.address)}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex-1 rounded-lg border border-border bg-card py-2.5 text-center text-sm font-bold"
                >
                  Directions
                </a>
              </div>
            </div>
            <div className="overflow-hidden rounded-2xl border border-border">
              <iframe
                title={`Google Maps location of ${changer.name} at ${changer.address}`}
                src={`https://maps.google.com/maps?q=${encodeURIComponent(changer.address)}&output=embed`}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-64 w-full border-0"
              />
            </div>
          </aside>
        </div>

        <section className="mt-16 max-w-3xl">
          <h2 className="text-2xl font-bold tracking-tight">Frequently asked questions</h2>
          <div className="mt-6 space-y-5">
            <div>
              <h3 className="font-bold">What currencies does {changer.name} exchange?</h3>
              <p className="mt-1 text-muted-foreground">{changer.name} typically handles major currencies including USD, SGD, EUR, GBP, JPY, AUD and most ASEAN currencies. The live table above shows exactly which currencies the branch is trading today.</p>
            </div>
            <div>
              <h3 className="font-bold">What are the opening hours?</h3>
              <p className="mt-1 text-muted-foreground">{changer.hours}. Hours can change on public holidays — call ahead on {changer.phone} to confirm.</p>
            </div>
            <div>
              <h3 className="font-bold">Where exactly is {changer.name}?</h3>
              <p className="mt-1 text-muted-foreground">{changer.address}. Use the map above for walking directions from the nearest LRT or MRT station.</p>
            </div>
            <div>
              <h3 className="font-bold">Is {changer.name} licensed?</h3>
              <p className="mt-1 text-muted-foreground">All money changers operating in Malaysia must be licensed by Bank Negara Malaysia under the Money Services Business Act 2011. Always look for the BNM licence sticker at the counter.</p>
            </div>
            <div>
              <h3 className="font-bold">Are the rates shown here the same as at the counter?</h3>
              <p className="mt-1 text-muted-foreground">They are pulled live from the merchant's own published source. Counter rates can move during the day and differ by note denomination — confirm the final rate before handing over money.</p>
            </div>
            <div>
              <h3 className="font-bold">Do I need to bring ID?</h3>
              <p className="mt-1 text-muted-foreground">Yes — you must present your IC or passport for any transaction. Under Bank Negara's AMLA rules, licensed money changers are required to verify customer identity on every exchange.</p>
            </div>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}