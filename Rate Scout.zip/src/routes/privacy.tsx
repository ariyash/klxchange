import { createFileRoute } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — KLXchange" },
      { name: "description", content: "How KLXchange collects, uses and protects your information, including cookies, analytics and Google AdSense advertising." },
      { property: "og:title", content: "Privacy Policy — KLXchange" },
      { property: "og:description", content: "How KLXchange handles data, cookies, analytics and advertising." },
      { property: "og:url", content: "https://klxchange.com/privacy" },
    ],
    links: [{ rel: "canonical", href: "https://klxchange.com/privacy" }],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8 prose-headings:font-bold">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Privacy Policy</h1>
        <p className="mt-3 text-sm text-muted-foreground">Last updated: 18 June 2026</p>

        <p className="mt-6 text-muted-foreground">
          This page explains what information KLXchange ("we", "us") collects when you visit
          klxchange.com, how we use it, and the choices you have. KLXchange is operated from Malaysia.
        </p>

        <h2 className="mt-10 text-2xl font-bold">1. What we collect</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li><strong>Usage data:</strong> pages viewed, referring URL, device type, browser, approximate location (country/city level), and timestamps.</li>
          <li><strong>Cookies & local storage:</strong> small files used to remember preferences and measure traffic.</li>
          <li><strong>Account data (optional):</strong> if you create an account to publish rates, we store your email and the rates you submit.</li>
          <li><strong>Contact data:</strong> anything you choose to email us.</li>
        </ul>
        <p className="mt-3 text-muted-foreground">
          We do <strong>not</strong> collect your IC number, passport number, bank details or transaction history. We are not a money changer.
        </p>

        <h2 className="mt-10 text-2xl font-bold">2. How we use it</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li>To operate and improve the site, fix bugs, and prevent abuse.</li>
          <li>To measure aggregate traffic (which pages are popular, which currencies people search).</li>
          <li>To serve relevant advertising via Google AdSense.</li>
          <li>To respond to emails you send us.</li>
        </ul>

        <h2 className="mt-10 text-2xl font-bold">3. Advertising — Google AdSense</h2>
        <p className="mt-3 text-muted-foreground">
          KLXchange uses Google AdSense to display ads. Google and its partners use cookies to serve
          ads based on your prior visits to this and other websites. Google's use of advertising
          cookies enables it and its partners to serve ads based on your visits to our site and other
          sites on the Internet.
        </p>
        <p className="mt-3 text-muted-foreground">
          You can opt out of personalized advertising by visiting{" "}
          <a href="https://www.google.com/settings/ads" target="_blank" rel="noreferrer" className="font-semibold text-[oklch(0.48_0.22_258)] underline">Google Ads Settings</a>{" "}
          or third-party vendor opt-outs at{" "}
          <a href="https://www.aboutads.info" target="_blank" rel="noreferrer" className="font-semibold text-[oklch(0.48_0.22_258)] underline">aboutads.info</a>.
        </p>

        <h2 className="mt-10 text-2xl font-bold">4. Analytics</h2>
        <p className="mt-3 text-muted-foreground">
          We use privacy-respecting analytics to understand aggregate traffic patterns. We do not
          attempt to identify individual visitors.
        </p>

        <h2 className="mt-10 text-2xl font-bold">5. Cookies</h2>
        <p className="mt-3 text-muted-foreground">
          You can block or delete cookies through your browser settings. Blocking advertising
          cookies may mean you see less relevant ads but will not affect access to rate data.
        </p>

        <h2 className="mt-10 text-2xl font-bold">6. Third-party links</h2>
        <p className="mt-3 text-muted-foreground">
          Money changer detail pages link out to merchant websites, Google Maps and phone numbers.
          Those sites have their own privacy policies; we are not responsible for their practices.
        </p>

        <h2 className="mt-10 text-2xl font-bold">7. Data retention</h2>
        <p className="mt-3 text-muted-foreground">
          Aggregate analytics are retained for up to 26 months. Account data is kept while your
          account is active and deleted on request.
        </p>

        <h2 className="mt-10 text-2xl font-bold">8. Your rights</h2>
        <p className="mt-3 text-muted-foreground">
          Under Malaysia's Personal Data Protection Act 2010 you may request access to, correction
          of, or deletion of your personal data. Email{" "}
          <a href="mailto:privacy@klxchange.com" className="font-semibold text-[oklch(0.48_0.22_258)] underline">privacy@klxchange.com</a>.
        </p>

        <h2 className="mt-10 text-2xl font-bold">9. Children</h2>
        <p className="mt-3 text-muted-foreground">
          KLXchange is not directed at children under 13 and we do not knowingly collect their data.
        </p>

        <h2 className="mt-10 text-2xl font-bold">10. Changes</h2>
        <p className="mt-3 text-muted-foreground">
          We may update this policy. Material changes will be reflected by an updated "Last updated" date above.
        </p>
      </main>
      <SiteFooter />
    </div>
  );
}