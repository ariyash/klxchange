import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { SiteHeader, SiteFooter } from "@/components/SiteHeader";
import { submitPublishRate } from "@/lib/publish-rate.functions";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/publish-rate")({
  head: () => ({
    meta: [
      { title: "Publish Your Rate — KL Exchange" },
      {
        name: "description",
        content:
          "Money changer in Klang Valley? Publish your live rates on KL Exchange. Fill the contact form and our team will get back to you.",
      },
      { property: "og:title", content: "Publish Your Rate — KL Exchange" },
      {
        property: "og:description",
        content:
          "Money changer in Klang Valley? Publish your live rates on KL Exchange.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: PublishRatePage,
});

function PublishRatePage() {
  const submit = useServerFn(submitPublishRate);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [form, setForm] = useState({
    business_name: "",
    contact_name: "",
    email: "",
    phone: "",
    location: "",
    message: "",
  });

  const update =
    (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.business_name.trim() || !form.contact_name.trim() || !form.email.trim()) {
      toast.error("Please fill in business name, contact name and email.");
      return;
    }
    setLoading(true);
    try {
      await submit({ data: form });
      setDone(true);
      toast.success("Thanks! We'll be in touch shortly.");
      setForm({
        business_name: "",
        contact_name: "",
        email: "",
        phone: "",
        location: "",
        message: "",
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Submission failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <Toaster />
      <main className="mx-auto max-w-3xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Publish Your Rate Here
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground sm:text-base">
            Are you a licensed money changer in Klang Valley? Get your live
            buy/sell rates featured on KL Exchange. Fill in the form below and
            our team will reach out shortly.
          </p>
        </div>

        {done ? (
          <div className="rounded-xl border border-border bg-card p-6 text-center shadow-sm">
            <h2 className="text-lg font-bold text-foreground">Submission received</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Thank you. Our team will contact you using the details provided.
            </p>
            <button
              type="button"
              onClick={() => setDone(false)}
              className="mt-4 inline-flex items-center justify-center rounded-md bg-[oklch(0.48_0.22_258)] px-4 py-2 text-sm font-medium text-white hover:opacity-90"
            >
              Submit another
            </button>
          </div>
        ) : (
          <form
            onSubmit={onSubmit}
            className="rounded-xl border border-border bg-card p-5 shadow-sm sm:p-7"
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Business name *">
                <input
                  required
                  maxLength={150}
                  value={form.business_name}
                  onChange={update("business_name")}
                  className={inputCls}
                />
              </Field>
              <Field label="Contact person *">
                <input
                  required
                  maxLength={100}
                  value={form.contact_name}
                  onChange={update("contact_name")}
                  className={inputCls}
                />
              </Field>
              <Field label="Email *">
                <input
                  required
                  type="email"
                  maxLength={255}
                  value={form.email}
                  onChange={update("email")}
                  className={inputCls}
                />
              </Field>
              <Field label="Phone / WhatsApp">
                <input
                  maxLength={40}
                  value={form.phone}
                  onChange={update("phone")}
                  className={inputCls}
                />
              </Field>
              <Field label="Location / Branch" className="sm:col-span-2">
                <input
                  maxLength={150}
                  value={form.location}
                  onChange={update("location")}
                  placeholder="e.g. Mid Valley, KLCC"
                  className={inputCls}
                />
              </Field>
              <Field label="Message" className="sm:col-span-2">
                <textarea
                  rows={5}
                  maxLength={2000}
                  value={form.message}
                  onChange={update("message")}
                  placeholder="Tell us about your store, rates source, business hours…"
                  className={`${inputCls} resize-y`}
                />
              </Field>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="mt-6 inline-flex w-full items-center justify-center rounded-md bg-[oklch(0.48_0.22_258)] px-4 py-3 text-sm font-bold text-white transition-opacity hover:opacity-90 disabled:opacity-60 sm:w-auto"
            >
              {loading ? "Submitting…" : "Submit"}
            </button>
            <p className="mt-3 text-xs text-muted-foreground">
              By submitting, you agree to be contacted by KL Exchange regarding
              listing your rates.
            </p>
          </form>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}

const inputCls =
  "w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground outline-none ring-offset-background focus:ring-2 focus:ring-[oklch(0.55_0.20_255)]";

function Field({
  label,
  children,
  className,
}: {
  label: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <label className={`flex flex-col gap-1.5 ${className ?? ""}`}>
      <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {label}
      </span>
      {children}
    </label>
  );
}