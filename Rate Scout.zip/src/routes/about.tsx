import { createFileRoute } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About KLXchange — Malaysia's Live Money Changer Comparison" },
      { name: "description", content: "KLXchange compares live buy/sell rates from authorized money changers across Kuala Lumpur, Mid Valley, KLCC and PJ. Learn who we are and how we work." },
      { property: "og:title", content: "About KLXchange" },
      { property: "og:description", content: "Who we are and how we compare KL money changer rates in real time." },
      { property: "og:url", content: "https://klxchange.com/about" },
    ],
    links: [{ rel: "canonical", href: "https://klxchange.com/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">About KLXchange</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          KLXchange is an independent Malaysian rate-comparison service built for travellers, expats,
          freelancers and small businesses who need to find the best currency exchange rate in Kuala
          Lumpur without walking from counter to counter.
        </p>

        <h2 className="mt-10 text-2xl font-bold">What we do</h2>
        <p className="mt-3 text-muted-foreground">
          We aggregate live buy and sell rates from 50+ licensed money changers across KL, Mid Valley,
          KLCC, Bukit Bintang and Petaling Jaya. Every rate on the site is pulled directly from each
          merchant's own published source — we don't make up numbers, mark them up, or take commission.
        </p>

        <h2 className="mt-10 text-2xl font-bold">Why we built it</h2>
        <p className="mt-3 text-muted-foreground">
          Rates between money changers in KL can vary by 1–3% for the same currency on the same day.
          On a RM 5,000 USD exchange that's RM 50–150 left on the table. We wanted one place to see
          everyone's rates side by side, updated continuously, so you can walk into the right shop
          the first time.
        </p>

        <h2 className="mt-10 text-2xl font-bold">How we make money</h2>
        <p className="mt-3 text-muted-foreground">
          KLXchange is free to use. We're supported by display advertising and (in future) optional
          paid listings for changers who want to feature their branch. Sponsored placements, if any,
          will always be clearly labelled. Rates themselves are never paid placements — the ranking
          is purely best-rate-first.
        </p>

        <h2 className="mt-10 text-2xl font-bold">Independence & accuracy</h2>
        <p className="mt-3 text-muted-foreground">
          We are not a money changer, not a remittance service, and not affiliated with Bank Negara
          Malaysia. We are an independent comparison site. Rates shown are indicative — always confirm
          the final rate at the counter before transacting, and bring your IC or passport as required
          under Malaysian AMLA rules.
        </p>

        <h2 className="mt-10 text-2xl font-bold">Contact</h2>
        <p className="mt-3 text-muted-foreground">
          Spotted a wrong rate, a closed branch, or want your changer listed? See our{" "}
          <a href="/contact" className="font-semibold text-[oklch(0.48_0.22_258)] underline">contact page</a>.
        </p>
      </main>
      <SiteFooter />
    </div>
  );
}