import { createFileRoute } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";

export const Route = createFileRoute("/methodology")({
  head: () => ({
    meta: [
      { title: "Methodology — How KLXchange Collects Money Changer Rates" },
      { name: "description", content: "How KLXchange sources, normalizes and refreshes rates from Malaysian money changers, and how we handle errors, gaps and disputes." },
      { property: "og:title", content: "How KLXchange collects rates" },
      { property: "og:description", content: "Our sourcing, normalization, refresh and accuracy methodology." },
      { property: "og:url", content: "https://klxchange.com/methodology" },
    ],
    links: [{ rel: "canonical", href: "https://klxchange.com/methodology" }],
  }),
  component: MethodologyPage,
});

function MethodologyPage() {
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Methodology</h1>
        <p className="mt-4 text-lg text-muted-foreground">
          We get this question a lot: where do the rates come from, and how do we know they're right?
          Here's exactly how KLXchange works.
        </p>

        <h2 className="mt-10 text-2xl font-bold">1. Sources</h2>
        <p className="mt-3 text-muted-foreground">
          Every rate on KLXchange comes from one of three places:
        </p>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li><strong>The changer's own public website</strong> (e.g. Placid Express, KL Money Changer).</li>
          <li><strong>A merchant-managed Google Sheet</strong> that the changer updates themselves.</li>
          <li><strong>Self-published rates</strong> submitted via the "Publish Your Rate" portal by verified merchants.</li>
        </ul>
        <p className="mt-3 text-muted-foreground">
          We never invent, estimate, or interpolate rates. If a source is offline, the row shows the
          last known value with a timestamp — or is hidden if it's clearly stale.
        </p>

        <h2 className="mt-10 text-2xl font-bold">2. Refresh frequency</h2>
        <p className="mt-3 text-muted-foreground">
          Rates are re-fetched on a rolling cycle, typically every 1–3 minutes for active changers.
          Each row carries its own "Last updated" timestamp so you can see exactly how fresh the number is.
        </p>

        <h2 className="mt-10 text-2xl font-bold">3. Normalization</h2>
        <p className="mt-3 text-muted-foreground">
          Different changers quote rates differently — some per 1 unit, some per 100, some buy/sell
          flipped. We normalize everything to the convention <em>"RM per 1 unit of foreign currency"</em>{" "}
          (with the original unit displayed in the Unit column) so you can compare apples to apples.
        </p>

        <h2 className="mt-10 text-2xl font-bold">4. Filtering bad data</h2>
        <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
          <li>Rows where buy = sell are treated as a "not traded at this branch" placeholder and hidden.</li>
          <li>Non-positive, non-finite, or impossibly wide spreads are dropped.</li>
          <li>Currencies marked unsupported at a branch are excluded from that branch only.</li>
        </ul>

        <h2 className="mt-10 text-2xl font-bold">5. Ranking</h2>
        <p className="mt-3 text-muted-foreground">
          The "best rate" highlight is purely algorithmic — it's whichever changer offers the most
          RM-per-unit for the currency you're buying (or the lowest RM-per-unit for currency you're
          selling). No paid placement, no manual boosts.
        </p>

        <h2 className="mt-10 text-2xl font-bold">6. Reporting errors</h2>
        <p className="mt-3 text-muted-foreground">
          See a rate that doesn't match the counter? Email{" "}
          <a href="mailto:rates@klxchange.com" className="font-semibold text-[oklch(0.48_0.22_258)] underline">rates@klxchange.com</a>{" "}
          with the changer name, currency and counter rate (a photo helps). We typically push a fix within a few hours.
        </p>

        <h2 className="mt-10 text-2xl font-bold">7. Important disclaimer</h2>
        <p className="mt-3 text-muted-foreground">
          Rates shown here are indicative only. The rate at the counter — after the changer factors
          in note denomination, customer profile and current liquidity — is the only binding rate.
          Always confirm before handing over money.
        </p>
      </main>
      <SiteFooter />
    </div>
  );
}