import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { SiteFooter, SiteHeader } from "@/components/SiteHeader";
import { CHANGERS } from "@/lib/changers";
import { useAllChangers } from "@/hooks/useChangers";

export const Route = createFileRoute("/changers")({
  head: () => ({
    meta: [
      { title: "All Money Changers in KL | KL EXCHANGE" },
      { name: "description", content: `Directory of ${CHANGERS.length} authorized money changers in Kuala Lumpur and PJ with live buy and sell rates, addresses and opening hours.` },
      { property: "og:title", content: "All Money Changers in KL | KL EXCHANGE" },
      { property: "og:description", content: `Directory of ${CHANGERS.length} authorized money changers in KL & PJ with live rates.` },
      { property: "og:url", content: "https://klxchange.com/changers" },
    ],
    links: [{ rel: "canonical", href: "https://klxchange.com/changers" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "ItemList",
          itemListElement: CHANGERS.map((c, i) => ({
            "@type": "ListItem",
            position: i + 1,
            url: `https://klxchange.com/changer/${c.slug}`,
            name: c.name,
          })),
        }),
      },
    ],
  }),
  component: ChangersList,
});

function ChangersList() {
  const [view, setView] = useState<"list" | "map">("list");
  const { changers } = useAllChangers();
  const all = [...(changers.length > 0 ? changers : CHANGERS)].sort((a, b) =>
    a.name.localeCompare(b.name, "en", { sensitivity: "base" }),
  );
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SiteHeader />
      <main className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold sm:text-4xl">All Money Changers</h1>
            <p className="mt-2 text-muted-foreground">{all.length} tracked across Kuala Lumpur & Selangor.</p>
          </div>
          <div className="inline-flex rounded-lg border border-border bg-card p-1 text-sm font-semibold">
            <button
              onClick={() => setView("list")}
              className={`rounded-md px-3 py-1.5 ${view === "list" ? "bg-foreground text-background" : "text-muted-foreground"}`}
            >
              List
            </button>
            <button
              onClick={() => setView("map")}
              className={`rounded-md px-3 py-1.5 ${view === "map" ? "bg-foreground text-background" : "text-muted-foreground"}`}
            >
              Map
            </button>
          </div>
        </div>
        {view === "map" ? (
          <div className="mt-8 grid grid-cols-1 gap-6 lg:grid-cols-3">
            <div className="overflow-hidden rounded-2xl border border-border lg:col-span-2">
              <iframe
                title="Money changers in KL"
                src={`https://maps.google.com/maps?q=${encodeURIComponent(
                  "money changer Kuala Lumpur",
                )}&output=embed`}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-[600px] w-full border-0"
              />
            </div>
            <ul className="space-y-3">
              {all.map((c) => (
                <li key={c.slug}>
                  <a
                    href={`https://maps.google.com/?q=${encodeURIComponent(c.address || c.name)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="block rounded-xl border border-border bg-card p-4 transition-all hover:border-foreground/30 hover:shadow-md"
                  >
                    <div className="text-xs font-bold uppercase tracking-wider text-[oklch(0.48_0.22_258)]">{c.area}</div>
                    <div className="mt-1 font-bold">{c.name}</div>
                    <p className="mt-1 text-xs text-muted-foreground">{c.address}</p>
                    <span className="mt-2 inline-block text-xs font-semibold text-[oklch(0.55_0.20_255)]">
                      Open in Google Maps →
                    </span>
                  </a>
                  <Link
                    to="/changer/$slug"
                    params={{ slug: c.slug }}
                    className="mt-1 inline-block text-xs text-muted-foreground hover:underline"
                  >
                    View rates & details
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ) : (
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {all.map((c) => (
            <Link
              key={c.slug}
              to="/changer/$slug"
              params={{ slug: c.slug }}
              className="rounded-2xl border border-border bg-card p-5 transition-all hover:shadow-lg"
            >
              <span className="text-xs font-bold uppercase tracking-wider text-[oklch(0.48_0.22_258)]">{c.area}</span>
              <h2 className="mt-2 text-lg font-bold">{c.name}</h2>
              <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">{c.address}</p>
              <div className="mt-3 text-xs font-medium text-muted-foreground">
                ⭐ {c.rating}/5 · {c.reviews.toLocaleString()} reviews
              </div>
            </Link>
          ))}
        </div>
        )}
      </main>
      <SiteFooter />
    </div>
  );
}