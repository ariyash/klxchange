export type Currency = string;

export const POPULAR_CURRENCIES = [
  "USD", "SGD", "EUR", "GBP", "AUD", "JPY", "THB", "IDR", "CNY", "HKD",
] as const;
export const CURRENCIES: string[] = [
  "USD", "SGD", "EUR", "GBP", "AUD", "JPY", "THB", "IDR", "CNY", "HKD",
  "NZD", "CHF", "CAD", "INR", "KRW", "TWD", "VND", "PHP", "AED", "SAR",
  "BHD", "BND", "DKK", "EGP", "JOD", "KWD", "MOP", "NOK", "OMR", "QAR",
  "ZAR", "LKR", "SEK", "TRY", "PKR", "BDT", "RUB", "NPR", "CZK", "KHR",
];

export const CURRENCY_NAMES: Record<string, string> = {
  USD: "US Dollar",
  SGD: "Singapore Dollar",
  EUR: "Euro",
  GBP: "British Pound",
  AUD: "Australian Dollar",
  JPY: "Japanese Yen",
  THB: "Thai Baht",
  IDR: "Indonesian Rupiah",
  CNY: "Chinese Yuan",
  HKD: "Hong Kong Dollar",
  NZD: "New Zealand Dollar",
  CHF: "Swiss Franc",
  CAD: "Canadian Dollar",
  INR: "Indian Rupee",
  KRW: "South Korean Won",
  TWD: "New Taiwan Dollar",
  VND: "Vietnamese Dong",
  PHP: "Philippine Peso",
  AED: "UAE Dirham",
  SAR: "Saudi Riyal",
  BHD: "Bahraini Dinar",
  BND: "Brunei Dollar",
  DKK: "Danish Krone",
  EGP: "Egyptian Pound",
  JOD: "Jordanian Dinar",
  KWD: "Kuwaiti Dinar",
  MOP: "Macanese Pataca",
  NOK: "Norwegian Krone",
  OMR: "Omani Rial",
  QAR: "Qatari Riyal",
  ZAR: "South African Rand",
  LKR: "Sri Lankan Rupee",
  SEK: "Swedish Krona",
  TRY: "Turkish Lira",
  PKR: "Pakistani Rupee",
  BDT: "Bangladeshi Taka",
  RUB: "Russian Ruble",
  NPR: "Nepalese Rupee",
  CZK: "Czech Koruna",
  KHR: "Cambodian Riel",
};

// Mid-market fallback (MYR per 1 unit) — used only when live data unavailable.
export const MID_RATES: Record<string, number> = {
  USD: 4.71,
  SGD: 3.49,
  EUR: 5.09,
  GBP: 5.95,
  AUD: 3.07,
  JPY: 0.0305,
  THB: 0.132,
  IDR: 0.00029,
  CNY: 0.65,
  HKD: 0.60,
};

export type Area =
  | "Mid Valley"
  | "Bukit Bintang"
  | "KLCC / Ampang"
  | "Bangsar"
  | "KL Sentral"
  | "Central Market"
  | "Petaling Jaya"
  | "Kepong";

export const AREAS: Area[] = [
  "Mid Valley",
  "Bukit Bintang",
  "KLCC / Ampang",
  "Bangsar",
  "KL Sentral",
  "Central Market",
  "Petaling Jaya",
  "Kepong",
];

export type RateSource =
  | { kind: "klmc"; url: string }
  | { kind: "klremit"; url: string }
  | { kind: "placid"; branch: string };

export interface MoneyChanger {
  slug: string;
  name: string;
  area: Area;
  address: string;
  hours: string;
  phone: string;
  rating: number;
  reviews: number;
  source: RateSource;
}

export const CHANGERS: MoneyChanger[] = [
  {
    slug: "placid-express-kl",
    name: "Placid Express (Central Market)",
    area: "Central Market",
    address:
      "Central Market, Jalan Hang Kasturi, City Centre, 50050 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur",
    hours: "10:00 AM – 7:00 PM (Mon–Sat)",
    phone: "+60 11-3666 7675",
    rating: 4.6,
    reviews: 120,
    source: { kind: "placid", branch: "main" },
  },
  {
    slug: "placid-express-bukit-bintang",
    name: "Placid Express (Bukit Bintang)",
    area: "Bukit Bintang",
    address:
      "Jalan Bukit Bintang, Bukit Bintang, 55100 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur",
    hours: "10:00 AM – 9:00 PM (Daily)",
    phone: "+60 11-3666 7675",
    rating: 4.6,
    reviews: 60,
    source: { kind: "placid", branch: "bukit_bintang" },
  },
  {
    slug: "max-money-mid-valley",
    name: "Max Money Mid Valley",
    area: "Mid Valley",
    address:
      "Lot S-P1-01, Mid Valley Megamall, Mid Valley City, Lingkaran Syed Putra, 59200 Kuala Lumpur",
    hours: "10:00 AM – 10:00 PM (Daily)",
    phone: "+60 3-2282 9500",
    rating: 4.5,
    reviews: 380,
    source: {
      kind: "klmc",
      url: "https://www.klmoneychanger.com/maxmoney/midvalley-megamall",
    },
  },
  {
    slug: "max-money-sungei-wang",
    name: "Max Money Sungei Wang",
    area: "Bukit Bintang",
    address: "Sungei Wang Plaza, Jalan Sultan Ismail, Bukit Bintang, 55100 Kuala Lumpur",
    hours: "10:00 AM – 10:00 PM (Daily)",
    phone: "+60 3-2110 0028",
    rating: 4.4,
    reviews: 250,
    source: {
      kind: "klmc",
      url: "https://www.klmoneychanger.com/maxmoney/sungei-wang",
    },
  },
  {
    slug: "my-money-master-mid-valley",
    name: "My Money Master Mid Valley",
    area: "Mid Valley",
    address:
      "LG 040, LGF, Mid Valley Megamall, Lingkaran Syed Putra, Mid Valley City, 59200 Kuala Lumpur",
    hours: "10:00 AM – 10:00 PM (Daily)",
    phone: "1-800-22-3030",
    rating: 4.4,
    reviews: 210,
    source: {
      kind: "klmc",
      url: "https://www.klmoneychanger.com/mymoneymaster/midvalley-megamall",
    },
  },
  {
    slug: "jalinan-duta-bukit-bintang",
    name: "Jalinan Duta (Bukit Bintang)",
    area: "Bukit Bintang",
    address: "2005A Malayan Mansion, Jalan Masjid India, 50100 Kuala Lumpur",
    hours: "9:30 AM – 7:00 PM (Daily)",
    phone: "+60 3-2694 6166",
    rating: 4.5,
    reviews: 150,
    source: {
      kind: "klmc",
      url: "https://www.klmoneychanger.com/jalinanduta/bukit-bintang",
    },
  },
  {
    slug: "jalinan-duta-masjid-india",
    name: "Jalinan Duta (Masjid India)",
    area: "Bukit Bintang",
    address: "No 120 Jalan Bukit Bintang, 55100 Kuala Lumpur",
    hours: "9:30 AM – 3:00 AM (Daily)",
    phone: "+60 3-2144 3666",
    rating: 4.5,
    reviews: 180,
    source: {
      kind: "klmc",
      url: "https://www.klmoneychanger.com/jalinanduta/masjid-india",
    },
  },
];

export function getChanger(slug: string) {
  return CHANGERS.find((c) => c.slug === slug);
}

export function formatRate(n: number) {
  if (!isFinite(n) || n === 0) return "0.0000";
  const abs = Math.abs(n);
  // Always keep at least 4 decimals; for sub-unit rates, expose enough
  // significant digits so currencies like IDR/VND aren't shown as 0.0003.
  if (abs >= 1) return n.toFixed(4);
  const decimals = Math.min(10, Math.max(4, 4 - Math.floor(Math.log10(abs))));
  return n.toFixed(decimals);
}

export function formatMyr(n: number) {
  return n.toLocaleString("en-MY", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** Shape returned by the live-rates server fn. */
export interface LiveChangerRates {
  slug: string;
  fetchedAt: string;
  error?: string;
  rates: Record<
    string,
    { code: string; name: string; unit: number; buy: number; sell: number; updatedAt: string }
  >;
}

export type LiveRatesPayload = Record<string, LiveChangerRates>;

/** Normalized MYR you receive per 1 unit of foreign currency. */
export function perUnitBuy(r: { buy: number; unit: number }) {
  return r.buy / r.unit;
}
export function perUnitSell(r: { sell: number; unit: number }) {
  return r.sell / r.unit;
}

/**
 * Some currencies (low denomination) are conventionally quoted per a larger
 * block so the displayed MYR figure is meaningful. e.g. IDR / VND per 1,000,000.
 */
export const DISPLAY_UNITS: Record<string, number> = {
  IDR: 1_000_000,
  VND: 1_000_000,
};

export function displayUnit(code: string) {
  return DISPLAY_UNITS[code] ?? 1;
}

/** Label like "USD" or "1,000,000 IDR" suitable for column headings. */
export function displayUnitLabel(code: string) {
  const u = displayUnit(code);
  return u === 1 ? code : `${u.toLocaleString("en-US")} ${code}`;
}

export function displayBuy(r: { buy: number; unit: number }, code: string) {
  return perUnitBuy(r) * displayUnit(code);
}
export function displaySell(r: { sell: number; unit: number }, code: string) {
  return perUnitSell(r) * displayUnit(code);
}