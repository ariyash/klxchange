import * as React from 'react'
import {
  Body,
  Container,
  Head,
  Heading,
  Hr,
  Html,
  Preview,
  Section,
  Text,
} from '@react-email/components'
import type { TemplateEntry } from './registry'

interface Props {
  business_name?: string
  contact_name?: string
  email?: string
  phone?: string | null
  location?: string | null
  message?: string | null
  submitted_at?: string
}

const Email = ({
  business_name = 'Unknown business',
  contact_name = '—',
  email = '—',
  phone,
  location,
  message,
  submitted_at,
}: Props) => (
  <Html lang="en" dir="ltr">
    <Head />
    <Preview>New publish-rate request from {business_name}</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>New publish-rate request</Heading>
        <Text style={muted}>
          A money changer has requested to publish their rates on KLXchange.
        </Text>
        <Hr style={hr} />
        <Section>
          <Row label="Business" value={business_name} />
          <Row label="Contact" value={contact_name} />
          <Row label="Email" value={email} />
          {phone ? <Row label="Phone" value={phone} /> : null}
          {location ? <Row label="Location" value={location} /> : null}
          {submitted_at ? <Row label="Submitted" value={submitted_at} /> : null}
        </Section>
        {message ? (
          <>
            <Hr style={hr} />
            <Heading as="h2" style={h2}>Message</Heading>
            <Text style={body}>{message}</Text>
          </>
        ) : null}
      </Container>
    </Body>
  </Html>
)

const Row = ({ label, value }: { label: string; value: string }) => (
  <Text style={row}>
    <span style={rowLabel}>{label}: </span>
    <span>{value}</span>
  </Text>
)

export const template = {
  component: Email,
  subject: (data: Record<string, any>) =>
    `New publish-rate request: ${data.business_name ?? 'Unknown'}`,
  displayName: 'Publish-rate notification',
  to: 'davereturned@gmail.com',
  previewData: {
    business_name: 'Acme Money Changer',
    contact_name: 'Jane Doe',
    email: 'jane@example.com',
    phone: '+60 12-345 6789',
    location: 'Kuala Lumpur',
    message: 'We would like to be listed on KLXchange.',
    submitted_at: new Date().toISOString(),
  },
} satisfies TemplateEntry

const main = { backgroundColor: '#ffffff', fontFamily: 'Arial, sans-serif' }
const container = { padding: '24px 28px', maxWidth: '560px' }
const h1 = { fontSize: '20px', color: '#0f172a', margin: '0 0 8px' }
const h2 = { fontSize: '15px', color: '#0f172a', margin: '16px 0 8px' }
const muted = { fontSize: '14px', color: '#64748b', margin: '0 0 12px' }
const body = { fontSize: '14px', color: '#0f172a', lineHeight: '1.5' }
const row = { fontSize: '14px', color: '#0f172a', margin: '4px 0' }
const rowLabel = { color: '#64748b', fontWeight: 600 }
const hr = { borderColor: '#e2e8f0', margin: '16px 0' }