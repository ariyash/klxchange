import { createServerFn } from "@tanstack/react-start";
import { CHANGERS, type LiveChangerRates, type LiveRatesPayload } from "./changers";
import {
  scrapeAntaraduit,
  scrapeAuto,
  scrapeEglobex,
  scrapeKlmc,
  scrapeKlremit,
  scrapePlacid,
  scrapeInfinity,
  scrapeGsheet,
  scrapeMoneywave,
  type LiveRate,
} from "./scraper.server";

const TTL_MS = 3_000;
let cache: { at: number; data: LiveRatesPayload } | null = null;
// Per-slug last successful scrape — used as fallback when a fresh scrape fails.
const lastGood: Record<string, LiveChangerRates> = {};

async function fetchOne(slug: string): Promise<LiveChangerRates> {
  const c = CHANGERS.find((x) => x.slug === slug);
  if (!c) return { slug, fetchedAt: new Date().toISOString(), rates: {}, error: "Unknown changer" };
  try {
    const list: LiveRate[] =
      c.source.kind === "klmc"
        ? await scrapeKlmc(c.source.url)
        : c.source.kind === "klremit"
          ? await scrapeKlremit(c.source.url)
          : await scrapePlacid(c.source.branch);
    const rates: LiveChangerRates["rates"] = {};
    for (const r of list) rates[r.code] = r;
    const fresh = { slug, fetchedAt: new Date().toISOString(), rates };
    if (Object.keys(rates).length > 0) lastGood[slug] = fresh;
    return fresh;
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    const cached = lastGood[slug];
    if (cached) {
      return {
        slug,
        fetchedAt: cached.fetchedAt,
        rates: cached.rates,
        error: `Using cached rates (live fetch failed: ${msg})`,
      };
    }
    return {
      slug,
      fetchedAt: new Date().toISOString(),
      rates: {},
      error: msg,
    };
  }
}

export const getLiveRates = createServerFn({ method: "GET" }).handler(async () => {
  if (cache && Date.now() - cache.at < TTL_MS) return cache.data;
  const results = await Promise.all(CHANGERS.map((c) => fetchOne(c.slug)));
  const data: LiveRatesPayload = {};
  for (const r of results) data[r.slug] = r;

  // Merge DB-backed changer rates (rates stored from admin ingestion)
  try {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [{ data: dbChangers }, { data: dbRates }] = await Promise.all([
      supabaseAdmin
        .from("changers" as never)
        .select("id, slug, rate_source_kind, rate_source_url"),
      supabaseAdmin
        .from("changer_rates" as never)
        .select("changer_id, code, unit, buy, sell, updated_at"),
    ]);
    const dbChangerRows = (dbChangers ?? []) as unknown as Array<{
      id: string;
      slug: string;
      rate_source_kind: string;
      rate_source_url: string | null;
    }>;
    const slugById = new Map<string, string>(dbChangerRows.map((c) => [c.id, c.slug]));
    for (const r of (dbRates ?? []) as unknown as Array<{
      changer_id: string;
      code: string;
      unit: number;
      buy: number;
      sell: number;
      updated_at: string;
    }>) {
      const slug = slugById.get(r.changer_id);
      if (!slug) continue;
      const entry =
        data[slug] ?? (data[slug] = { slug, fetchedAt: new Date().toISOString(), rates: {} });
      entry.rates[r.code] = {
        code: r.code,
        name: r.code,
        unit: Number(r.unit) || 1,
        buy: Number(r.buy),
        sell: Number(r.sell),
        updatedAt: r.updated_at,
      };
    }

    // Live-scrape any DB changer that has no stored rates yet, so detail pages
    // don't sit on "Loading live rates…" forever before an admin clicks Refresh.
    // Always re-scrape Google Sheet sources so edits show up within ~3 seconds.
    const scrapeMissing = dbChangerRows.filter(
      (c) =>
        c.rate_source_url &&
        c.rate_source_kind !== "csv" &&
        (c.rate_source_kind === "gsheet" || !data[c.slug]),
    );
    await Promise.all(
      scrapeMissing.map(async (c) => {
        try {
          let list: LiveRate[] = [];
          if (c.rate_source_kind === "klmc") list = await scrapeKlmc(c.rate_source_url!);
          else if (c.rate_source_kind === "klremit") list = await scrapeKlremit(c.rate_source_url!);
          else if (c.rate_source_kind === "antaraduit")
            list = await scrapeAntaraduit(c.rate_source_url!);
          else if (c.rate_source_kind === "eglobex")
            list = await scrapeEglobex(c.rate_source_url!);
          else if (c.rate_source_kind === "infinity")
            list = await scrapeInfinity(c.rate_source_url!);
          else if (c.rate_source_kind === "auto") list = await scrapeAuto(c.rate_source_url!);
          else if (c.rate_source_kind === "gsheet") list = await scrapeGsheet(c.rate_source_url!);
          else if (c.rate_source_kind === "moneywave") list = await scrapeMoneywave(c.rate_source_url!);
          else return;
          const rates: LiveChangerRates["rates"] = {};
          for (const r of list) rates[r.code] = r;
          const fresh = { slug: c.slug, fetchedAt: new Date().toISOString(), rates };
          if (Object.keys(rates).length > 0) lastGood[c.slug] = fresh;
          data[c.slug] = fresh;
        } catch (e) {
          const msg = e instanceof Error ? e.message : String(e);
          const cached = lastGood[c.slug];
          data[c.slug] = cached
            ? {
                slug: c.slug,
                fetchedAt: cached.fetchedAt,
                rates: cached.rates,
                error: `Using cached rates (live fetch failed: ${msg})`,
              }
            : {
                slug: c.slug,
                fetchedAt: new Date().toISOString(),
                rates: {},
                error: msg,
              };
        }
      }),
    );
  } catch (e) {
    console.error("[getLiveRates] DB merge failed:", e);
  }

  cache = { at: Date.now(), data };
  return data;
});