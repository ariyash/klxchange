import * as React from 'react'
import { render } from '@react-email/components'
import { TEMPLATES } from '@/lib/email-templates/registry'

const SENDER_DOMAIN = 'notify.klxchange.com'
const FROM_DOMAIN = 'notify.klxchange.com'
const SITE_NAME = 'KLXchange'

function generateToken(): string {
  const bytes = new Uint8Array(32)
  crypto.getRandomValues(bytes)
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}

export interface InternalSendArgs {
  templateName: string
  recipientEmail?: string
  idempotencyKey?: string
  templateData?: Record<string, any>
}

/**
 * Server-only helper to enqueue a transactional email without going through
 * the user-auth-gated /lovable/email/transactional/send route. Use this for
 * public form triggers (contact forms, notifications). Always call from a
 * trusted server context (server function or server route handler).
 */
export async function sendTransactionalEmailInternal(args: InternalSendArgs) {
  const { supabaseAdmin } = await import('@/integrations/supabase/client.server')
  const supabase = supabaseAdmin

  const template = TEMPLATES[args.templateName]
  if (!template) throw new Error(`Template '${args.templateName}' not found`)

  const effectiveRecipient = template.to || args.recipientEmail
  if (!effectiveRecipient) throw new Error('recipientEmail is required')

  const normalizedEmail = effectiveRecipient.toLowerCase()
  const messageId = crypto.randomUUID()
  const idempotencyKey = args.idempotencyKey || messageId
  const templateData = args.templateData ?? {}

  // Suppression check
  const { data: suppressed } = await supabase
    .from('suppressed_emails' as never)
    .select('id')
    .eq('email', normalizedEmail)
    .maybeSingle()
  if (suppressed) {
    await supabase.from('email_send_log' as never).insert({
      message_id: messageId,
      template_name: args.templateName,
      recipient_email: effectiveRecipient,
      status: 'suppressed',
    } as never)
    return { success: false, reason: 'email_suppressed' as const }
  }

  // Unsubscribe token
  let unsubscribeToken: string
  const { data: existingToken } = await supabase
    .from('email_unsubscribe_tokens' as never)
    .select('token, used_at')
    .eq('email', normalizedEmail)
    .maybeSingle()
  if (existingToken && !(existingToken as any).used_at) {
    unsubscribeToken = (existingToken as any).token
  } else {
    unsubscribeToken = generateToken()
    await supabase
      .from('email_unsubscribe_tokens' as never)
      .upsert(
        { token: unsubscribeToken, email: normalizedEmail } as never,
        { onConflict: 'email', ignoreDuplicates: true } as never,
      )
    const { data: stored } = await supabase
      .from('email_unsubscribe_tokens' as never)
      .select('token')
      .eq('email', normalizedEmail)
      .maybeSingle()
    if (stored) unsubscribeToken = (stored as any).token
  }

  // Render
  const element = React.createElement(template.component, templateData)
  const html = await render(element)
  const plainText = await render(element, { plainText: true })
  const resolvedSubject =
    typeof template.subject === 'function'
      ? template.subject(templateData)
      : template.subject

  await supabase.from('email_send_log' as never).insert({
    message_id: messageId,
    template_name: args.templateName,
    recipient_email: effectiveRecipient,
    status: 'pending',
  } as never)

  const { error: enqueueError } = await supabase.rpc('enqueue_email' as never, {
    queue_name: 'transactional_emails',
    payload: {
      message_id: messageId,
      to: effectiveRecipient,
      from: `${SITE_NAME} <noreply@${FROM_DOMAIN}>`,
      sender_domain: SENDER_DOMAIN,
      subject: resolvedSubject,
      html,
      text: plainText,
      purpose: 'transactional',
      label: args.templateName,
      idempotency_key: idempotencyKey,
      unsubscribe_token: unsubscribeToken,
      queued_at: new Date().toISOString(),
    },
  } as never)

  if (enqueueError) {
    await supabase.from('email_send_log' as never).insert({
      message_id: messageId,
      template_name: args.templateName,
      recipient_email: effectiveRecipient,
      status: 'failed',
      error_message: 'Failed to enqueue email',
    } as never)
    throw new Error(`Failed to enqueue email: ${enqueueError.message}`)
  }

  return { success: true, queued: true, messageId }
}