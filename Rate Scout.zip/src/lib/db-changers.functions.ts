import { createServerFn } from "@tanstack/react-start";

export interface DbChangerRow {
  id: string;
  slug: string;
  name: string;
  area: string;
  address: string;
  phone: string;
  hours: string;
  website: string | null;
  rating: number;
  reviews: number;
  rate_source_kind: string;
  rate_source_url: string | null;
  rate_json_mapping: Record<string, string> | null;
}

export interface DbRateRow {
  changer_id: string;
  code: string;
  unit: number;
  buy: number;
  sell: number;
  updated_at: string;
}

export const getDbChangers = createServerFn({ method: "GET" }).handler(
  async (): Promise<{ changers: DbChangerRow[]; rates: DbRateRow[] }> => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [changersRes, ratesRes] = await Promise.all([
      supabaseAdmin
        .from("changers" as never)
        .select(
          "id, slug, name, area, address, phone, hours, website, rating, reviews, rate_source_kind, rate_source_url, rate_json_mapping",
        ),
      supabaseAdmin
        .from("changer_rates" as never)
        .select("changer_id, code, unit, buy, sell, updated_at"),
    ]);
    return {
      changers: ((changersRes.data ?? []) as unknown) as DbChangerRow[],
      rates: ((ratesRes.data ?? []) as unknown) as DbRateRow[],
    };
  },
);