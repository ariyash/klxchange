// Map of ISO 4217 currency code → ISO 3166 country code used by flagcdn.com.
// EUR uses "eu". Codes not listed fall back to the first two letters of the
// currency code lowercased (works for the vast majority of ISO currencies).
export const CURRENCY_COUNTRY: Record<string, string> = {
  USD: "us", EUR: "eu", GBP: "gb", JPY: "jp", CHF: "ch", AUD: "au", NZD: "nz",
  CAD: "ca", SGD: "sg", HKD: "hk", CNY: "cn", TWD: "tw", KRW: "kr", THB: "th",
  IDR: "id", PHP: "ph", VND: "vn", INR: "in", PKR: "pk", BDT: "bd", LKR: "lk",
  NPR: "np", BND: "bn", MOP: "mo", KHR: "kh", MMK: "mm", LAK: "la",
  AED: "ae", SAR: "sa", QAR: "qa", KWD: "kw", BHD: "bh", OMR: "om", JOD: "jo",
  EGP: "eg", TRY: "tr", ZAR: "za", RUB: "ru",
  DKK: "dk", NOK: "no", SEK: "se", CZK: "cz", PLN: "pl", HUF: "hu", RON: "ro",
  MXN: "mx", BRL: "br", ARS: "ar", CLP: "cl",
  MYR: "my",
};

export function currencyCountry(code: string): string {
  const upper = code.toUpperCase();
  return CURRENCY_COUNTRY[upper] ?? upper.slice(0, 2).toLowerCase();
}

export function currencyFlagSrc(code: string, w: 40 | 80 | 160 = 80): string {
  return `https://flagcdn.com/w${w}/${currencyCountry(code)}.png`;
}

export function currencyFlagSrcSet(code: string): string {
  return `https://flagcdn.com/w160/${currencyCountry(code)}.png 2x`;
}

export function currencyFlagFallback(code: string): string {
  return (
    "data:image/svg+xml;utf8," +
    encodeURIComponent(
      `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 30'><rect width='40' height='30' rx='3' fill='%23e2e8f0'/><text x='50%25' y='55%25' font-family='system-ui,sans-serif' font-size='10' font-weight='700' text-anchor='middle' fill='%2364748b'>${code}</text></svg>`,
    )
  );
}