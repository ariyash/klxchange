import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const schema = z.object({
  business_name: z.string().trim().min(1).max(150),
  contact_name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  location: z.string().trim().max(150).optional().or(z.literal("")),
  message: z.string().trim().max(2000).optional().or(z.literal("")),
});

export const submitPublishRate = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => schema.parse(data))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: inserted, error } = await supabaseAdmin
      .from("publish_rate_submissions" as never)
      .insert({
        business_name: data.business_name,
        contact_name: data.contact_name,
        email: data.email,
        phone: data.phone || null,
        location: data.location || null,
        message: data.message || null,
      } as never)
      .select("id, created_at")
      .maybeSingle();
    if (error) throw new Error(error.message);

    // Notify site owner — non-fatal if the email fails.
    try {
      const { sendTransactionalEmailInternal } = await import("@/lib/email/send.server");
      const submissionId = (inserted as any)?.id ?? crypto.randomUUID();
      await sendTransactionalEmailInternal({
        templateName: "publish-rate-notification",
        idempotencyKey: `publish-rate-${submissionId}`,
        templateData: {
          business_name: data.business_name,
          contact_name: data.contact_name,
          email: data.email,
          phone: data.phone || null,
          location: data.location || null,
          message: data.message || null,
          submitted_at: (inserted as any)?.created_at ?? new Date().toISOString(),
        },
      });
    } catch (emailError) {
      console.error("Failed to send publish-rate notification email", emailError);
    }

    return { ok: true } as const;
  });