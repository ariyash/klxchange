import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles" as never)
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: admin role required");
}

export const getMyRole = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin
      .from("user_roles" as never)
      .select("role")
      .eq("user_id", context.userId);
    const roles = ((data ?? []) as unknown as Array<{ role: string }>).map((r) => r.role);
    return { isAdmin: roles.includes("admin"), roles };
  });

export const listAdminChangers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [{ data: changers }, { data: rates }] = await Promise.all([
      supabaseAdmin
        .from("changers" as never)
        .select("*")
        .order("created_at", { ascending: false }),
      supabaseAdmin.from("changer_rates" as never).select("changer_id, code, buy, sell, updated_at"),
    ]);
    return { changers: changers ?? [], rates: rates ?? [] };
  });

const ChangerSchema = z.object({
  id: z.string().uuid().optional(),
  slug: z.string().min(1).max(120).regex(/^[a-z0-9-]+$/, "lowercase letters, numbers and dashes"),
  name: z.string().min(1).max(200),
  area: z.string().min(1).max(120),
  address: z.string().max(500).default(""),
  phone: z.string().max(50).default(""),
  hours: z.string().max(120).default(""),
  website: z.string().url().nullable().optional(),
  rating: z.number().min(0).max(5).default(0),
  reviews: z.number().int().min(0).default(0),
  rate_source_kind: z.enum(["csv", "klmc", "auto", "json", "antaraduit", "eglobex", "infinity", "saujana", "gsheet", "moneywave"]),
  rate_source_url: z.string().url().nullable().optional(),
  rate_json_mapping: z
    .object({
      list: z.string(),
      code: z.string(),
      unit: z.string().optional(),
      buy: z.string(),
      sell: z.string(),
    })
    .nullable()
    .optional(),
});

export const upsertChanger = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => ChangerSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { id, ...rest } = data;
    const payload: Record<string, unknown> = { ...rest, created_by: context.userId };
    if (id) payload.id = id;
    const { data: row, error } = await supabaseAdmin
      .from("changers" as never)
      .upsert(payload as never, { onConflict: "slug" })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: (row as unknown as { id: string }).id };
  });

export const deleteChanger = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("changers" as never).delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

function parseCsv(csv: string): Array<{ code: string; unit: number; buy: number; sell: number }> {
  const lines = csv
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  const out: Array<{ code: string; unit: number; buy: number; sell: number }> = [];
  for (const line of lines) {
    const cells = line.split(/[,\t;]/).map((c) => c.trim());
    if (cells.length < 3) continue;
    const code = cells[0].toUpperCase();
    if (!/^[A-Z]{3}$/.test(code)) continue; // skip header / bad rows
    const unit = cells.length >= 4 ? Number(cells[1]) || 1 : 1;
    const buy = Number(cells[cells.length - 2]);
    const sell = Number(cells[cells.length - 1]);
    if (!isFinite(buy) || !isFinite(sell)) continue;
    out.push({ code, unit, buy, sell });
  }
  return out;
}

function resolvePath(obj: unknown, path: string): unknown {
  return path.split(".").reduce<unknown>((acc, part) => {
    if (acc == null) return undefined;
    if (Array.isArray(acc)) return acc[Number(part)];
    return (acc as Record<string, unknown>)[part];
  }, obj);
}

export const ingestRates = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: unknown) =>
    z
      .object({
        changerId: z.string().uuid(),
        csv: z.string().optional(),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: changer, error: cErr } = await supabaseAdmin
      .from("changers" as never)
      .select("id, rate_source_kind, rate_source_url, rate_json_mapping")
      .eq("id", data.changerId)
      .single();
    if (cErr || !changer) throw new Error(cErr?.message ?? "Changer not found");
    const c = changer as unknown as {
      id: string;
      rate_source_kind: string;
      rate_source_url: string | null;
      rate_json_mapping: { list: string; code: string; unit?: string; buy: string; sell: string } | null;
    };

    let rows: Array<{ code: string; unit: number; buy: number; sell: number }> = [];

    if (c.rate_source_kind === "csv") {
      if (!data.csv) throw new Error("CSV content required");
      rows = parseCsv(data.csv);
    } else if (c.rate_source_kind === "klmc") {
      if (!c.rate_source_url) throw new Error("Source URL required");
      const { scrapeKlmc } = await import("@/lib/scraper.server");
      const scraped = await scrapeKlmc(c.rate_source_url);
      rows = scraped.map((r) => ({ code: r.code, unit: r.unit, buy: r.buy, sell: r.sell }));
    } else if (c.rate_source_kind === "auto") {
      if (!c.rate_source_url) throw new Error("Source URL required");
      const { scrapeAuto } = await import("@/lib/scraper.server");
      const scraped = await scrapeAuto(c.rate_source_url);
      rows = scraped.map((r) => ({ code: r.code, unit: r.unit, buy: r.buy, sell: r.sell }));
    } else if (c.rate_source_kind === "antaraduit") {
      if (!c.rate_source_url) throw new Error("Source URL required");
      const { scrapeAntaraduit } = await import("@/lib/scraper.server");
      const scraped = await scrapeAntaraduit(c.rate_source_url);
      rows = scraped.map((r) => ({ code: r.code, unit: r.unit, buy: r.buy, sell: r.sell }));
    } else if (c.rate_source_kind === "eglobex") {
      if (!c.rate_source_url) throw new Error("Source URL required");
      const { scrapeEglobex } = await import("@/lib/scraper.server");
      const scraped = await scrapeEglobex(c.rate_source_url);
      rows = scraped.map((r) => ({ code: r.code, unit: r.unit, buy: r.buy, sell: r.sell }));
    } else if (c.rate_source_kind === "infinity") {
      if (!c.rate_source_url) throw new Error("Source URL required");
      const { scrapeInfinity } = await import("@/lib/scraper.server");
      const scraped = await scrapeInfinity(c.rate_source_url);
      rows = scraped.map((r) => ({ code: r.code, unit: r.unit, buy: r.buy, sell: r.sell }));
    } else if (c.rate_source_kind === "saujana") {
      if (!c.rate_source_url) throw new Error("Source URL required");
      const { scrapeSaujana } = await import("@/lib/scraper.server");
      const scraped = await scrapeSaujana(c.rate_source_url);
      rows = scraped.map((r) => ({ code: r.code, unit: r.unit, buy: r.buy, sell: r.sell }));
    } else if (c.rate_source_kind === "moneywave") {
      if (!c.rate_source_url) throw new Error("Source URL required");
      const { scrapeMoneywave } = await import("@/lib/scraper.server");
      const scraped = await scrapeMoneywave(c.rate_source_url);
      rows = scraped.map((r) => ({ code: r.code, unit: r.unit, buy: r.buy, sell: r.sell }));
    } else if (c.rate_source_kind === "gsheet") {
      if (!c.rate_source_url) throw new Error("Source URL required");
      const { scrapeGsheet } = await import("@/lib/scraper.server");
      const scraped = await scrapeGsheet(c.rate_source_url);
      rows = scraped.map((r) => ({ code: r.code, unit: r.unit, buy: r.buy, sell: r.sell }));
    } else if (c.rate_source_kind === "json") {
      if (!c.rate_source_url || !c.rate_json_mapping) {
        throw new Error("URL and JSON mapping required");
      }
      const res = await fetch(c.rate_source_url, { headers: { Accept: "application/json" } });
      if (!res.ok) throw new Error(`Fetch failed: ${res.status}`);
      const json = (await res.json()) as unknown;
      const list = resolvePath(json, c.rate_json_mapping.list);
      if (!Array.isArray(list)) throw new Error(`Mapping 'list' did not resolve to an array`);
      for (const item of list) {
        const code = String(resolvePath(item, c.rate_json_mapping.code) ?? "").toUpperCase();
        const unit = Number(
          c.rate_json_mapping.unit ? resolvePath(item, c.rate_json_mapping.unit) : 1,
        );
        const buy = Number(resolvePath(item, c.rate_json_mapping.buy));
        const sell = Number(resolvePath(item, c.rate_json_mapping.sell));
        if (!/^[A-Z]{3}$/.test(code) || !isFinite(buy) || !isFinite(sell)) continue;
        rows.push({ code, unit: isFinite(unit) && unit > 0 ? unit : 1, buy, sell });
      }
    } else {
      throw new Error(`Unknown rate source: ${c.rate_source_kind}`);
    }

    if (rows.length === 0) throw new Error("No valid rate rows parsed");

    const now = new Date().toISOString();
    const upserts = rows.map((r) => ({ ...r, changer_id: c.id, updated_at: now }));
    const { error: upErr } = await supabaseAdmin
      .from("changer_rates" as never)
      .upsert(upserts as never, { onConflict: "changer_id,code" });
    if (upErr) throw new Error(upErr.message);
    return { ok: true, count: rows.length };
  });