// Server-only scraping helpers. Do NOT import from client components.

export interface LiveRate {
  code: string;
  name: string;
  unit: number; // e.g. 1, 100, 1000, 1_000_000
  buy: number; // MYR you receive per `unit` of foreign currency
  sell: number;
  updatedAt: string; // ISO or original "YYYY-MM-DD H:MM AM/PM" from source
}

const UA = "Mozilla/5.0 (compatible; KlexchangeBot/1.0; +https://klexchange.app)";
const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0 Safari/537.36";

/**
 * Reference mid-market MYR per 1 unit. Used only to sanity-check the unit
 * scale that scrapers infer — low-denomination currencies (IDR/VND/KRW) are
 * often listed without an explicit "per 1,000,000" label and the extractor
 * defaults `unit` to 1, which makes display rates 1,000,000x too large.
 */
const REF_PER_UNIT_MYR: Record<string, number> = {
  USD: 4.71, SGD: 3.49, EUR: 5.09, GBP: 5.95, AUD: 3.07, CAD: 3.4, NZD: 2.7,
  CHF: 5.2, JPY: 0.0305, KRW: 0.0034, THB: 0.132, IDR: 0.00029, VND: 0.00018,
  CNY: 0.65, HKD: 0.60, TWD: 0.146, INR: 0.056, PHP: 0.082, BND: 3.49,
  MMK: 0.00224, KHR: 0.00115, LAK: 0.00022, NPR: 0.035, PKR: 0.017, BDT: 0.039,
  LKR: 0.016, AED: 1.28, SAR: 1.25, QAR: 1.29, KWD: 15.3, OMR: 12.2, BHD: 12.5,
  EGP: 0.097, ZAR: 0.26, TRY: 0.12, RUB: 0.053, BRL: 0.83, MXN: 0.24,
};

/**
 * Normalize a scraped rate so `buy/unit` lands within ~3x of the reference
 * mid-market value. Adjusts `unit` by powers of 10 when the per-unit value
 * is wildly off (only when we have a reference for the code).
 */
export function normalizeRateScale(r: LiveRate): LiveRate {
  const ref = REF_PER_UNIT_MYR[r.code];
  if (!ref || !isFinite(r.buy) || r.buy <= 0) return r;
  let unit = r.unit > 0 ? r.unit : 1;
  let per = r.buy / unit;
  // Find power-of-10 factor that brings per closest (in log space) to ref.
  const k = Math.round(Math.log10(per / ref));
  if (k !== 0) {
    const factor = Math.pow(10, k);
    unit = unit * factor;
    per = r.buy / unit;
  }
  // Only accept if result is within 5x of reference, else leave untouched.
  if (per / ref > 5 || ref / per > 5) return r;
  return { ...r, unit };
}

async function getText(url: string, init?: RequestInit) {
  const maxAttempts = 3;
  let lastErr: unknown;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    if (attempt > 0) {
      // Exponential backoff with jitter: 300ms, 900ms, ...
      const delay = 300 * Math.pow(3, attempt - 1) + Math.floor(Math.random() * 150);
      await new Promise((r) => setTimeout(r, delay));
    }
    try {
      const res = await fetch(url, {
        ...init,
        headers: {
          "User-Agent": UA,
          Accept: "text/html,application/json,*/*",
          ...(init?.headers ?? {}),
        },
      });
      if (!res.ok) {
        // Retry on 5xx and 429; fail fast on other 4xx
        if (res.status >= 500 || res.status === 429) {
          lastErr = new Error(`Fetch ${url} -> ${res.status}`);
          continue;
        }
        throw new Error(`Fetch ${url} -> ${res.status}`);
      }
      return await res.text();
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error(String(lastErr));
}

/** klmoneychanger.com profile page (e.g. /maxmoney/midvalley-megamall) */
export async function scrapeKlmc(url: string): Promise<LiveRate[]> {
  const html = await getText(url);
  return parseKlmcProfileHtml(html);
}

function parseKlmcProfileHtml(html: string): LiveRate[] {
  const rows: LiveRate[] = [];
  const seen = new Set<string>();

  // Match each rate row. Currencies appear twice (responsive). Dedupe by code.
  const rowRe =
    /font-size:\s*2\.5vh;?">([A-Z]{3})<\/span>\s*<br>\s*<span[^>]*>([^<]+)<\/span>[\s\S]*?<td style="font-size:\s*2\.5vh">([^<]+)<\/td>\s*<td style="font-size:\s*3vh;color:green">([\d.]+)<\/td>\s*<td style="font-size:\s*3vh;color:red">([\d.]+)<\/td>\s*<td class="hidden-xs">([^<]+)<\/td>/g;

  let m: RegExpExecArray | null;
  while ((m = rowRe.exec(html))) {
    const [, code, name, unitRaw, buy, sell, updated] = m;
    if (seen.has(code)) continue;
    seen.add(code);
    const unit = parseUnit(unitRaw);
    const buyN = parseFloat(buy);
    const sellN = parseFloat(sell);
    if (!isFinite(buyN) || !isFinite(sellN) || buyN <= 0) continue;
    rows.push({ code, name: name.trim(), unit, buy: buyN, sell: sellN, updatedAt: updated.trim() });
  }
  return rows;
}

function stripTags(html: string): string {
  return html
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/\s+/g, " ")
    .trim();
}

function parseMoney(raw: string): number {
  const n = parseFloat(raw.replace(/,/g, "").trim());
  return isFinite(n) ? n : NaN;
}

function normalizeCode(raw: string): string {
  const code = raw.trim().toUpperCase();
  if (code === "EURO") return "EUR";
  if (code === "UAE") return "AED";
  if (code === "BRD") return "BND";
  if (code === "NTD") return "TWD";
  if (code === "WON") return "KRW";
  return code;
}

function parseSimpleTableHtml(html: string): LiveRate[] {
  const rows: LiveRate[] = [];
  const seen = new Set<string>();
  const trRe = /<tr\b[^>]*>([\s\S]*?)<\/tr>/gi;
  let tr: RegExpExecArray | null;
  while ((tr = trRe.exec(html))) {
    const cells = [...tr[1].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map((m) => stripTags(m[1]));
    if (cells.length < 6) continue;
    const offset = cells[0].match(/^[A-Z]{3,4}$/i) ? 0 : 1;
    const unit = parseUnit(cells[offset]);
    const code = normalizeCode(cells[offset + 1] ?? "");
    const name = cells[offset + 2] || code;
    const buy = parseMoney(cells[offset + 3] ?? "");
    const sell = parseMoney(cells[offset + 4] ?? "");
    const updatedAt = cells[offset + 5] || new Date().toISOString();
    if (!/^[A-Z]{3}$/.test(code) || seen.has(code)) continue;
    if (!isFinite(buy) || !isFinite(sell) || buy <= 0 || sell <= 0) continue;
    seen.add(code);
    rows.push({ code, name, unit, buy, sell, updatedAt });
  }
  return rows;
}

function parseKnownHtmlRates(html: string): LiveRate[] {
  const klmcRows = parseKlmcProfileHtml(html);
  return klmcRows.length > 0 ? klmcRows : parseSimpleTableHtml(html);
}

function parseUnit(raw: string): number {
  const s = raw.trim().toUpperCase();
  if (s === "1M" || s === "1,000,000") return 1_000_000;
  if (s.endsWith("MIL") || s.endsWith("M")) {
    const n = parseFloat(s) || 1;
    return n * 1_000_000;
  }
  if (s.endsWith("K")) return parseFloat(s) * 1000;
  const n = parseFloat(s.replace(/,/g, ""));
  return isFinite(n) && n > 0 ? n : 1;
}

/** klremitexchange.com rates.php — table rows of [flag, unit, code, name, buy, sell, updated] */
export async function scrapeKlremit(url: string): Promise<LiveRate[]> {
  const html = await getText(url);
  const rows: LiveRate[] = [];
  const seen = new Set<string>();

  // Match a row by spotting the 3-letter code cell, then its name cell, then two
  // rate cells (buy/sell) wrapped in <div id="rateText">...<a ...>NUMBER</a>,
  // then the "Last Updated" cell.
  const rowRe =
    /<td[^>]*ratesInfoBox[^"]*"[^>]*>\s*(\d[\d,]*)\s*<\/td>\s*<td[^>]*ratesInfoBox[^"]*"[^>]*>\s*([A-Z]{3})\s*<\/td>\s*<td[^>]*ratesInfoBox[^"]*"[^>]*>\s*([^<]+?)\s*<\/td>\s*<td[^>]*>\s*<div[^>]*>\s*<a[^>]*>\s*([\d.]+)\s*<\/?a>?\s*<\/div>\s*<\/td>\s*<td[^>]*>\s*<div[^>]*>\s*<a[^>]*>\s*([\d.]+)\s*<\/a>\s*<\/div>\s*<\/td>\s*<td[^>]*>\s*([^<]+?)\s*<\/td>/g;

  let m: RegExpExecArray | null;
  while ((m = rowRe.exec(html))) {
    const [, unitRaw, code, name, buy, sell, updated] = m;
    if (seen.has(code)) continue;
    seen.add(code);
    const buyN = parseFloat(buy);
    const sellN = parseFloat(sell);
    if (!isFinite(buyN) || !isFinite(sellN) || buyN <= 0) continue;
    const unit = parseUnit(unitRaw);
    void updated; // source timestamp lacks timezone; use server fetch time
    rows.push({ code, name: name.trim(), unit, buy: buyN, sell: sellN, updatedAt: new Date().toISOString() });
  }
  return rows;
}

/** Generic AI-powered scraper. Fetches any URL and uses Lovable AI to extract rates as JSON. */
export async function scrapeAuto(url: string): Promise<LiveRate[]> {
  const apiKey = process.env.LOVABLE_API_KEY;
  const html = await getText(url);
  const htmlRates = parseKnownHtmlRates(html);
  if (htmlRates.length > 0) return htmlRates;
  if (!apiKey) throw new Error("LOVABLE_API_KEY not configured");
  // Strip scripts/styles and collapse to keep token usage small.
  const cleaned = html
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/\s+/g, " ")
    .slice(0, 60000);

  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash",
      messages: [
        {
          role: "system",
          content:
            "You extract foreign-currency exchange rate tables from HTML for a Malaysian money changer. Return ONLY a JSON object with key 'rates' whose value is an array of items: { code: 3-letter ISO currency code, unit: number (usually 1, sometimes 100 for JPY/KRW or 1000), buy: number (MYR per unit, what the changer pays customer), sell: number (MYR per unit, what changer sells at) }. Skip rows that aren't currencies. Never invent numbers.",
        },
        { role: "user", content: `URL: ${url}\n\nHTML:\n${cleaned}` },
      ],
      response_format: { type: "json_object" },
    }),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    if (res.status === 402 || /payment_required|not enough credits/i.test(text)) {
      throw new Error(
        "AI_CREDITS_EXHAUSTED: The AI rate-extraction service has run out of credits. Add credits in Settings → Workspace → Plans & Credits, then try Refresh again.",
      );
    }
    if (res.status === 429) {
      throw new Error("AI_RATE_LIMITED: AI service is rate-limited right now. Wait a moment and try Refresh again.");
    }
    throw new Error(`AI gateway ${res.status}: ${text.slice(0, 200)}`);
  }
  const data = (await res.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const content = data.choices?.[0]?.message?.content ?? "{}";
  let parsed: { rates?: Array<{ code: string; unit?: number; buy: number; sell: number }> };
  try {
    parsed = JSON.parse(content);
  } catch {
    throw new Error("AI returned invalid JSON");
  }
  const out: LiveRate[] = [];
  const seen = new Set<string>();
  for (const r of parsed.rates ?? []) {
    const code = String(r.code ?? "").toUpperCase();
    if (!/^[A-Z]{3}$/.test(code) || seen.has(code)) continue;
    const buy = Number(r.buy);
    const sell = Number(r.sell);
    if (!isFinite(buy) || !isFinite(sell) || buy <= 0) continue;
    const unit = Number(r.unit) > 0 ? Number(r.unit) : 1;
    seen.add(code);
    out.push({ code, name: code, unit, buy, sell, updatedAt: new Date().toISOString() });
  }
  if (out.length === 0) throw new Error("AI extraction returned no valid rates");
  return out;
}

/** Placid Express — uses a public Supabase REST endpoint we discovered in their bundle. */
const PLACID_SUPABASE = "https://mfipdmeydutqcmdsoedx.supabase.co";
const PLACID_KEY = "sb_publishable_cryufxumNz8cXU22xqxm8Q_OjbMGetD";

export async function scrapePlacid(branch = "main"): Promise<LiveRate[]> {
  const url = `${PLACID_SUPABASE}/rest/v1/rates?select=code,name,buy_rate,sell_rate,updated_at,sort_order&branch=eq.${branch}&order=sort_order.asc`;
  const res = await fetch(url, {
    headers: { apikey: PLACID_KEY, Authorization: `Bearer ${PLACID_KEY}` },
  });
  if (!res.ok) throw new Error(`Placid API ${res.status}`);
  const data = (await res.json()) as Array<{
    code: string;
    name: string;
    buy_rate: number | string;
    sell_rate: number | string;
    updated_at: string;
  }>;
  const out: LiveRate[] = [];
  for (const r of data) {
    const code = normalizeCode(r.code ?? "");
    if (!/^[A-Z]{3}$/.test(code) || code === "MYR") continue;
    const buy = Number(r.buy_rate);
    const sell = Number(r.sell_rate);
    if (!isFinite(buy) || !isFinite(sell) || buy <= 0 || sell <= 0) continue;
    // Skip placeholder rows where the branch has no real rate for this
    // currency (Placid stores these as buy == sell, e.g. 1.0/1.0 for BND
    // on branches that don't actually trade it).
    if (buy === sell) continue;
    out.push({
      code,
      name: (r.name ?? code).replace(/\s*\(per[^)]*\)\s*/i, "").trim() || code,
      unit: unitFromName(r.name ?? ""),
      buy,
      sell,
      updatedAt: r.updated_at,
    });
  }
  return out;
}

function unitFromName(name: string): number {
  const m = name.match(/per\s+([\d,]+)/i);
  if (!m) return 1;
  return parseInt(m[1].replace(/,/g, ""), 10) || 1;
}

/** Antaraduit (antaraduit.com.my) — branch-keyed AJAX endpoint.
 * URL format: https://www.antaraduit.com.my/get_branch_units.php?val=<branchId>
 * Branch ids: 1 = HQ Tun Razak, 3 = Shah Alam, 4 = Avenue K (KLCC). */
export async function scrapeAntaraduit(url: string): Promise<LiveRate[]> {
  const u = new URL(url);
  const val = u.searchParams.get("val") ?? "4";
  const endpoint = `${u.origin}/get_branch_units.php`;
  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "User-Agent": BROWSER_UA,
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Requested-With": "XMLHttpRequest",
      Referer: `${u.origin}/exchange-rates.php`,
      Accept: "text/html, */*; q=0.01",
      "Accept-Language": "en-US,en;q=0.9",
    },
    body: `val=${encodeURIComponent(val)}`,
  });
  if (!res.ok) throw new Error(`Antaraduit ${res.status}`);
  const html = await res.text();
  const out: LiveRate[] = [];
  const seen = new Set<string>();
  // Row shape: <td><img.../></td> <td>UNIT</td> <td>CODE</td> <td>NAME</td> <td>BUY</td> <td>SELL</td> <td>UPDATED</td>
  const rowRe =
    /<td>\s*<img[^>]*flags\/[A-Z]{3}\.png[^>]*>\s*<\/td>[\s\S]*?<td>\s*(\d[\d,]*)\s*<\/td>\s*<td>\s*([A-Z]{3})\s*<\/td>\s*<td>\s*([^<]+?)\s*<\/td>\s*<td>\s*([\d.]+)\s*<\/td>\s*<td>\s*([\d.]+)\s*<\/td>\s*<td>\s*([^<]+?)\s*<\/td>/g;
  let m: RegExpExecArray | null;
  while ((m = rowRe.exec(html))) {
    const [, unitRaw, rawCode, name, buy, sell] = m;
    const code = normalizeCode(rawCode);
    if (seen.has(code)) continue;
    const buyN = parseFloat(buy);
    const sellN = parseFloat(sell);
    if (!isFinite(buyN) || !isFinite(sellN) || buyN <= 0) continue;
    const unit = parseUnit(unitRaw);
    seen.add(code);
    out.push({ code, name: name.trim(), unit, buy: buyN, sell: sellN, updatedAt: new Date().toISOString() });
  }
  if (out.length === 0) throw new Error("Antaraduit: no rates parsed");
  return out;
}

/** E-Globex (e-globex.com.my) — branch pages /rates (Kepong) and /timessquare. */
export async function scrapeEglobex(url: string): Promise<LiveRate[]> {
  const html = await getText(url);
  const out: LiveRate[] = [];
  const seen = new Set<string>();
  // Map filename codes to ISO codes; some image names differ from ISO.
  const codeMap: Record<string, string> = {
    USB: "USD", // USD large bills row — preferred over the small-bills USD row
    SAS: "SAR", // duplicate Saudi Riyal row
    NTD: "TWD",
  };
  // Row: <td class="text-left"><img src="json/publish/img/CODE.jpg"...> UNIT-TEXT NAME</td>
  //      <td ... rate buy">BUY</td><td ... rate" ...>SELL</td>
  const rowRe =
    /<img\s+src="json\/publish\/img\/([A-Z]+)\.jpg"[^>]*>\s*([^<]+?)<\/td>\s*<td[^>]*rate\s+buy[^>]*>\s*([\d.,]+)\s*<\/td>\s*<td[^>]*class="[^"]*rate[^"]*"[^>]*>\s*([\d.,]+)\s*<\/td>/g;
  let m: RegExpExecArray | null;
  while ((m = rowRe.exec(html))) {
    const [, rawCode, label, buy, sell] = m;
    const code = (codeMap[rawCode] ?? rawCode).toUpperCase();
    if (!/^[A-Z]{3}$/.test(code) || seen.has(code)) continue;
    const buyN = parseFloat(buy.replace(/,/g, ""));
    const sellN = parseFloat(sell.replace(/,/g, ""));
    if (!isFinite(buyN) || !isFinite(sellN) || buyN <= 0) continue;
    // Parse leading unit from the label text, e.g. "1", "100", "1,000", "1 Million".
    const t = label.trim();
    let unit = 1;
    const mil = t.match(/^([\d,.]+)\s*Million/i);
    if (mil) {
      unit = (parseFloat(mil[1].replace(/,/g, "")) || 1) * 1_000_000;
    } else {
      const n = t.match(/^([\d,.]+)/);
      if (n) unit = parseFloat(n[1].replace(/,/g, "")) || 1;
    }
    const name = t.replace(/^[\d,.\s]+(Million\s+)?/i, "").trim() || code;
    seen.add(code);
    out.push({ code, name, unit, buy: buyN, sell: sellN, updatedAt: new Date().toISOString() });
  }
  if (out.length === 0) throw new Error("E-Globex: no rates parsed");
  return out;
}

/** Infinity Exchange (infinityexchange.com.my) — TablePress with 10-column rows
 * containing two currencies each. Flag image filename gives ISO code. */
export async function scrapeInfinity(url: string): Promise<LiveRate[]> {
  const html = await getText(url);
  const flagMap: Record<string, string> = {
    us: "USD", eu: "EUR", gb: "GBP", nz: "NZD", au: "AUD", sg: "SGD",
    bn: "BND", ch: "CHF", ca: "CAD", sa: "SAR", ae: "AED", qa: "QAR",
    bh: "BHD", om: "OMR", kw: "KWD", eg: "EGP", tr: "TRY", ph: "PHP",
    in: "INR", jp: "JPY", cn: "CNY", hk: "HKD", th: "THB", id: "IDR",
    kr: "KRW", tw: "TWD", vn: "VND", dk: "DKK", no: "NOK", se: "SEK",
    mo: "MOP", jo: "JOD", lk: "LKR", za: "ZAR", pk: "PKR", bd: "BDT",
    ru: "RUB", np: "NPR", cz: "CZK", kh: "KHR",
  };
  // Isolate first tablepress table to avoid the duplicate mobile copy.
  const tStart = html.indexOf('id="tablepress-1"');
  const tEnd = html.indexOf("</table>", tStart);
  const body = tStart >= 0 ? html.slice(tStart, tEnd) : html;
  const out: LiveRate[] = [];
  const seen = new Set<string>();
  const trRe = /<tr[^>]*>([\s\S]*?)<\/tr>/g;
  let tm: RegExpExecArray | null;
  while ((tm = trRe.exec(body))) {
    const row = tm[1];
    // Skip header (no <img>).
    if (!/<img/i.test(row)) continue;
    const cellRe = /<td[^>]*class="column-(\d+)"[^>]*>([\s\S]*?)<\/td>/g;
    const cells: Record<number, string> = {};
    let cm: RegExpExecArray | null;
    while ((cm = cellRe.exec(row))) cells[Number(cm[1])] = cm[2];
    for (const offset of [0, 5]) {
      const flagHtml = cells[1 + offset] ?? "";
      const unitRaw = (cells[2 + offset] ?? "").replace(/<[^>]+>/g, "").trim();
      const buyRaw = (cells[4 + offset] ?? "").replace(/<[^>]+>/g, "").trim();
      const sellRaw = (cells[5 + offset] ?? "").replace(/<[^>]+>/g, "").trim();
      const flagM = flagHtml.match(/\/([a-z]{2})\.png/i);
      if (!flagM) continue;
      const code = flagMap[flagM[1].toLowerCase()];
      if (!code || seen.has(code)) continue;
      const buy = parseFloat(buyRaw.replace(/,/g, ""));
      const sell = parseFloat(sellRaw.replace(/,/g, ""));
      if (!isFinite(buy) || !isFinite(sell) || buy <= 0) continue;
      const unit = parseUnit(unitRaw);
      seen.add(code);
      out.push({ code, name: code, unit, buy, sell, updatedAt: new Date().toISOString() });
    }
  }
  if (out.length === 0) throw new Error("Infinity: no rates parsed");
  return out;
}

/** Saujana Hirisan (saujanahirisan.com.my) — branch-keyed JSON endpoint.
 * Source URL format: https://saujanahirisan.com.my/ajax-exchange-rate.php?branch_id=11
 * Branch ids: 11 = Main Place Mall HQ, 12 = Taipan, 13 = KLGCC Mall. */
export async function scrapeSaujana(url: string): Promise<LiveRate[]> {
  const u = new URL(url);
  const branchId = u.searchParams.get("branch_id") ?? "11";
  const endpoint = `${u.origin}/ajax-exchange-rate.php`;
  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/x-www-form-urlencoded",
      "X-Requested-With": "XMLHttpRequest",
      Referer: `${u.origin}/exchange-rate.php`,
      Accept: "application/json, text/javascript, */*; q=0.01",
    },
    body: `branch_id=${encodeURIComponent(branchId)}`,
  });
  if (!res.ok) throw new Error(`Saujana ${res.status}`);
  const data = (await res.json()) as Array<{
    cur_flag: string;
    cur_name: string;
    cur_unit: string | number;
    buy_val: string | number;
    sell_val: string | number;
    site_display?: string;
  }>;
  const flagMap: Record<string, string> = {
    usd: "USD", eur: "EUR", gbp: "GBP", aud: "AUD", sgd: "SGD", jpy: "JPY",
    thb: "THB", idr: "IDR", cny: "CNY", hkd: "HKD", nzd: "NZD", chf: "CHF",
    cad: "CAD", krw: "KRW", twd: "TWD", vnd: "VND", php: "PHP", aed: "AED",
    sar: "SAR", bhd: "BHD", bnd: "BND", dkk: "DKK", egp: "EGP", jod: "JOD",
    kwd: "KWD", mop: "MOP", mac: "MOP", nok: "NOK", omr: "OMR", qar: "QAR",
    zar: "ZAR", lkr: "LKR", sek: "SEK", try: "TRY", pkr: "PKR", bdt: "BDT",
    rub: "RUB", npr: "NPR", czk: "CZK", khr: "KHR", ind: "INR", inr: "INR",
  };
  const out: LiveRate[] = [];
  const seen = new Set<string>();
  for (const row of data) {
    if (row.site_display !== undefined && String(row.site_display) === "0") continue;
    const key = String(row.cur_flag ?? "").replace(/\.png$/i, "").toLowerCase();
    const code = flagMap[key];
    if (!code || seen.has(code)) continue;
    const buy = Number(row.buy_val);
    const sell = Number(row.sell_val);
    if (!isFinite(buy) || !isFinite(sell) || buy <= 0) continue;
    const unit = Number(row.cur_unit) > 0 ? Number(row.cur_unit) : 1;
    const name = String(row.cur_name ?? code).replace(/\s*\([^)]*\)\s*$/, "").trim() || code;
    seen.add(code);
    out.push({ code, name, unit, buy, sell, updatedAt: new Date().toISOString() });
  }
  if (out.length === 0) throw new Error("Saujana: no rates parsed");
  return out;
}

/** MS Nationwide Exchange — data lives in a public Firestore collection.
 * Source URL format:
 *   https://firestore.googleapis.com/v1/projects/<PROJECT>/databases/<DB>/documents:runQuery?key=<API_KEY>
 * The collection is "rates" with fields: code, name, unit, buy, sell, active, updatedAt. */
export async function scrapeMsFirestore(url: string): Promise<LiveRate[]> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", "User-Agent": BROWSER_UA },
    body: JSON.stringify({
      structuredQuery: { from: [{ collectionId: "rates" }], limit: 200 },
    }),
  });
  if (!res.ok) throw new Error(`MS Firestore ${res.status}`);
  const data = (await res.json()) as Array<{
    document?: {
      fields?: Record<string, { stringValue?: string; doubleValue?: number; integerValue?: string; booleanValue?: boolean; timestampValue?: string }>;
    };
  }>;
  type Cand = { rate: LiveRate; ts: number };
  const best = new Map<string, Cand>();
  for (const row of data) {
    const f = row.document?.fields;
    if (!f) continue;
    if (f.active && f.active.booleanValue === false) continue;
    const rawCode = f.code?.stringValue ?? "";
    // Skip variants like EUR_S, USD_L — keep only base 3-letter codes.
    if (!/^[A-Z]{3}$/.test(rawCode)) continue;
    const code = normalizeCode(rawCode);
    const buy = Number(f.buy?.doubleValue ?? f.buy?.integerValue ?? NaN);
    const sell = Number(f.sell?.doubleValue ?? f.sell?.integerValue ?? NaN);
    if (!isFinite(buy) || !isFinite(sell) || buy <= 0) continue;
    // Sanity: at a money changer, sell >= buy. Drops stale placeholder rows.
    if (sell < buy) continue;
    const unit = Number(f.unit?.integerValue ?? f.unit?.doubleValue ?? 1) || 1;
    const name = f.name?.stringValue ?? code;
    const updatedAt = f.updatedAt?.timestampValue ?? new Date().toISOString();
    const ts = Date.parse(updatedAt) || 0;
    const prev = best.get(code);
    if (!prev || ts > prev.ts) best.set(code, { rate: { code, name, unit, buy, sell, updatedAt }, ts });
  }
  const out = [...best.values()].map((c) => c.rate);
  if (out.length === 0) throw new Error("MS Firestore: no rates parsed");
  return out;
}

/** Google Sheets — accepts any Google Sheets URL (edit / view / pub) and
 * fetches the sheet as CSV. The sheet must be shared "Anyone with the link
 * can view" (or published to web). Expected columns per row:
 *   code, buy, sell                — unit defaults to 1
 *   code, unit, buy, sell          — explicit unit
 * A header row is optional and auto-skipped.
 */
export async function scrapeGsheet(url: string): Promise<LiveRate[]> {
  const csvUrl = toGsheetCsvUrl(url);
  // Cache-bust both upstream CDN and the Worker fetch cache — without this,
  // edits in the sheet can take minutes to surface.
  const bust = `${csvUrl}${csvUrl.includes("?") ? "&" : "?"}_=${Date.now()}`;
  const res = await fetch(bust, {
    headers: {
      "User-Agent": BROWSER_UA,
      Accept: "text/csv,text/plain,*/*",
      "Cache-Control": "no-cache",
      Pragma: "no-cache",
    },
    redirect: "follow",
    cache: "no-store",
  });
  if (!res.ok) {
    throw new Error(
      `Google Sheets fetch failed: ${res.status}. Make sure the sheet is shared "Anyone with the link can view".`,
    );
  }
  const csv = await res.text();
  const lines = csv.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const rows: LiveRate[] = [];
  const now = new Date().toISOString();
  for (const line of lines) {
    const cells = parseCsvLine(line).map((c) => c.trim());
    if (cells.length < 3) continue;
    const code = cells[0].toUpperCase();
    if (!/^[A-Z]{3}$/.test(code)) continue; // skip headers / bad rows
    let unit = 1;
    let buy: number;
    let sell: number;
    if (cells.length >= 4 && isFinite(Number(cells[1]))) {
      unit = Number(cells[1]) || 1;
      buy = Number(cells[2]);
      sell = Number(cells[3]);
    } else {
      buy = Number(cells[1]);
      sell = Number(cells[2]);
    }
    if (!isFinite(buy) || !isFinite(sell)) continue;
    rows.push({ code, name: code, unit, buy, sell, updatedAt: now });
  }
  if (rows.length === 0) {
    throw new Error(
      "Google Sheets: no valid rate rows. Expected columns: code, [unit,] buy, sell.",
    );
  }
  return rows;
}

function toGsheetCsvUrl(input: string): string {
  const url = input.trim();
  // Already a CSV export
  if (/output=csv|format=csv/i.test(url)) return url;
  // /spreadsheets/d/{id}/...  → export?format=csv&gid={gid}
  const idMatch = url.match(/\/spreadsheets\/d\/([a-zA-Z0-9_-]+)/);
  if (idMatch) {
    const id = idMatch[1];
    const gidMatch = url.match(/[#&?]gid=([0-9]+)/);
    const gid = gidMatch ? gidMatch[1] : "0";
    return `https://docs.google.com/spreadsheets/d/${id}/export?format=csv&gid=${gid}`;
  }
  // /spreadsheets/d/e/{pubId}/pubhtml → /pub?gid=...&single=true&output=csv
  const pubMatch = url.match(/\/spreadsheets\/d\/e\/([a-zA-Z0-9_-]+)/);
  if (pubMatch) {
    const pubId = pubMatch[1];
    const gidMatch = url.match(/[#&?]gid=([0-9]+)/);
    const gid = gidMatch ? gidMatch[1] : "0";
    return `https://docs.google.com/spreadsheets/d/e/${pubId}/pub?gid=${gid}&single=true&output=csv`;
  }
  return url;
}

/** Moneywave (moneywave.com.my/exchange-rates) — Next.js page that embeds
 * per-branch counter-exchange rates inline in the SSR payload. URL format:
 *   https://moneywave.com.my/exchange-rates           — defaults to first branch
 *   https://moneywave.com.my/exchange-rates?branch=pandan   — case-insensitive
 *     name substring match, e.g. "pandan", "midvalley", "klcc". Also accepts
 *     a raw branch id via ?branch_id=<id>.
 */
export async function scrapeMoneywave(url: string): Promise<LiveRate[]> {
  const u = new URL(url);
  const branchQuery = (u.searchParams.get("branch") ?? "").trim().toLowerCase();
  const branchIdQuery = (u.searchParams.get("branch_id") ?? "").trim();
  // The page itself does not accept these query params — strip them before fetch.
  const fetchUrl = `${u.origin}${u.pathname}`;
  const html = await getText(fetchUrl, { headers: { "User-Agent": BROWSER_UA } });

  // Currencies are encoded as repeated JSON fragments in the SSR script blob,
  // with backslash-escaped quotes. Match the escaped form.
  type Cur = { id: string; code: string; name: string; unit: number };
  const curRe =
    /\\"id\\":\\"([a-z0-9]{16,})\\",\\"code\\":\\"([A-Z]{3})\\",\\"name\\":\\"([^"\\]+)\\",\\"flagPath\\":\\"[^"\\]*\\",\\"variant\\":\\"\$undefined\\",\\"unit\\":(\d+)/g;
  const currencies = new Map<string, Cur>();
  let cm: RegExpExecArray | null;
  while ((cm = curRe.exec(html))) {
    const [, id, code, name, unit] = cm;
    if (!currencies.has(id)) {
      currencies.set(id, { id, code: normalizeCode(code), name, unit: Number(unit) || 1 });
    }
  }

  // Exchanges (branches): [{id, name, address, ...}]
  type Branch = { id: string; name: string };
  const branchRe = /\\"id\\":\\"([a-z0-9]{16,})\\",\\"name\\":\\"([^"\\]+)\\",\\"address\\":\\"/g;
  const branches: Branch[] = [];
  const seenBranchIds = new Set<string>();
  let bm: RegExpExecArray | null;
  while ((bm = branchRe.exec(html))) {
    const [, id, name] = bm;
    if (seenBranchIds.has(id)) continue;
    seenBranchIds.add(id);
    branches.push({ id, name });
  }

  // Rates: "<branchId>":{"<currencyId>":{"counter":{"exchange":[{...buy:N,sell:N}]
  // We capture the slice from each branchId up to the next branchId or end.
  const ratesByBranch = new Map<string, Map<string, { buy: number; sell: number }>>();
  for (const b of branches) {
    const startPattern = new RegExp(`\\\\"${b.id}\\\\":\\{`, "g");
    const startMatch = startPattern.exec(html);
    if (!startMatch) continue;
    // Find the next branch id occurrence to bound the slice.
    let end = html.length;
    for (const ob of branches) {
      if (ob.id === b.id) continue;
      const otherPattern = new RegExp(`\\\\"${ob.id}\\\\":\\{`);
      const m = otherPattern.exec(html.slice(startMatch.index + 1));
      if (m) end = Math.min(end, startMatch.index + 1 + m.index);
    }
    const slice = html.slice(startMatch.index, end);
    const rateRe =
      /\\"([a-z0-9]{16,})\\":\{\\"counter\\":\{\\"exchange\\":\[\{[^}]*\\"buy\\":([\d.]+),\\"sell\\":([\d.]+)/g;
    const map = new Map<string, { buy: number; sell: number }>();
    let rm: RegExpExecArray | null;
    while ((rm = rateRe.exec(slice))) {
      const [, curId, buy, sell] = rm;
      if (currencies.has(curId) && !map.has(curId)) {
        map.set(curId, { buy: Number(buy), sell: Number(sell) });
      }
    }
    if (map.size > 0) ratesByBranch.set(b.id, map);
  }

  if (branches.length === 0 || ratesByBranch.size === 0) {
    throw new Error("Moneywave: could not parse branches/rates from page");
  }

  // Pick branch: explicit id > name substring > first available.
  let chosen = branches.find((b) => ratesByBranch.has(b.id));
  if (branchIdQuery) {
    const byId = branches.find((b) => b.id === branchIdQuery && ratesByBranch.has(b.id));
    if (byId) chosen = byId;
  } else if (branchQuery) {
    const byName = branches.find(
      (b) => ratesByBranch.has(b.id) && b.name.toLowerCase().includes(branchQuery),
    );
    if (byName) chosen = byName;
  }
  if (!chosen) throw new Error("Moneywave: no branch with rates found");

  const rateMap = ratesByBranch.get(chosen.id)!;
  const out: LiveRate[] = [];
  const now = new Date().toISOString();
  for (const [curId, { buy, sell }] of rateMap) {
    const cur = currencies.get(curId);
    if (!cur) continue;
    if (!isFinite(buy) || !isFinite(sell) || buy <= 0 || sell <= 0) continue;
    out.push({ code: cur.code, name: cur.name, unit: cur.unit, buy, sell, updatedAt: now });
  }
  if (out.length === 0) throw new Error("Moneywave: no rates parsed for selected branch");
  return out;
}

function parseCsvLine(line: string): string[] {
  const out: string[] = [];
  let cur = "";
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"') {
        if (line[i + 1] === '"') { cur += '"'; i++; } else { inQuotes = false; }
      } else cur += ch;
    } else {
      if (ch === '"') inQuotes = true;
      else if (ch === "," || ch === ";" || ch === "\t") { out.push(cur); cur = ""; }
      else cur += ch;
    }
  }
  out.push(cur);
  return out;
}
