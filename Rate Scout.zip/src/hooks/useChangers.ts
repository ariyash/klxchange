import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CHANGERS, type MoneyChanger, type Area } from "@/lib/changers";
import { getDbChangers, type DbChangerRow, type DbRateRow } from "@/lib/db-changers.functions";

function toMoneyChanger(row: DbChangerRow): MoneyChanger {
  return {
    slug: row.slug,
    name: row.name,
    area: row.area as Area,
    address: row.address,
    hours: row.hours,
    phone: row.phone,
    rating: Number(row.rating) || 0,
    reviews: row.reviews,
    source:
      row.rate_source_kind === "klmc" && row.rate_source_url
        ? { kind: "klmc", url: row.rate_source_url }
        : { kind: "placid", branch: row.slug }, // placeholder; live rates come from DB
  };
}

export function useAllChangers() {
  const fetch = useServerFn(getDbChangers);
  const { data } = useQuery({
    queryKey: ["db-changers"],
    queryFn: () => fetch(),
    staleTime: 30_000,
    refetchInterval: 60_000,
  });
  const dbChangers = (data?.changers ?? []).map(toMoneyChanger);
  const seedSlugs = new Set(CHANGERS.map((c) => c.slug));
  const merged: MoneyChanger[] = [
    ...CHANGERS,
    ...dbChangers.filter((c) => !seedSlugs.has(c.slug)),
  ];
  return { changers: merged, dbRates: data?.rates ?? ([] as DbRateRow[]) };
}