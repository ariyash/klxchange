import { currencyFlagFallback, currencyFlagSrc, currencyFlagSrcSet } from "@/lib/currency-flags";

export function CurrencyFlag({
  code,
  className = "h-5 w-7 rounded-sm bg-secondary object-cover shadow-sm",
}: {
  code: string;
  className?: string;
}) {
  return (
    <img
      src={currencyFlagSrc(code)}
      srcSet={currencyFlagSrcSet(code)}
      alt={`${code} flag`}
      loading="lazy"
      width={40}
      height={30}
      className={className}
      onError={(e) => {
        const img = e.currentTarget;
        img.onerror = null;
        img.removeAttribute("srcset");
        img.src = currencyFlagFallback(code);
      }}
    />
  );
}