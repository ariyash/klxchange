import { useEffect, useRef, useState } from "react";

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

type AdVariant = "auto" | "fluid";

export function AdSlot({
  className,
  variant = "auto",
  slot,
  layoutKey,
}: {
  className?: string;
  variant?: AdVariant;
  slot?: string;
  layoutKey?: string;
}) {
  const adRef = useRef<HTMLModElement | null>(null);
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted || !adRef.current) return;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
      // ignore
    }
  }, [mounted]);

  if (!mounted) return <div className={className} aria-hidden="true" suppressHydrationWarning />;

  if (variant === "fluid") {
    return (
      <div className={className}>
        <ins
          ref={adRef}
          suppressHydrationWarning
          className="adsbygoogle"
          style={{ display: "block" }}
          data-ad-format="fluid"
          data-ad-layout-key={layoutKey ?? "-gw-3+1f-3d+2z"}
          data-ad-client="ca-pub-8684336377067417"
          data-ad-slot={slot ?? "8903458349"}
        />
      </div>
    );
  }

  return (
    <div className={className}>
      <ins
        ref={adRef}
        suppressHydrationWarning
        className="adsbygoogle"
        style={{ display: "block" }}
        data-ad-client="ca-pub-8684336377067417"
        data-ad-slot={slot ?? "9663716107"}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
}