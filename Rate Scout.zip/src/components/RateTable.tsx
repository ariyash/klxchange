import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  AREAS,
  CURRENCIES,
  type Area,
  type Currency,
  formatRate,
  perUnitBuy,
  perUnitSell,
  displayUnit,
  displayUnitLabel,
} from "@/lib/changers";
import { getLiveRates } from "@/lib/rates.functions";
import { useAllChangers } from "@/hooks/useChangers";
import { Trophy, Medal, Award } from "lucide-react";

function timeAgo(iso: string) {
  const t = Date.parse(iso);
  if (!isFinite(t)) return iso;
  const mins = Math.max(0, Math.round((Date.now() - t) / 60000));
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs} hr ago`;
  const days = Math.round(hrs / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
}

export function RateTable() {
  const [currency, setCurrency] = useState<Currency>("USD");
  const [currencyQuery, setCurrencyQuery] = useState("USD");
  const [currencyOpen, setCurrencyOpen] = useState(false);

  useEffect(() => {
    const fromUrl = new URLSearchParams(window.location.search).get("currency");
    if (fromUrl) {
      setCurrency(fromUrl);
      setCurrencyQuery(fromUrl);
    }
  }, []);
  const [area, setArea] = useState<Area | "All">("All");
  const [search, setSearch] = useState("");

  useEffect(() => {
    const handler = (e: Event) => {
      const code = (e as CustomEvent<string>).detail;
      if (code) {
        setCurrency(code);
        setCurrencyQuery(code);
      }
    };
    window.addEventListener("rate-currency-change", handler);
    return () => window.removeEventListener("rate-currency-change", handler);
  }, []);

  const currencyMatches = useMemo(() => {
    const q = currencyQuery.trim().toUpperCase();
    if (!q) return CURRENCIES;
    return CURRENCIES.filter((c) => c.includes(q));
  }, [currencyQuery]);

  const pickCurrency = (code: string) => {
    setCurrency(code);
    setCurrencyQuery(code);
    setCurrencyOpen(false);
  };

  const fetchRates = useServerFn(getLiveRates);
  const { data: live, isLoading, isFetching, refetch } = useQuery({
    queryKey: ["live-rates"],
    queryFn: () => fetchRates(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });
  const { changers } = useAllChangers();

  const rows = useMemo(() => {
    const filtered = changers.filter((c) => area === "All" || c.area === area).filter((c) =>
      c.name.toLowerCase().includes(search.toLowerCase()),
    );
    const withRates = filtered.map((c) => {
      const r = live?.[c.slug]?.rates[currency];
      const scale = displayUnit(currency);
      return {
        changer: c,
        rate: r,
        buyPerUnit: r ? perUnitBuy(r) * scale : 0,
        sellPerUnit: r ? perUnitSell(r) * scale : 0,
        updatedAt: r?.updatedAt,
      };
    });
    withRates.sort((a, b) => b.buyPerUnit - a.buyPerUnit);
    return withRates;
  }, [currency, area, search, live, changers]);

  const bestBuy = rows.find((r) => r.rate)?.buyPerUnit ?? 0;
  const topThree = rows.filter((r) => r.rate && r.buyPerUnit > 0).slice(0, 3);

  return (
    <section id="rate-table" className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 scroll-mt-20">
      <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-bold text-foreground">Live Comparison</h2>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-[oklch(0.95_0.05_255)] px-2 py-0.5 text-[10px] font-bold uppercase text-[oklch(0.40_0.20_258)]">
            <span className={`h-1.5 w-1.5 rounded-full bg-[oklch(0.48_0.22_258)] ${isFetching ? "animate-pulse" : ""}`} />
            {isLoading ? "Loading" : "Live"}
          </span>
          <button
            onClick={() => refetch()}
            aria-label="Refresh live rates"
            className="text-xs font-semibold text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
          >
            Refresh
          </button>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <input
            type="text"
            aria-label="Search money changers"
            placeholder="Search money changers…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="rounded-lg border border-border bg-card px-3 py-2 text-sm text-[oklch(0.48_0.22_258)] placeholder:text-[oklch(0.48_0.22_258)]/60 focus:border-[oklch(0.55_0.20_255)] focus:outline-none"
          />
          <div className="relative">
            <input
              type="text"
              aria-label="Search currency"
              placeholder="Search currency (e.g. USD)"
              value={currencyQuery}
              onChange={(e) => {
                const v = e.target.value.toUpperCase();
                setCurrencyQuery(v);
                setCurrencyOpen(true);
                const exact = CURRENCIES.find((c) => c === v);
                if (exact) setCurrency(exact);
              }}
              onFocus={() => setCurrencyOpen(true)}
              onBlur={() => {
                setTimeout(() => setCurrencyOpen(false), 120);
                setCurrencyQuery(currency);
              }}
              className="w-44 rounded-lg border border-border bg-card px-3 py-2 text-sm font-medium uppercase text-[oklch(0.48_0.22_258)] placeholder:text-[oklch(0.48_0.22_258)]/60 focus:border-[oklch(0.55_0.20_255)] focus:outline-none"
            />
            {currencyOpen && currencyMatches.length > 0 && (
              <ul
                role="listbox"
                className="absolute right-0 z-20 mt-1 max-h-64 w-44 overflow-auto rounded-lg border border-border bg-card shadow-lg"
              >
                {currencyMatches.map((c) => (
                  <li key={c}>
                    <button
                      type="button"
                      onMouseDown={(e) => {
                        e.preventDefault();
                        pickCurrency(c);
                      }}
                      className={`block w-full px-3 py-1.5 text-left text-sm hover:bg-secondary ${
                        c === currency ? "bg-secondary font-bold" : ""
                      }`}
                    >
                      {c} / MYR
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
        {(["All", ...AREAS] as const).map((a) => {
          const active = area === a;
          return (
            <button
              key={a}
              onClick={() => setArea(a as Area | "All")}
              className={`whitespace-nowrap rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                active
                  ? "bg-foreground text-background"
                  : "border border-border bg-card text-muted-foreground hover:bg-secondary"
              }`}
            >
              {a === "All" ? "All Locations" : a}
            </button>
          );
        })}
      </div>

      <div className="mb-4 rounded-lg border border-border bg-secondary/40 px-3 py-2 text-xs text-muted-foreground">
        <span className="font-semibold text-foreground">Note:</span> JAGS Money (Pavilion) is temporarily hidden — their{" "}
        <a
          href="https://www.jagsmoney.com/daily-rates/"
          target="_blank"
          rel="noreferrer"
          className="underline underline-offset-2 hover:text-foreground"
        >
          daily-rates page
        </a>{" "}
        currently shows no live data to scrape. We'll re-list them once it's back online.
      </div>

      {topThree.length > 0 && (
        <div className="mb-6">
          <div className="mb-3 flex items-center gap-2">
            <Trophy className="h-5 w-5 text-[oklch(0.48_0.22_258)]" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-foreground">
              Top 3 Best {currency} Rates
            </h3>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            {topThree.map(({ changer, buyPerUnit, updatedAt }, i) => {
              const Icon = i === 0 ? Trophy : i === 1 ? Medal : Award;
              const tone =
                i === 0
                  ? "from-[oklch(0.95_0.10_85)] to-[oklch(0.98_0.04_85)] border-[oklch(0.80_0.15_85)] text-[oklch(0.50_0.15_70)]"
                  : i === 1
                  ? "from-[oklch(0.96_0.01_255)] to-[oklch(0.99_0.01_255)] border-[oklch(0.82_0.02_255)] text-[oklch(0.45_0.02_255)]"
                  : "from-[oklch(0.94_0.06_45)] to-[oklch(0.98_0.03_45)] border-[oklch(0.78_0.10_45)] text-[oklch(0.45_0.12_45)]";
              return (
                <Link
                  key={changer.slug}
                  to="/changer/$slug"
                  params={{ slug: changer.slug }}
                  className={`group relative flex items-center gap-3 rounded-xl border bg-gradient-to-br ${tone} p-4 shadow-sm transition-transform hover:-translate-y-0.5 hover:shadow-md`}
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/80 shadow-inner">
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider opacity-80">
                      #{i + 1} {i === 0 ? "Best" : i === 1 ? "Runner-up" : "Third"}
                    </div>
                    <div className="truncate text-sm font-bold text-foreground">{changer.name}</div>
                    <div className="truncate text-[11px] text-muted-foreground">{changer.area}</div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="font-mono text-base font-bold text-foreground tabular-nums">
                      {formatRate(buyPerUnit)}
                    </div>
                    <div className="text-[10px] text-muted-foreground">
                      per {displayUnitLabel(currency).replace(/^.*?\//, "").trim() || currency}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-primary/20 bg-card shadow-sm ring-1 ring-primary/10" style={{ fontFamily: "Arial, sans-serif" }}>
        <div className="hidden overflow-x-auto md:block">
          <table className="w-full text-left">
            <thead className="bg-primary text-xs font-bold uppercase tracking-wider text-primary-foreground">
              <tr>
                <th className="px-6 py-4 border-r border-primary-foreground/15">Money Changer</th>
                <th className="px-6 py-4 border-r border-primary-foreground/15">Buy {displayUnitLabel(currency)} ↓</th>
                <th className="px-6 py-4 border-r border-primary-foreground/15">Sell {displayUnitLabel(currency)}</th>
                <th className="px-6 py-4 border-r border-primary-foreground/15">Location</th>
                <th className="px-6 py-4 text-right">Last Updated</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-primary/15">
              {rows.map(({ changer, rate, buyPerUnit, sellPerUnit, updatedAt }) => {
                const isBest = rate && buyPerUnit > 0 && buyPerUnit === bestBuy;
                return (
                  <tr
                    key={changer.slug}
                    className={`transition-colors odd:bg-background even:bg-primary/[0.03] hover:bg-gradient-to-r hover:from-[oklch(0.96_0.04_255)] hover:via-[oklch(0.92_0.07_255)] hover:to-[oklch(0.96_0.04_255)] ${
                      isBest ? "bg-[oklch(0.97_0.04_255)]" : ""
                    }`}
                  >
                    <td className="px-6 py-4">
                      <Link to="/changer/$slug" params={{ slug: changer.slug }} className="block">
                        <div className="flex items-center gap-2 font-bold text-foreground">
                          {changer.name}
                          {isBest && (
                            <span className="rounded bg-[oklch(0.55_0.20_255)]/10 px-1.5 py-0.5 text-[10px] font-bold uppercase text-[oklch(0.40_0.20_258)]">
                              Best Rate
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground">{changer.area}</div>
                      </Link>
                    </td>
                    <td className={`px-6 py-4 font-mono font-bold ${isBest ? "text-[oklch(0.48_0.22_258)]" : "text-foreground"}`}>
                      {rate ? formatRate(buyPerUnit) : "—"}
                      {rate && rate.unit !== 1 && (
                        <div className="text-[10px] font-normal text-muted-foreground">
                          {formatRate(rate.buy)} per {rate.unit} {currency}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 font-mono text-foreground">
                      {rate ? formatRate(sellPerUnit) : "—"}
                    </td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{changer.area}</td>
                    <td className="px-6 py-4 text-right text-xs text-muted-foreground">
                      {updatedAt ? timeAgo(updatedAt) : "—"}
                    </td>
                  </tr>
                );
              })}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-sm text-muted-foreground">
                    No money changers match your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <div className="divide-y divide-primary/15 md:hidden">
          {rows.map(({ changer, rate, buyPerUnit, sellPerUnit, updatedAt }, index) => {
            const isBest = rate && buyPerUnit > 0 && buyPerUnit === bestBuy;
            return (
              <Link
                key={changer.slug}
                to="/changer/$slug"
                params={{ slug: changer.slug }}
                className={`block px-4 py-3 transition-colors hover:bg-gradient-to-r hover:from-[oklch(0.96_0.04_255)] hover:via-[oklch(0.92_0.07_255)] hover:to-[oklch(0.96_0.04_255)] ${isBest ? "bg-[oklch(0.97_0.04_255)]" : ""}`}
              >
                <div className="grid min-w-0 grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
                  <div className="flex min-w-0 gap-2">
                    <span className="shrink-0 text-sm font-bold text-muted-foreground">{index + 1}.</span>
                    <div className="min-w-0">
                      <div className="truncate text-sm font-bold text-foreground">{changer.name}</div>
                      <div className="mt-0.5 truncate text-xs text-muted-foreground">{changer.area}</div>
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className={`font-mono text-sm font-bold tabular-nums ${isBest ? "text-[oklch(0.48_0.22_258)]" : "text-foreground"}`}>
                      {rate ? formatRate(buyPerUnit) : "—"}
                    </div>
                    <div className="mt-0.5 font-mono text-xs tabular-nums text-muted-foreground">
                      Sell {rate ? formatRate(sellPerUnit) : "—"}
                    </div>
                  </div>
                </div>
                <div className="mt-2 flex items-center justify-between gap-2 text-[11px] text-muted-foreground">
                  <span>{isBest ? "Best Rate" : `Buy ${displayUnitLabel(currency)}`}</span>
                  <span className="shrink-0">{updatedAt ? timeAgo(updatedAt) : "—"}</span>
                </div>
              </Link>
            );
          })}
          {rows.length === 0 && (
            <div className="px-6 py-12 text-center text-sm text-muted-foreground">
              No money changers match your filters.
            </div>
          )}
        </div>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">
        Rates pulled live from each changer's website. Always confirm at the counter.
      </p>
    </section>
  );
}