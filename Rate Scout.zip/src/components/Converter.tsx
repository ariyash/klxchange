import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CHANGERS, CURRENCIES, type Currency, MID_RATES, perUnitSell, displayUnit, displayUnitLabel } from "@/lib/changers";
import { getLiveRates } from "@/lib/rates.functions";

export function Converter() {
  const [amount, setAmount] = useState("1000");
  const [currency, setCurrency] = useState<Currency>("USD");

  const fetchRates = useServerFn(getLiveRates);
  const { data: live } = useQuery({
    queryKey: ["live-rates"],
    queryFn: () => fetchRates(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });

  // Remittance flow: you SEND MYR, recipient gets foreign currency.
  // Customer pays the changer's SELL rate. Best for sender = LOWEST sell rate.
  const { bestSellPerUnit, bestSlug } = useMemo(() => {
    let best = Infinity;
    let slug: string | null = null;
    for (const c of CHANGERS) {
      const r = live?.[c.slug]?.rates[currency];
      if (!r) continue;
      const pu = perUnitSell(r);
      if (pu > 0 && pu < best) {
        best = pu;
        slug = c.slug;
      }
    }
    const fallback = MID_RATES[currency] ?? 0;
    return {
      bestSellPerUnit: isFinite(best) ? best : fallback,
      bestSlug: slug,
    };
  }, [live, currency]);

  const received = useMemo(() => {
    const n = parseFloat(amount) || 0;
    if (!bestSellPerUnit) return "0.00";
    return (n / bestSellPerUnit).toLocaleString("en-MY", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }, [amount, bestSellPerUnit]);

  const bestChanger = CHANGERS.find((c) => c.slug === bestSlug);

  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-xl shadow-slate-200/50">
      <div className="mb-4">
        <h2 className="text-xl font-bold text-foreground">Currency Calculator</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Live estimate using our published rates. Remittance based.
        </p>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">You Send</label>
          <div className="relative">
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="w-full rounded-lg border border-border bg-secondary px-4 py-3 text-lg font-semibold text-foreground focus:border-[oklch(0.55_0.20_255)] focus:outline-none"
            />
            <div className="absolute right-3 top-1/2 -translate-y-1/2 font-bold text-foreground">MYR</div>
          </div>
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Recipient Gets (Best)</label>
          <div className="relative">
            <input
              type="text"
              value={received}
              readOnly
              className="w-full rounded-lg border border-border bg-secondary px-4 py-3 text-lg font-semibold text-[oklch(0.55_0.20_255)]"
            />
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              aria-label="Select recipient currency"
              className="absolute right-2 top-1/2 -translate-y-1/2 rounded bg-transparent px-2 py-1 font-bold text-foreground"
            >
              {CURRENCIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
      <div className="mt-6 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
        <span>
          Best sell: {displayUnit(currency) === 1 ? `1 ${currency}` : displayUnitLabel(currency)} = <span className="font-mono font-semibold text-foreground">{(bestSellPerUnit * displayUnit(currency)).toFixed(4)}</span> MYR
        </span>
        <span className="font-semibold text-[oklch(0.55_0.20_255)]">
          {bestChanger ? `at ${bestChanger.name}` : "Live rate"}
        </span>
      </div>
    </div>
  );
}