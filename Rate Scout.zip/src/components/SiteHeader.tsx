import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import logoUrl from "@/assets/klxchange-logo.png";
import { AdSlot } from "@/components/AdSlot";

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);
  return (
    <nav className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2" onClick={close}>
          <img
            src={logoUrl}
            alt="KLXchange logo"
            width={32}
            height={32}
            className="size-8 object-contain"
          />
          <span className="text-xl font-bold tracking-tight text-foreground">
            KL<span className="text-[oklch(0.48_0.22_258)]">X</span>change
          </span>
        </Link>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
          <Link to="/" className="text-[oklch(0.55_0.20_255)]">
            Live Rates
          </Link>
          <Link to="/changers" className="hover:text-foreground">
            Money Changers
          </Link>
          <Link to="/publish-rate" className="hover:text-foreground">
            Publish Your Rate
          </Link>
        </div>
        <button
          type="button"
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="md:hidden inline-flex items-center justify-center rounded-md p-2 text-foreground hover:bg-accent"
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>
      {open && (
        <div className="md:hidden border-t border-border bg-background">
          <div className="mx-auto flex max-w-7xl flex-col px-4 py-3 sm:px-6 text-sm font-medium">
            <Link to="/" onClick={close} className="py-2 text-[oklch(0.55_0.20_255)]">
              Live Rates
            </Link>
            <Link to="/changers" onClick={close} className="py-2 text-foreground">
              Money Changers
            </Link>
            <Link to="/publish-rate" onClick={close} className="py-2 text-foreground">
              Publish Your Rate
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-secondary/50 py-12 text-center text-sm text-muted-foreground">
      <AdSlot className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-8" />
      <nav className="mx-auto mb-6 flex max-w-3xl flex-wrap items-center justify-center gap-x-5 gap-y-2 px-4 text-sm font-medium">
        <Link to="/about" className="hover:text-foreground">About</Link>
        <Link to="/methodology" className="hover:text-foreground">Methodology</Link>
        <Link to="/contact" className="hover:text-foreground">Contact</Link>
        <Link to="/privacy" className="hover:text-foreground">Privacy</Link>
        <Link to="/terms" className="hover:text-foreground">Terms</Link>
        <Link to="/changers" className="hover:text-foreground">All changers</Link>
      </nav>
      <p>© 2026 KLXchange Malaysia. Independent rate comparison — not a money changer, not a financial advisor. Always confirm the rate at the counter before transacting.</p>
    </footer>
  );
}