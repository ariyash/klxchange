import { CURRENCY_NAMES } from "@/lib/changers";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { perUnitBuy, perUnitSell, formatRate, displayUnit, displayUnitLabel } from "@/lib/changers";
import { getLiveRates } from "@/lib/rates.functions";
import { useAllChangers } from "@/hooks/useChangers";
import { Fragment, useState } from "react";
import { X } from "lucide-react";
import { Link } from "@tanstack/react-router";

type Group = { title: string; items: { code: string; country: string }[] };

const GROUPS: Group[] = [
  {
    title: "Asia Pacific Currencies",
    items: [
      { code: "AUD", country: "au" },
      { code: "SGD", country: "sg" },
      { code: "JPY", country: "jp" },
      { code: "THB", country: "th" },
      { code: "TWD", country: "tw" },
      { code: "CNY", country: "cn" },
      { code: "HKD", country: "hk" },
      { code: "KRW", country: "kr" },
      { code: "VND", country: "vn" },
      { code: "IDR", country: "id" },
      { code: "NZD", country: "nz" },
      { code: "PHP", country: "ph" },
      { code: "INR", country: "in" },
      { code: "BND", country: "bn" },
      { code: "LKR", country: "lk" },
      { code: "PKR", country: "pk" },
      { code: "NPR", country: "np" },
      { code: "BDT", country: "bd" },
      { code: "MOP", country: "mo" },
      { code: "KHR", country: "kh" },
    ],
  },
  {
    title: "Americas & Europe",
    items: [
      { code: "USD", country: "us" },
      { code: "EUR", country: "eu" },
      { code: "GBP", country: "gb" },
      { code: "CAD", country: "ca" },
      { code: "CHF", country: "ch" },
      { code: "DKK", country: "dk" },
      { code: "NOK", country: "no" },
      { code: "SEK", country: "se" },
      { code: "CZK", country: "cz" },
      { code: "TRY", country: "tr" },
      { code: "RUB", country: "ru" },
      { code: "ZAR", country: "za" },
    ],
  },
  {
    title: "Middle East",
    items: [
      { code: "AED", country: "ae" },
      { code: "SAR", country: "sa" },
      { code: "BHD", country: "bh" },
      { code: "JOD", country: "jo" },
      { code: "KWD", country: "kw" },
      { code: "OMR", country: "om" },
      { code: "QAR", country: "qa" },
      { code: "EGP", country: "eg" },
    ],
  },
];

export function CurrencyGrid() {
  const fetchRates = useServerFn(getLiveRates);
  const { data: live } = useQuery({
    queryKey: ["live-rates"],
    queryFn: () => fetchRates(),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });
  const { changers } = useAllChangers();

  const [openCode, setOpenCode] = useState<string | null>(null);

  const bestBuyFor = (code: string) => {
    let best = 0;
    const scale = displayUnit(code);
    for (const c of changers) {
      const r = live?.[c.slug]?.rates[code];
      if (!r) continue;
      const pu = perUnitBuy(r) * scale;
      if (pu > best) best = pu;
    }
    return best;
  };

  const handleClick = (code: string) => {
    const params = new URLSearchParams(window.location.search);
    params.set("currency", code);
    window.history.replaceState({}, "", `${window.location.pathname}?${params}`);
    window.dispatchEvent(new CustomEvent("rate-currency-change", { detail: code }));
    setOpenCode(code);
  };

  const rowsFor = (code: string) => {
    const scale = displayUnit(code);
    const rows = changers.map((c) => {
      const r = live?.[c.slug]?.rates[code];
      return r
        ? { changer: c, buy: perUnitBuy(r) * scale, sell: perUnitSell(r) * scale }
        : null;
    }).filter((x): x is { changer: typeof changers[number]; buy: number; sell: number } => !!x);
    const buys = [...rows].sort((a, b) => b.buy - a.buy);
    const sells = [...rows].filter((r) => r.sell > 0).sort((a, b) => a.sell - b.sell);
    return { buys, sells };
  };

  return (
    <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="space-y-10">
        {GROUPS.map((g) => (
          <div key={g.title}>
            <div className="mb-5 rounded-lg bg-[oklch(0.48_0.22_258)] px-5 py-3 text-center text-base font-bold text-white">
              {g.title}
            </div>
            <div className="grid min-w-0 grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
              {g.items.map((c) => {
                const best = bestBuyFor(c.code);
                const isOpen = openCode === c.code;
                return (
                  <Fragment key={c.code}>
                  <button
                    type="button"
                    onClick={() => handleClick(c.code)}
                    aria-label={`View rates for ${CURRENCY_NAMES[c.code] ?? c.code} (${c.code})`}
                    aria-expanded={isOpen}
                    className={`flex flex-col items-center rounded-xl border bg-card px-3 py-4 text-center shadow-sm transition-all hover:-translate-y-0.5 hover:border-[oklch(0.55_0.20_255)] hover:shadow-md ${isOpen ? "border-[oklch(0.48_0.22_258)] ring-2 ring-[oklch(0.48_0.22_258)]" : "border-border"}`}
                  >
                    <img
                      src={`https://flagcdn.com/w80/${c.country}.png`}
                      srcSet={`https://flagcdn.com/w160/${c.country}.png 2x`}
                      alt={`${c.code} flag`}
                      loading="lazy"
                      width={40}
                      height={30}
                      className="h-7 w-10 rounded-sm bg-secondary object-cover shadow-sm"
                      onError={(e) => {
                        const img = e.currentTarget;
                        img.onerror = null;
                        img.removeAttribute("srcset");
                        img.src =
                          "data:image/svg+xml;utf8," +
                          encodeURIComponent(
                            `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 30'><rect width='40' height='30' rx='3' fill='%23e2e8f0'/><text x='50%25' y='55%25' font-family='system-ui,sans-serif' font-size='10' font-weight='700' text-anchor='middle' fill='%2364748b'>${c.code}</text></svg>`,
                          );
                      }}
                    />
                    <div className="mt-2 text-sm font-bold text-foreground">{c.code}</div>
                    <div className="text-[11px] text-muted-foreground">
                      {CURRENCY_NAMES[c.code] ?? c.code}
                    </div>
                    <div className="mt-1 font-mono text-xs font-bold text-[oklch(0.48_0.22_258)]">
                      {best > 0 ? formatRate(best) : "—"}
                    </div>
                  </button>
                  {isOpen && (
                    <div className="col-span-2 min-w-0 sm:col-span-3 md:col-span-4 lg:col-span-6">
                      {renderPanel(c.code)}
                    </div>
                  )}
                  </Fragment>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </section>
  );

  function renderPanel(code: string) {
    const { buys, sells } = rowsFor(code);
    return (
      <div className="mt-3 min-w-0 overflow-hidden rounded-xl border border-[oklch(0.48_0.22_258)]/30 bg-card p-3 shadow-sm sm:p-5">
        <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
          <h3 className="min-w-0 truncate text-base font-bold sm:text-lg">
            {code} — {CURRENCY_NAMES[code] ?? code} Rates
          </h3>
          <button
            type="button"
            onClick={() => setOpenCode(null)}
            aria-label="Close"
            className="rounded-md p-1 text-muted-foreground hover:bg-secondary hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        {buys.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">
            No live rates available for {code} right now.
          </p>
        ) : (
          <div className="grid min-w-0 gap-4 md:grid-cols-2 md:gap-6">
            <div className="min-w-0">
              <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-[oklch(0.48_0.22_258)] sm:text-sm">
                Buy {code} — Highest to Lowest
              </h4>
              <ul className="min-w-0 divide-y divide-border rounded-lg border border-border">
                {buys.map((r, i) => (
                  <li key={r.changer.slug} className="grid min-w-0 gap-1 px-2.5 py-2 text-sm sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center sm:gap-2 sm:px-3">
                    <span className="flex min-w-0 items-center gap-2">
                      <span className="shrink-0 text-xs font-bold text-muted-foreground">{i + 1}.</span>
                      <Link
                        to="/changer/$slug"
                        params={{ slug: r.changer.slug }}
                        className="min-w-0 truncate hover:text-[oklch(0.48_0.22_258)] hover:underline"
                      >
                        {r.changer.name}
                      </Link>
                    </span>
                    <span className="pl-6 text-left font-mono text-xs font-bold tabular-nums sm:pl-0 sm:text-right sm:text-sm">{formatRate(r.buy)}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="min-w-0">
              <h4 className="mb-2 text-xs font-bold uppercase tracking-wider text-[oklch(0.48_0.22_258)] sm:text-sm">
                Sell {code} — Lowest to Highest
              </h4>
              <ul className="min-w-0 divide-y divide-border rounded-lg border border-border">
                {sells.map((r, i) => (
                  <li key={r.changer.slug} className="grid min-w-0 gap-1 px-2.5 py-2 text-sm sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center sm:gap-2 sm:px-3">
                    <span className="flex min-w-0 items-center gap-2">
                      <span className="shrink-0 text-xs font-bold text-muted-foreground">{i + 1}.</span>
                      <Link
                        to="/changer/$slug"
                        params={{ slug: r.changer.slug }}
                        className="min-w-0 truncate hover:text-[oklch(0.48_0.22_258)] hover:underline"
                      >
                        {r.changer.name}
                      </Link>
                    </span>
                    <span className="pl-6 text-left font-mono text-xs font-bold tabular-nums sm:pl-0 sm:text-right sm:text-sm">{formatRate(r.sell)}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
        <p className="mt-3 text-xs text-muted-foreground">
          Rates shown as MYR per {displayUnitLabel(code)}. Always confirm at the counter.
        </p>
      </div>
    );
  }
}