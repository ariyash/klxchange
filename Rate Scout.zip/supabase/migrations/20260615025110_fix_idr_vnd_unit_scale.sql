-- Normalize unit scale for low-denomination currencies where scrapers stored unit=1.
-- Reference per-unit MYR (mid-market). If buy/unit is > 100x the reference,
-- bump unit by the closest power of 10 that brings it back into range.

WITH refs(code, ref) AS (
  VALUES
    ('IDR', 0.00029::numeric),
    ('VND', 0.00018::numeric),
    ('KRW', 0.0034::numeric),
    ('LAK', 0.00022::numeric),
    ('KHR', 0.00115::numeric),
    ('MMK', 0.00224::numeric)
),
candidates AS (
  SELECT cr.id, cr.code, cr.unit, cr.buy, r.ref,
         ROUND(LOG(10, (cr.buy / cr.unit) / r.ref))::int AS k
  FROM changer_rates cr
  JOIN refs r ON r.code = cr.code
  WHERE cr.buy > 0 AND cr.unit > 0
)
UPDATE changer_rates cr
SET unit = cr.unit * POWER(10, c.k)::numeric
FROM candidates c
WHERE cr.id = c.id
  AND c.k <> 0
  AND ABS(c.k) <= 8;
