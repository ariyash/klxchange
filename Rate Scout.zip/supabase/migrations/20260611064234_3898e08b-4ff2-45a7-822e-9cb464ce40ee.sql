DELETE FROM public.changer_rates WHERE changer_id = (SELECT id FROM public.changers WHERE slug = 'jagsmoneybb');
DELETE FROM public.changers WHERE slug = 'jagsmoneybb';