CREATE TABLE public.publish_rate_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  business_name text NOT NULL,
  contact_name text NOT NULL,
  email text NOT NULL,
  phone text,
  location text,
  message text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.publish_rate_submissions TO authenticated;
GRANT ALL ON public.publish_rate_submissions TO service_role;
ALTER TABLE public.publish_rate_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view submissions" ON public.publish_rate_submissions FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins delete submissions" ON public.publish_rate_submissions FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));