
INSERT INTO public.changers (slug, name, area, address, phone, hours, website, rate_source_kind, rate_source_url, rating, reviews)
VALUES
  ('antaraduit-tun-razak', 'Antaraduit (HQ Drive-In, Tun Razak)', 'KLCC / Ampang',
   'Ground Floor, 195A, Jalan Tun Razak, 50400 Kuala Lumpur', '03-2161 1225', 'Mon–Sat 9:30am–6:00pm',
   'https://www.antaraduit.com.my/', 'antaraduit', 'https://www.antaraduit.com.my/get_branch_units.php?val=1', 0, 0),
  ('antaraduit-shah-alam', 'Antaraduit (Shah Alam)', 'Petaling Jaya',
   'Shah Alam, Selangor', '', 'Mon–Sat 9:30am–6:00pm',
   'https://www.antaraduit.com.my/', 'antaraduit', 'https://www.antaraduit.com.my/get_branch_units.php?val=3', 0, 0),
  ('antaraduit-avenue-k', 'Antaraduit (Avenue K / KLCC)', 'KLCC / Ampang',
   'C7, Concourse Level, Avenue K Mall, Jalan Ampang, 50450 Kuala Lumpur', '03-2161 1222', 'Mon–Sun 10:00am–10:00pm',
   'https://www.antaraduit.com.my/', 'antaraduit', 'https://www.antaraduit.com.my/get_branch_units.php?val=4', 0, 0)
ON CONFLICT (slug) DO UPDATE SET
  name = EXCLUDED.name,
  area = EXCLUDED.area,
  address = EXCLUDED.address,
  phone = EXCLUDED.phone,
  hours = EXCLUDED.hours,
  website = EXCLUDED.website,
  rate_source_kind = EXCLUDED.rate_source_kind,
  rate_source_url = EXCLUDED.rate_source_url;
