WITH refs(code, ref) AS (
  VALUES
    ('IDR', 0.00029::numeric),
    ('VND', 0.00018::numeric),
    ('KRW', 0.0034::numeric),
    ('LAK', 0.00022::numeric),
    ('KHR', 0.00115::numeric),
    ('MMK', 0.00224::numeric)
),
candidates AS (
  SELECT cr.id,
         ROUND(LOG(10, (cr.buy / cr.unit) / r.ref))::int AS k
  FROM changer_rates cr
  JOIN refs r ON r.code = cr.code
  WHERE cr.buy > 0 AND cr.unit > 0
)
UPDATE changer_rates cr
SET unit = cr.unit * POWER(10, c.k)::numeric
FROM candidates c
WHERE cr.id = c.id
  AND c.k <> 0
  AND ABS(c.k) <= 8;