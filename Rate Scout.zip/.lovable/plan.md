# Admin Money Changer Manager

## 1. Enable Lovable Cloud
Provision database + auth (email/password). Required for persistent changers and admin login.

## 2. Database schema (migration)
- `profiles` — auto-created on signup, holds `id`, `email`, `display_name`.
- `app_role` enum (`admin`, `user`) + `user_roles` table + `has_role()` security-definer function (per security standard).
- `changers` — id, slug (unique), name, area, address, phone, hours, website, rating, reviews, rate_source_kind ('csv' | 'klmc' | 'json'), rate_source_url, rate_json_mapping (jsonb: `{ list, code, unit, buy, sell }`), created_by, timestamps.
- `changer_rates` — id, changer_id, code, unit, buy, sell, updated_at; unique (changer_id, code).
- RLS: anyone (anon + authenticated) can SELECT changers & rates; only admins INSERT/UPDATE/DELETE.
- Grants per Supabase Data API rules.

## 3. Auth
- `/auth` page: email/password sign in + sign up. After sign-up, first user can self-promote (or seeded admin role — we'll add a one-time SQL inviting the first registered email to admin role on request).
- Integration-managed `_authenticated/route.tsx` already handles gating.

## 4. Admin UI — `/_authenticated/admin`
- Role check via `has_role(auth.uid(), 'admin')` server fn; non-admins see "Access denied".
- List existing DB-backed changers + edit/delete.
- "Add money changer" form:
  - Name, area (dropdown), address, phone, hours, website (optional).
  - Rate source picker:
    - **CSV paste/upload** — textarea or file input parsing `code,unit,buy,sell` (header optional).
    - **Pull from URL (klmoneychanger)** — uses existing `scrapeKlmc`.
    - **Custom JSON endpoint** — URL + field-path mapping (`list`, `code`, `unit`, `buy`, `sell`); fetched server-side, parsed using mapping.
  - "Refresh rates now" button on each saved changer.

## 5. Server functions
- `listAdminChangers`, `upsertChanger`, `deleteChanger` (admin only via `requireSupabaseAuth` + role check).
- `ingestRates({ changerId })` — re-runs the configured source, writes to `changer_rates`.
- Update existing `getLiveRates` to merge DB changers + their stored rates with the existing hard-coded list.

## 6. Display
- Home page `RateTable` and `CurrencyGrid` continue to work; merged changers appear automatically.

## Technical notes
- CSV parser: split lines, trim, skip header row if first cell is non-numeric.
- JSON mapper: dot-path resolver (`a.b.0.c`).
- Generic URL scrape uses `fetch` in a server fn (no extra deps).
- One-time admin promotion: after first sign-up, the user runs a provided SQL snippet (or we ask their email upfront and seed the role in the migration).

## Out of scope
- Multi-tenant orgs, audit log, email invites, image uploads.
